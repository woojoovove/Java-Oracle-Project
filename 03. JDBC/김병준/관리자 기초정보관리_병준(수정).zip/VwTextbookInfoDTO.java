package dto;

public class VwTextbookInfoDTO {

	private String vtextbookseq;
	private String vtextbookname;
	private String vpublisher;
	private String vtextbookstate;
	
	
	
	public String getVtextbookstate() {
		return vtextbookstate;
	}
	public void setVtextbookstate(String vtextbookstate) {
		this.vtextbookstate = vtextbookstate;
	}
	
	public String getVtextbookseq() {
		return vtextbookseq;
	}
	public void setVtextbookseq(String vtextbookseq) {
		this.vtextbookseq = vtextbookseq;
	}
	public String getVtextbookname() {
		return vtextbookname;
	}
	public void setVtextbookname(String vtextbookname) {
		this.vtextbookname = vtextbookname;
	}
	public String getVpublisher() {
		return vpublisher;
	}
	public void setVpublisher(String vpublisher) {
		this.vpublisher = vpublisher;
	}
	
	
	
}
