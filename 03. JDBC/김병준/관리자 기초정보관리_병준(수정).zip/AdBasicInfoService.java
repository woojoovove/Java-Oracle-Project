package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.AdministratorBasicInfoDAO;
import admin.AdministratorBasicInfoView;
import admin.AdministratorView;
import dto.ClassRoomDTO;
import dto.CourseNameDTO;
import dto.PublisherDTO;
import dto.SubjectNameDTO;
import dto.SubjectTypeDTO;
import dto.TextBookDTO;
import dto.VwTextbookInfoDTO;

public class AdBasicInfoService implements IAdBasicInfoService {

	private static AdministratorView administratorView;
	private static AdministratorBasicInfoView administratorBasicInfoView;
	
	
	private static Scanner scan;
	
	static{
		administratorView = new AdministratorView();
		administratorBasicInfoView = new AdministratorBasicInfoView();
		scan = new Scanner(System.in);
	}
	
	@Override
	public void basicCourseList() {
		
		administratorView.title(AdministratorView.courseName);
		
		administratorView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<CourseNameDTO> list = adminDAO.basicCourseList();
		
		for (CourseNameDTO dto : list) {
			System.out.printf("\t\t\t[%s] %s\n", dto.getSeq(), dto.getName());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicInfoCourseAddDelMo();	
		
		adminDAO.close();
		
	}

	@Override
	public void insertCourseName() {
		
		administratorBasicInfoView.blank();
		
		administratorView.title(AdministratorView.insertCourseName);
		
		administratorBasicInfoView.basicInfoCourseAdd();
		
		System.out.print("\t과정명 : ");
		String name = scan.nextLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		CourseNameDTO DTO = new CourseNameDTO ();
		DTO.setName(name);
				
		int result = adminDAO.courseAdd(DTO);
		
		administratorBasicInfoView.basicInfoCourseAddFin();
		
		adminDAO.close();
		
		
		
	}

	@Override
	public void modifyCourseName() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		CourseNameDTO DTO = new CourseNameDTO ();
		
		ArrayList<CourseNameDTO> list = adminDAO.basicCourseList();
		
		String basicOldCourseNameSeq = administratorBasicInfoView.basicInfoCourseModDel01();
		
		if (!basicOldCourseNameSeq.equals("0")) {
			
			String basicCourseName = adminDAO.selectCourseNameEdit(basicOldCourseNameSeq);
			administratorBasicInfoView.basicInfoCourseModDel02(basicCourseName);
		
		}
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.modifyCourseName);
		
		administratorView.thickLine();
		
		String basicOldCourseName = adminDAO.selectCourseNameEdit(basicOldCourseNameSeq);
		System.out.println("\t기존 과정명 : " + basicOldCourseName);
	
		String basicNewCourseName = administratorBasicInfoView.basicInfoMod01();
		
		CourseNameDTO dto = new CourseNameDTO();
		
		dto.setSeq(basicOldCourseNameSeq);
		dto.setName(basicNewCourseName);
		
		int result = adminDAO.courseEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editBasicCourseName(basicNewCourseName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		administratorBasicInfoView.basicInfoCourseModFin();
		
	}

	@Override
	public void deleteCourseName() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		CourseNameDTO DTO = new CourseNameDTO ();
		
		ArrayList<CourseNameDTO> list = adminDAO.basicCourseList();
		
		String basicDelCourseNameSeq = administratorBasicInfoView.basicInfoCourseModDel01();
		
		if (!basicDelCourseNameSeq.equals("0")) {
			
			String basicDelCourseName = adminDAO.selectCourseNameEdit(basicDelCourseNameSeq);
			administratorBasicInfoView.basicInfoCourseModDel02(basicDelCourseName);
		
		}
		
		administratorView.title(AdministratorBasicInfoView.deleteCourseName);
		
		administratorView.thickLine();
		
		String basicDelCourseName = adminDAO.selectCourseNameEdit(basicDelCourseNameSeq);
		System.out.println("\t삭제할 과정명 : " + basicDelCourseName);
		
		CourseNameDTO dto = new CourseNameDTO();
		
		dto.setSeq(basicDelCourseNameSeq);
		
		int result = adminDAO.courseDel(dto);
		
		if (result == 1) {
			administratorBasicInfoView.delBasicCourseName(basicDelCourseName);
		} else {
			System.out.println("실패하였습니다");
		}
		
	}
	
	@Override
	public void subjectName() {
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.subjectName);
		
		administratorView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<SubjectNameDTO> list = adminDAO.basicSubjectList();
		
		for (SubjectNameDTO dto : list) {
			System.out.printf("\t\t\t[%s] %s\n", dto.getSeq(), dto.getName());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicSubjectListAddDelMo();	
		
		adminDAO.close();
		
	}

	@Override
	public void insertSubject() {
		
		administratorBasicInfoView.blank();
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.subjectTypeName);
		
		administratorBasicInfoView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<SubjectTypeDTO> list = adminDAO.basicSubjectTypeList();
		
		for (SubjectTypeDTO dto : list) {
			System.out.printf("\t\t\t\t[%s] %s\n", dto.getSeq(), dto.getName());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicSubjectAdd01();
		String subjectType = scan.nextLine();
		
		administratorBasicInfoView.basicSubjectAdd02();
		
		System.out.print("\t새로운 과목 명 : ");
		String newSubject = scan.nextLine();
		
		SubjectNameDTO DTO = new SubjectNameDTO ();
		DTO.setName(newSubject);
		DTO.setSubjectTypeSeq(subjectType);
				
		int result = adminDAO.subjectAdd(DTO);
		
		administratorBasicInfoView.basicInfoCourseAddFin();
		
		adminDAO.close();
		
	}

	@Override
	public void modifySubject() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		SubjectNameDTO DTO = new SubjectNameDTO ();
		
		ArrayList<SubjectNameDTO> list = adminDAO.basicSubjectList();
		
		String basicOldSubjectNameSeq = administratorBasicInfoView.basicSubjectModDel01();
		
		if (!basicOldSubjectNameSeq.equals("0")) {
			
			String basicSubjectName = adminDAO.selectSubjectNameEdit(basicOldSubjectNameSeq);
			administratorBasicInfoView.basicInfoCourseModDel02(basicSubjectName);
		
		}
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.modifySubjectName);
		
		administratorView.thickLine();
		
		
		String basicSubjectName = adminDAO.selectSubjectNameEdit(basicOldSubjectNameSeq);
		System.out.println("\t기존 과목명 : " + basicSubjectName);
		
	
		String basicNewSubjectName = administratorBasicInfoView.basicSubjectMod01();
		
		SubjectNameDTO dto = new SubjectNameDTO();
		
		dto.setSeq(basicOldSubjectNameSeq);
		dto.setName(basicNewSubjectName);
		
		int result = adminDAO.subjectEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editBasicCourseName(basicNewSubjectName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		//TODO 과목정보 수정 추가
		
		administratorBasicInfoView.basicInfoCourseModFin();
		
	}

	@Override
	public void deleteSubject() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		SubjectNameDTO DTO = new SubjectNameDTO ();
		
		ArrayList<SubjectNameDTO> list = adminDAO.basicSubjectList();
		
		String basicDelSubjectNameSeq = administratorBasicInfoView.basicSubjectModDel01();
		
		if (!basicDelSubjectNameSeq.equals("0")) {
			
			String basicDelSubjectName = adminDAO.selectSubjectNameEdit(basicDelSubjectNameSeq);
			administratorBasicInfoView.basicInfoCourseModDel02(basicDelSubjectName);
		
		}
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.deleteSubjectName);
		
		administratorBasicInfoView.thickLine();
		
		String basicDelSubjectName = adminDAO.selectSubjectNameEdit(basicDelSubjectNameSeq);
		System.out.println("\t삭제할 과목명 : " + basicDelSubjectName);
		
		SubjectNameDTO dto = new SubjectNameDTO();
		
		dto.setSeq(basicDelSubjectNameSeq);
		
		int result = adminDAO.subjectDel(dto);
		
		if (result == 1) {
			administratorBasicInfoView.delBasicCourseName(basicDelSubjectName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		
	}
	
	
	@Override
	public void classRoom() {
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.classRoom);
		
		administratorView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<ClassRoomDTO> list = adminDAO.basicClassRoomList();
		
		for (ClassRoomDTO dto : list) {
			System.out.printf("\t\t\t[%s] %s (%s명)\n", dto.getSeq(), dto.getName(), dto.getNum());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicClassroomListDelMo();	
		
		adminDAO.close();
		
	}

	@Override
	public void modifyClassRoomName() {
		
		String editClassroomSeq = administratorBasicInfoView.basicClassroomModDel01();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ClassRoomDTO DTO = new ClassRoomDTO ();
		
		ArrayList<ClassRoomDTO> list = adminDAO.basicClassRoomList();
		
		administratorBasicInfoView.basicClassroomModDel02();
		administratorBasicInfoView.title(AdministratorBasicInfoView.modifyClassRoomName);
	
		String oldClassroomName = adminDAO.selectClassroomNameEdit(editClassroomSeq);
		
		administratorBasicInfoView.thickLine();
		System.out.print("\t선택 강의실명 : " + oldClassroomName);
		System.out.println();
		administratorBasicInfoView.thinLine();
		System.out.print("\t새 강의실명 : " );
		String newClassroomName = scan.nextLine();
		
		ClassRoomDTO dto = new ClassRoomDTO();
		
		dto.setSeq(editClassroomSeq);
		dto.setName(newClassroomName);
		
		int result = adminDAO.classroomNameEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editBasicClassroomName(newClassroomName);
		} else {
			System.out.println("\t실패하였습니다.");
		}
		
	}

	@Override
	public void modifyclassRoomNum() {
		
		String editClassroomSeq = administratorBasicInfoView.basicClassroomModDel01();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ClassRoomDTO DTO = new ClassRoomDTO ();
		
		ArrayList<ClassRoomDTO> list = adminDAO.basicClassRoomList();
		
		administratorBasicInfoView.basicClassroomModDel02();
		administratorBasicInfoView.title(AdministratorBasicInfoView.modifyClassRoomNum);
	
		String oldClassroomNum = adminDAO.selectClassroomNumEdit(editClassroomSeq);
		
		administratorBasicInfoView.thickLine();
		System.out.print("\t선택 강의실 정원 : " + oldClassroomNum);
		System.out.println();
		
		administratorBasicInfoView.thinLine();
		System.out.print("\t새 강의실 정원 : " );
		String newClassroomNum = scan.nextLine();
		
		ClassRoomDTO dto = new ClassRoomDTO();
		
		dto.setSeq(editClassroomSeq);
		dto.setNum(newClassroomNum);
		
		int result = adminDAO.classroomNumEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editBasicClassroomNum(newClassroomNum);
		} else {
			System.out.println("\t실패하였습니다.");
		}
		
	}
	
	@Override
	public void textBook() {
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.textBook);
		
		administratorView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<VwTextbookInfoDTO> list = adminDAO.basicTextbookList();
		
		for (VwTextbookInfoDTO dto : list) {
			System.out.printf("\t\t\t[%s] 교재명 %s\n \t\t\t          출판사 %s\n", 
					dto.getVtextbookseq(), 
					dto.getVtextbookname(), 
					dto.getVpublisher());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicTextbookAddDelMo01();	
		
		adminDAO.close();
		
	}

	/*@Override
	public void addtextBook() {
		
		administratorBasicInfoView.basicTextbookAdd();
		System.out.print("\t새로운 교재명 : ");
		String newTextbook = scan.nextLine();
		
		administratorBasicInfoView.basicPublisherAdd01();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		ArrayList<PublisherDTO> list = adminDAO.publisherList();
		
		for (PublisherDTO dto : list) {
			System.out.printf("\t[%s] %s\n", dto.getSeq(), dto.getName());
			administratorView.thinLine();
		}
		
		administratorBasicInfoView.basicPublisherAdd02();
		
		String publisherSeq = scan.nextLine();
		
		TextBookDTO DTO = new TextBookDTO ();
		DTO.setPublisherSeq(publisherSeq);
		DTO.setName(newTextbook);
				
		int result = adminDAO.textbookAdd(DTO);
		
		administratorBasicInfoView.basicInfoCourseAddFin();
		
		adminDAO.close();
		
		
	}
	*/
	@Override
	public void modifytextBook() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		TextBookDTO DTO = new TextBookDTO ();
		
		ArrayList<TextBookDTO> list = adminDAO.textbookList();
		
		String basicOldTextbookNameSeq = administratorBasicInfoView.basicTextbookMod01();
		
		if (!basicOldTextbookNameSeq.equals("0")) {
			
			String basicTextbookName = adminDAO.selectTextbookNameEdit(basicOldTextbookNameSeq);
			administratorBasicInfoView.basicTextbookMod02(basicTextbookName);
		
		}
		
		String basicTextbookName = adminDAO.selectTextbookNameEdit(basicOldTextbookNameSeq);
		System.out.println("\t선택 교재명 : " + basicTextbookName);
		
	
		String basicNewTextbookName = administratorBasicInfoView.basicTextbookMod03();
		
		TextBookDTO dto = new TextBookDTO();
		
		dto.setSeq(basicOldTextbookNameSeq);
		dto.setName(basicNewTextbookName);
		
		int result = adminDAO.textbookNameEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editTextbookName(basicNewTextbookName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		administratorBasicInfoView.basicInfoCourseModFin();
		
		adminDAO.close();
		
	}
	
	@Override
	public void modifypublisher() {
		
		administratorBasicInfoView.blank();
		
		administratorBasicInfoView.title(AdministratorBasicInfoView.selectPublisher);
		
		administratorBasicInfoView.thickLine();
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		PublisherDTO DTO = new PublisherDTO ();
		
		ArrayList<PublisherDTO> list = adminDAO.publisherList();
		
		for (PublisherDTO dto : list) {
			System.out.printf("\t\t\t[%s] %s\n", 
					dto.getSeq(), 
					dto.getName());
			administratorView.thinLine();
		}
		
		String basicOldPublisherNameSeq = administratorBasicInfoView.basicPublisherMod01();
		
		if (!basicOldPublisherNameSeq.equals("0")) {
			
			String basicPublisherName = adminDAO.selectPublisherNameEdit(basicOldPublisherNameSeq);
			administratorBasicInfoView.basicPublisherMod02(basicPublisherName);
		
		}
		
		String basicPublisherName = adminDAO.selectPublisherNameEdit(basicOldPublisherNameSeq);
		System.out.println("\t선택 출판사명 : " + basicPublisherName);
		
	
		String basicNewPublisherName = administratorBasicInfoView.basicPublisherMod03();
		
		PublisherDTO dto = new PublisherDTO();
		
		dto.setSeq(basicOldPublisherNameSeq);
		dto.setName(basicNewPublisherName);
		
		int result = adminDAO.publisherNameEdit(dto);
		
		if (result == 1) {
			administratorBasicInfoView.editPublisherName(basicNewPublisherName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		administratorBasicInfoView.basicInfoCourseModFin();
		
		
		
		adminDAO.close();
	}

	@Override
	public void deletetextBook() {
		
		AdministratorBasicInfoDAO adminDAO = new AdministratorBasicInfoDAO();
		
		TextBookDTO DTO = new TextBookDTO ();
		
		ArrayList<TextBookDTO> list = adminDAO.textbookList();
		
		String DelTextbookSeq = administratorBasicInfoView.basicTextbookDel01();
		
		if (!DelTextbookSeq.equals("0")) {
			
			String DelTextbook = adminDAO.selectTextbookEdit(DelTextbookSeq);
			administratorBasicInfoView.basicTextbookDel02(DelTextbook);
		
		}
		
		String DelTextbookName = adminDAO.selectTextbookNameEdit(DelTextbookSeq);
				
		TextBookDTO dto = new TextBookDTO();
		
		dto.setSeq(DelTextbookSeq);
		
		int result = adminDAO.textbookDel(dto);
		
		if (result == 1) {
			administratorBasicInfoView.delBasicCourseName(DelTextbookName);
		} else {
			System.out.println("실패하였습니다");
		}
		
		
	}

	@Override
	public void addLecturer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lecturerInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void detailLecturer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerReg() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerTel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void basicInfomenu() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void textBookMenu() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectPublisher() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addtextBook() {
		// TODO Auto-generated method stub
		
	}

	

	
	
}
