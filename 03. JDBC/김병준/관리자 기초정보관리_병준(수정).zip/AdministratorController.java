package admin;

import java.util.Scanner;

import admin.service.AdAttendanceService;
import admin.service.AdBasicInfoService;
import admin.service.AdCourseService;
import admin.service.AdGradeService;
import admin.service.AdLecturerInfoService;
import admin.service.AdRecommendationService;
import admin.service.AdStudentService;
import admin.service.IAdAttendanceService;
import admin.service.IAdBasicInfoService;
import admin.service.IAdCourseService;
import admin.service.IAdGradeService;
import admin.service.IAdLecturerInfoService;
import admin.service.IAdRecommendationService;
import admin.service.IAdStudentService;
import login.LoginController;
import util.Cls;

public class AdministratorController {

	private static AdministratorView administratorView;
	private static AdministratorBasicInfoView administratorBasicInfoView; // TODO 추가
	
	private static IAdCourseService adCourseService;
	private static IAdStudentService adStudentService;
	private static IAdAttendanceService adAttendanceService;
	private static IAdRecommendationService adRecommendationService;
	private static IAdGradeService adGradeService;
	private static IAdBasicInfoService adBasicInfoService;
	private static IAdLecturerInfoService adLecturerInfoService;
	
	private static Scanner scan;
	
	static {
		administratorView = new AdministratorView();
		administratorBasicInfoView = new AdministratorBasicInfoView(); // TODO 추가
		
		adCourseService = new AdCourseService();
		adStudentService = new AdStudentService();
		adAttendanceService = new AdAttendanceService();
		adRecommendationService = new AdRecommendationService();
		adGradeService = new AdGradeService();
		adBasicInfoService = new AdBasicInfoService();
		adLecturerInfoService = new AdLecturerInfoService();
		
		scan = new Scanner(System.in);
	}
	
//=================================================================================================================================
	
	public static void main(String[] args) {

		boolean administratorLoop = true;
		
		while (administratorLoop) {
			
			Cls.clearScreen();
			
			administratorView.begin();
			administratorView.menu();
			String select = scan.nextLine();
			
	//------------------------------------------------------------------------------------------------------
			
			
			if (select.equals("1")) { //기초 정보 관리
							
				boolean adBasicInfoLoop = true;
				
				while (adBasicInfoLoop) {
					
					Cls.clearScreen();
					administratorView.title(AdministratorView.courseMenu);
					
					administratorView.basicInfomenu();
					select = scan.nextLine();

					if (select.equals("1")) { // 과정명 보기
						
						firstCourseName();

					} else if (select.equals("2")) { // 과목명 보기
						
						secondSubjectName();
						
					} else if (select.equals("3")) { // 강의실명 보기
						
						ThirdClassRoom();
						
					} else if (select.equals("4")) { // 교재명 보기
						
						FourthTextBook();
						
					} else if (select.equals("0")) { // 돌아가기

						System.out.println("이전 화면으로 돌아갑니다");
						adBasicInfoLoop = false;
						administratorView.menu();

					} else {
						
						System.out.println("다시 입력해 주세요");
						continue;
					}
					
				}//While : adBasicInfoLoop		
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("2")) { //교사 계정 관리
								
				boolean adLecturerInfoLoop = true;
				
				while (adLecturerInfoLoop) {
					
					administratorView.basicInfomenu();
					select = scan.nextLine();
				
					if(select.equals("1")) {  //교사 추가하기
						
						adBasicInfoService.addLecturer();   //교사 추가
						
					} else if(select.equals("2")) {//교사 정보 조회
						
						detailLecturerInfo();
						
					} else if(select.equals("0")) {
						
						System.out.println("이전 화면으로 돌아갑니다");
						adLecturerInfoLoop = false;
						continue;
						
					}
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("3")) { //개설 과정 관리
										
				boolean adCourseLoop = true;
				
				while (adCourseLoop) {
					
					Cls.clearScreen();
					administratorView.courseManagement();
					
					select = scan.nextLine();
					
					//개설 과정 신규 등록
					if (select.equals("1")) adCourseAdd();
					
					//개설 과정 수정
					else if (select.equals("2")) adCourseEdit();
						
					//개설 과정 삭제
					else if (select.equals("3")) adCourseDelete();
						
					//개설 과정 조회
					else if (select.equals("4")) adCourseInfo(); 
						
					//이전 메뉴로 돌아가기
					else if (select.equals("0")) adCourseLoop = false; 
						
					//그 외
					else System.out.println("\t\t\t\t잘못된 입력입니다");						
					
				}//While : adCourseLoop	
								
	//------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("4")) { //교육생 관리
								
				boolean adStudentLoop = true;
				
				while (adStudentLoop) {
					
					//administratorView.menuAdStudent();
					
					String sel = scan.nextLine();
					if (sel.equals("1")) {
						
						//studentService.studentAdd();
						
					}
						
					else if (sel.equals("2")) {
						
						boolean bool = true;
						
						while(bool) {

							//administratorView.menuManageStudent();
							
							String p = scan.nextLine();
							if (p.equals("1")) {
								
								//studentService.searchByName();
								
							}
							
							else if (p.equals("2")) {
								
								//studentService.searchByCourse();
								
							}
						}
						
					} else adStudentLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("5")) { //성적 관리
							
				boolean adGradeLoop = true;
				
				while (adGradeLoop) {
					
					//administratorView.menuGrade();
					
					String pick = scan.nextLine();
					
					if (pick.equals("1")) {
						
						//gradeService.gradeByCourse();
						
					}
					
					else if (pick.equals("2")) {
						
						//gradeService.gradeByName();
						
					}
					
					else adGradeLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("6")) { //출결 관리
								
				boolean adAttendanceLoop = true;
				
				while (adAttendanceLoop) {
					
					administratorView.menuAttendance();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
						
						boolean p = true;
						
						while(p) {
							
							administratorView.menuCourse();
							
							select = scan.nextLine();
							
							if(select.equals("1")) {
								adAttendanceService.fullAttendance();
							} else if (select.equals("2")) {
								adAttendanceService.attendanceByMonth();
							} else {
								p = false;
							}
						}
					}
					
					else if (select.equals("0")) adAttendanceLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("7")) { //추천서 관리
								
				boolean adRecommendationLoop = true;
				
				while (adRecommendationLoop) {
					
					administratorView.title(AdministratorView.RECOMMENDATION);
					adRecommendationService.recommendation();
					
				}	
				
	//------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("0")) { //로그아웃
								
				administratorLoop = false;	
				
				Cls.clearScreen();
				
			}
			
		}//While : administratorLoop
		
	}//Method : main

//=================================================================================================================================	

	private static void detailLecturerInfo() {

		boolean detailLecturerInfo = true;
		
		while (detailLecturerInfo) {
			adBasicInfoService.lecturerInfo();
			String select = scan.nextLine();

			if (select.equals("교사번호")) {
				detailLecturer(); // 교사 세부사항

			} else if (select.equals("0")) {

				System.out.println("돌아가기");
				administratorView.lecturerBasicInfomenu();
			}
		}

	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void detailLecturer() {

		boolean detailLecturer = true;

		while (detailLecturer) {
			adBasicInfoService.detailLecturer();
			administratorView.lecturerBasicInfoUpdate();
			String select = scan.nextLine();

			if (select.equals("*")) {
				updateLecturer();
			} else if (select.equals("#")) {
				// 담당 강의 확인 호출
			} else if (select.equals("0")) {
				administratorView.lecturerBasicInfomenu();

			}
			
		}
		
	}
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void updateLecturer() {
		boolean updateLecturer = true;

		while (updateLecturer) {
			
			adBasicInfoService.detailLecturer();  //교사 세부사항 
			administratorView.lecturerBasicInfoSelect();
			
			String select = scan.nextLine();
			
			if(select.equals("1")) {
				
				adBasicInfoService.updateLecturerName();
				
			}else if(select.equals("2")) {
				
				adBasicInfoService.updateLecturerReg();
				
			}else if(select.equals("3")) {
				
				adBasicInfoService.updateLecturerTel();
				
			}else if(select.equals("4")) {
				
				adBasicInfoService.updateLecturerSubject();
				
			}else if(select.equals("0")) {
				
				administratorView.lecturerBasicInfoSelect();
				
			}
		
		}
	}
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void FourthTextBook() { // 교재 선택
		
		Cls.clearScreen();
		boolean textBook = true;
		
		while (textBook) {
			
			adBasicInfoService.textBook();
			String select = scan.nextLine();

			if (select.equals("*")) {
				textBookUpdate(); // 교재 추가 수정 삭제
				
			} else if (select.equals("0")) {
				
				System.out.print("\t이전화면으로 돌아갑니다.");
				
				textBook = false;
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void textBookUpdate() { // 교재 수정 추가 삭제
		
		
		boolean textBookUpdate = true;

		while (textBookUpdate) {
			
			administratorView.title(AdministratorView.textBook); //TODO title 추가
			 
			administratorView.textBookMenu();
			String select = scan.nextLine(); //TODO adBasicInfoService.textBookMenu() 삭제
			
			if (select.equals("1")) {
				
				selectContent();	//TODO selectContent 메소드 추가
				
			} else if (select.equals("2")) {
				
				adBasicInfoService.deletetextBook();
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				textBookUpdate = false;
				
			} else {
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
	}

	//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void selectContent() { 				//TODO selectContent 메소드 추가
	
		boolean selectContent = true;
		
		while (selectContent) {
			
			administratorBasicInfoView.textbookContentSelect();
			String select = scan.nextLine();
			
			if (select.equals("1")) {
				
				adBasicInfoService.modifytextBook(); //TODO interface IAdBasicInfoService 추가
							
			} else if (select.equals("2")) {
				
				adBasicInfoService.modifypublisher();  //TODO interface IAdBasicInfoService 추가
													   //TODO DAO AdBasicInfoService 추가
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				selectContent = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
			
		}
		
}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void ThirdClassRoom() {
		

		Cls.clearScreen();
		boolean basicClassRoom = true;
		
		while (basicClassRoom) {
			
			adBasicInfoService.classRoom();
			String select = scan.nextLine();

			if (select.equals("*")) {
				
				adBasicInfoService.modifyClassRoomName();
				
			} else if (select.equals("#")) {
				
				adBasicInfoService.modifyclassRoomNum();
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				basicClassRoom = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
		}
		
	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void secondSubjectName() { // 과목명선택 메소드
		
		Cls.clearScreen();
		boolean basicSubjectName = true;
		
		while (basicSubjectName) {
			
			adBasicInfoService.subjectName();
			String select = scan.nextLine();

			if (select.equals("*")) { 
			
				subjectInDeUp();	
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				basicSubjectName = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void subjectInDeUp() { // 과목명 추가 수정 삭제 메소드

		boolean subjectUpdate = true;

		while (subjectUpdate) {
			
			administratorView.title(AdministratorView.subjectNameInMoDe); //TODO title 추가
			
			administratorView.subjectNameMenu();  //TODO 메소드명 수정 courseNameMenu-> subjectNameMenu

			String select = scan.nextLine();

			if (select.equals("1")) {
				adBasicInfoService.insertSubject();
			} else if (select.equals("2")) {
				adBasicInfoService.modifySubject();
			} else if (select.equals("3")) {
				adBasicInfoService.deleteSubject();
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				subjectUpdate = false;			
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void firstCourseName() {

		Cls.clearScreen();
		boolean basicCourseName = true;

		while (basicCourseName) {
			
			adBasicInfoService.basicCourseList(); // TODO 메소드명 변경 -> basicCourseList, Interface 추가
			
			String select = scan.nextLine();

			if (select.equals("*")) { // 과정 추가 삭제 수정
				
				courseInDeUp(); // 과정 추가삭제수정 메소드
				
			} else if (select.equals("0")) { // 돌아가기
				
				System.out.println("\t이전 화면으로 돌아갑니다");
				
				basicCourseName = false;

			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
		
	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void courseInDeUp() {   // 과정 추가삭제수정 메소드
		
		 Cls.clearScreen();
		 boolean courseUpdate = true;

		 while (courseUpdate) {
			 
			 administratorView.title(AdministratorView.courseNameInMoDe); //TODO title 추가
			 
			 administratorView.courseNameMenu();
			 String select = scan.nextLine();
			 
			if(select.equals("1")) {
				
				adBasicInfoService.insertCourseName();
				
			}else if(select.equals("2")) {
				
				adBasicInfoService.modifyCourseName();
				
			}else if(select.equals("3")) {
				
				adBasicInfoService.deleteCourseName();
				
			} else if (select.equals("0")) { // 돌아가기
				
				System.out.println("\t이전 화면으로 돌아갑니다");
			
				courseUpdate = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
	
	}
	
//=================================================================================================================================


//과정 관리
//=================================================================================================================================
	
	//과정 추가 메소드
	private static void adCourseAdd() {
		
		adCourseService.courseAdd();
		
	}//method : adCourseAdd
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	//과정 수정 메소드
	private static void adCourseEdit() { 
		
		adCourseService.courseEdit();
		
	}//method : adCourseEdit
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	//과정 삭제 메소드
	private static void adCourseDelete() {
		
		adCourseService.courseDelete();
		
	}//method : adCourseDelete
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	//과정 조회 메소드
	private static void adCourseInfo() {
		
		adCourseService.courseList();
		
	}//method : adCourseInfo
	
//=================================================================================================================================	
	
}//Class : AdministratorController


