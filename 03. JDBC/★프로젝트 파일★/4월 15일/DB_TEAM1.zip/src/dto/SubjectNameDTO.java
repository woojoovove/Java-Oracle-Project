package dto;

public class SubjectNameDTO {
	
	private String seq;
	private String name;
	private String subjectTypeSeq;
	private String state;
	
//------------------------------------------------------------
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getSubjectTypeSeq() {
		return subjectTypeSeq;
	}
	public void setSubjectTypeSeq(String subjectTypeSeq) {
		this.subjectTypeSeq = subjectTypeSeq;
	}
	
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
