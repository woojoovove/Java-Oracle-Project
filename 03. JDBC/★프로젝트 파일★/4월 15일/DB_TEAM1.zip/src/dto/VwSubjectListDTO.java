package dto;

public class VwSubjectListDTO {
	
	private String vCourseNum;
	private String vCourseName;
	private String vCourseStart;
	private String vCourseEnd;
	private String vSubjectNum;
	private String vSubjectName;
	private String vTextBookname;
	private String vWrittenPercent;
	private String vPracticalPercent;
	private String vAttendancePercent;
	
//--------------------------------------------------------------	
	
	public String getvCourseNum() {
		return vCourseNum;
	}
	public void setvCourseNum(String vCourseNum) {
		this.vCourseNum = vCourseNum;
	}
	public String getvCourseName() {
		return vCourseName;
	}
	public void setvCourseName(String vCourseName) {
		this.vCourseName = vCourseName;
	}
	public String getvCourseStart() {
		return vCourseStart;
	}
	public void setvCourseStart(String vCourseStart) {
		this.vCourseStart = vCourseStart;
	}
	public String getvCourseEnd() {
		return vCourseEnd;
	}
	public void setvCourseEnd(String vCourseEnd) {
		this.vCourseEnd = vCourseEnd;
	}
	public String getvSubjectNum() {
		return vSubjectNum;
	}
	public void setvSubjectNum(String vSubjectNum) {
		this.vSubjectNum = vSubjectNum;
	}
	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
	public String getvTextBookname() {
		return vTextBookname;
	}
	public void setvTextBookname(String vTextBookname) {
		this.vTextBookname = vTextBookname;
	}
	public String getvWrittenPercent() {
		return vWrittenPercent;
	}
	public void setvWrittenPercent(String vWrittenPercent) {
		this.vWrittenPercent = vWrittenPercent;
	}
	public String getvPracticalPercent() {
		return vPracticalPercent;
	}
	public void setvPracticalPercent(String vPracticalPercent) {
		this.vPracticalPercent = vPracticalPercent;
	}
	public String getvAttendancePercent() {
		return vAttendancePercent;
	}
	public void setvAttendancePercent(String vAttendancePercent) {
		this.vAttendancePercent = vAttendancePercent;
	}
	
}
