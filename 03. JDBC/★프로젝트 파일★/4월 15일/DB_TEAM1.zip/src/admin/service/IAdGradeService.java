package admin.service;

public interface IAdGradeService {

}
