package lecturer.service;

public class LePercentService implements ILePercentService{

	@Override
	public void course() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperquizadd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperquizdel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperdateadd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperdatedel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperadd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lepermodify() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leperdel() {
		// TODO Auto-generated method stub
		
	}

}
