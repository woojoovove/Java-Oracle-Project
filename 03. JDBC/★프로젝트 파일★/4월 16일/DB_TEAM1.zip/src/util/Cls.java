package util;

public class Cls {
	
	public static void clearScreen() {
		
		for (int i = 0; i < 50; i++) {
			System.out.println("");
		}
		System.out.println("\t\t\t\t\tLOADING.....");
		try {
			Thread.sleep(700);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < 50; i++) {
			System.out.println("");
		}
		
	}
	
}
