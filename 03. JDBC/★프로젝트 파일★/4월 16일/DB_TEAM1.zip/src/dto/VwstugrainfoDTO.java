package dto;

public class VwstugrainfoDTO {
	
	private String vstuname;
	private String vstuseq;
	private String vgrawri;
	private String vgraprac;
	private String vgraseq;
	private String vgrasubseq;
	
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	}
	public String getVgrawri() {
		return vgrawri;
	}
	public void setVgrawri(String vgrawri) {
		this.vgrawri = vgrawri;
	}
	public String getVgraprac() {
		return vgraprac;
	}
	public void setVgraprac(String vgraprac) {
		this.vgraprac = vgraprac;
	}
	public String getVgraseq() {
		return vgraseq;
	}
	public void setVgraseq(String vgraseq) {
		this.vgraseq = vgraseq;
	}
	public String getVgrasubseq() {
		return vgrasubseq;
	}
	public void setVgrasubseq(String vgrasubseq) {
		this.vgrasubseq = vgrasubseq;
	}
	
	
	
}
