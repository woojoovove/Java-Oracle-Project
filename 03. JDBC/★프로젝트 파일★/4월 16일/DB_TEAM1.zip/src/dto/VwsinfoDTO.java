package dto;

public class VwsinfoDTO {

	
	private String vstuname; 
	private String vstupnum; 
	private String vstustatus; 
	private String vstuseq;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVstustatus() {
		return vstustatus;
	}
	public void setVstustatus(String vstustatus) {
		this.vstustatus = vstustatus;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	} 
	
	
	
}
