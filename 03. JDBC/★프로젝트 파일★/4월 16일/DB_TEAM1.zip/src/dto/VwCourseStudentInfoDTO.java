package dto;

public class VwCourseStudentInfoDTO {

	private String vCourseSeq;
	private String vName;
	private String vRegistrationNum;
	private String vPhoneNum;
	private String vRegistrationDate;
	private String vState;
	
//------------------------------------------------------------------
	
	public String getvCourseSeq() {
		return vCourseSeq;
	}
	public void setvCourseSeq(String vCourseSeq) {
		this.vCourseSeq = vCourseSeq;
	}
	public String getvName() {
		return vName;
	}
	public void setvName(String vName) {
		this.vName = vName;
	}
	public String getvRegistrationNum() {
		return vRegistrationNum;
	}
	public void setvRegistrationNum(String vRegistrationNum) {
		this.vRegistrationNum = vRegistrationNum;
	}
	public String getvPhoneNum() {
		return vPhoneNum;
	}
	public void setvPhoneNum(String vPhoneNum) {
		this.vPhoneNum = vPhoneNum;
	}
	public String getvRegistrationDate() {
		return vRegistrationDate;
	}
	public void setvRegistrationDate(String vRegistrationDate) {
		this.vRegistrationDate = vRegistrationDate;
	}
	public String getvState() {
		return vState;
	}
	public void setvState(String vState) {
		this.vState = vState;
	}	
	
}
