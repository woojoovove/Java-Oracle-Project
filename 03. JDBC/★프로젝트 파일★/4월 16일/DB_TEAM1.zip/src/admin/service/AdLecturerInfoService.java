package admin.service;

public class AdLecturerInfoService implements IAdLecturerInfoService {

}
