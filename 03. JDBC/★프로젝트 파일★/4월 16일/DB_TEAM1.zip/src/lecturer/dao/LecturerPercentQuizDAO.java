package lecturer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.SubjectDTO;
import dto.VwCourseEditInfoDTO;
import dto.VwCourseInfoDTO;
import dto.VwCourseSubjectListDTO;
import dto.VwSubjectPercentQuizDTO;
import util.DBUtil;

public class LecturerPercentQuizDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public LecturerPercentQuizDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : AdministratorDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close

	
	
//과정, 과목 목록
//=====================================================================================================================================
	
	//과정 목록
	public ArrayList<String> courseList(String lecturerSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseLecturerSeq\" = %s", lecturerSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseEditInfoDTO> courseEditList = new ArrayList<VwCourseEditInfoDTO>();
			
			while (rs.next()) {				
				VwCourseEditInfoDTO courseEditInfoDto = new VwCourseEditInfoDTO();
				
				courseEditInfoDto.setvCourseNum(rs.getString("vCourseNum"));
				courseEditInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseEditInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseEditInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseEditInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				courseEditInfoDto.setvCourseLecturer(rs.getString("vCourseLecturer"));
				
				courseEditList.add(courseEditInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseEditInfoDTO courseEditInfoDto : courseEditList) {
				tempList.add(
					"\t과정번호\t[" + courseEditInfoDto.getvCourseNum() + "]"
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정명\t\t" + courseEditInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseEditInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseEditInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseEditInfoDto.getvCourseClassroom()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t교사\t\t" + courseEditInfoDto.getvCourseLecturer()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : courseList
	
	
	//선택한 과정의 이름
	public String selectCourseListName(String vCourseNum) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", vCourseNum);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vCourseName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseListName

//--------------------------------------------------------------------------------------------------------------------------------
	
	//과목 목록
	public ArrayList<String> subjectList(String vCourseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s "
											+ "AND \"vSubjectEnd\" < SYSDATE AND state = 1", vCourseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseSubjectListDTO> courseSubjectList = new ArrayList<VwCourseSubjectListDTO>();
			
			while (rs.next()) {				
				VwCourseSubjectListDTO courseSubjectListDTO = new VwCourseSubjectListDTO();
				
				courseSubjectListDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				courseSubjectListDTO.setvSubjectName(rs.getString("vSubjectName"));	
				courseSubjectListDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				courseSubjectListDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				
				courseSubjectList.add(courseSubjectListDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseSubjectListDTO courseSubjectListDTO : courseSubjectList) {
				tempList.add(
						"\n\t=========================================================================="
						+ "\n\t과목번호\t[" + courseSubjectListDTO.getvSubjectSeq() + "]"
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목명\t\t" + courseSubjectListDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목기간\t" + courseSubjectListDTO.getvSubjectStart().substring(0, 10) + " ~ "
												+ courseSubjectListDTO.getvSubjectEnd().substring(0, 10)
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectList

	
	//선택한 과목의 이름
	public String selectSubjectListName(String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vSubjectSeq\" = %s", subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("vSubjectName");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectSubjectListName

	
	//선택한 과목의 배점정보, 시험정보
	public ArrayList<String> subjectPercentQuiz(String vCourseNum, String vSubjectNum) {
		
		try {
			
			String sql = String.format("SELECT DISTINCT vSubjectName, vWrittenPercent, vPracticalPercent, "
											+ "vAttendancePercent, vQuizDate FROM vwSubjectPercentQuiz "
												+ "WHERE vCourseNum = 1 AND vsubjectnum = 3", vCourseNum,vSubjectNum);
			
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwSubjectPercentQuizDTO> subjectPercentQuizList = new ArrayList<VwSubjectPercentQuizDTO>();
			
			while (rs.next()) {				
				VwSubjectPercentQuizDTO subjectPercentQuizDTO = new VwSubjectPercentQuizDTO();
				
				subjectPercentQuizDTO.setvSubjectName(rs.getString("vSubjectName"));
				subjectPercentQuizDTO.setvWrittenPercent(rs.getString("vWrittenPercent"));
				subjectPercentQuizDTO.setvPracticalPercent(rs.getString("vPracticalPercent"));
				subjectPercentQuizDTO.setvAttendancePercent(rs.getString("vAttendancePercent"));
				subjectPercentQuizDTO.setvQuizDate(rs.getString("vQuizDate"));
				
				subjectPercentQuizList.add(subjectPercentQuizDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwSubjectPercentQuizDTO subjectPercentQuizDTO : subjectPercentQuizList) {
				
				String quizNull, writtenNull, practicalNull, attendanceNull;
				
				if(subjectPercentQuizDTO.getvWrittenPercent() == null) writtenNull = "X";
				else writtenNull = subjectPercentQuizDTO.getvWrittenPercent();
				
				if(subjectPercentQuizDTO.getvPracticalPercent() == null) practicalNull = "X";
				else practicalNull = subjectPercentQuizDTO.getvPracticalPercent();
				
				if(subjectPercentQuizDTO.getvAttendancePercent() == null) attendanceNull = "X";
				else attendanceNull = subjectPercentQuizDTO.getvAttendancePercent();
				
				if(subjectPercentQuizDTO.getvQuizDate() == null) quizNull = "시험날짜가 입력되지 않음";
				else quizNull = subjectPercentQuizDTO.getvQuizDate();
				
				tempList.add(
						"\t과목명\t\t" + subjectPercentQuizDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t배점\t\t필기" + writtenNull + "\t실기" + practicalNull + "\t출결" + attendanceNull
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t시험날짜\t" + quizNull
						+ "\n\t==========================================================================\n");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectPercentQuiz

//=====================================================================================================================================
	
	
	
//배점 관리	
//=====================================================================================================================================
	
	//배점 입력
	public int percentAdd(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET writtenPercent = ?, practicalPercent = ?, attendancePercent = ? "
						+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : percentAdd

	
	//배점 수정
	public int percentEdit(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET writtenPercent = ?, practicalPercent = ?, attendancePercent = ? "
				+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : percentEdit

	
	
	//배점 삭제
	public int percentDelete(SubjectDTO subjectDTO) {

		String sql = "UPDATE tblSubject SET writtenPercent = NULL, practicalPercent = NULL, attendancePercent = NULL "
				+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : method : percentDelete
	
//--------------------------------------------------------------------------------------------------------------------------------

	//시험 관리
	
	
	
	
	
	
	
	
	
	
	
	
//=====================================================================================================================================

}//Class : LecturerPercentDAO


