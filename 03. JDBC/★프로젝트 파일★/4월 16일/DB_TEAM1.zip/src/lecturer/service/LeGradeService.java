package lecturer.service;

public class LeGradeService implements ILeGradeService{

	@Override
	public void allsubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void student(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int alleachstudent(String nextLine) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void written() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void practical() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int eachstudent(String nextLine) {
		// TODO Auto-generated method stub
		return 0;
	}

}
