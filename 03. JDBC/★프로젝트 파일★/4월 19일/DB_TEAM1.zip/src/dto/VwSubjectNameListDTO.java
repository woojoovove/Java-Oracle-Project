package dto;

public class VwSubjectNameListDTO {
	private String vsubjectSeq;
    private String vsubjectName;
	
    
    public String getVsubjectSeq() {
		return vsubjectSeq;
	}
	public void setVsubjectSeq(String vsubjectSeq) {
		this.vsubjectSeq = vsubjectSeq;
	}
	public String getVsubjectName() {
		return vsubjectName;
	}
	public void setVsubjectName(String vsubjectName) {
		this.vsubjectName = vsubjectName;
	}
    
    
}
