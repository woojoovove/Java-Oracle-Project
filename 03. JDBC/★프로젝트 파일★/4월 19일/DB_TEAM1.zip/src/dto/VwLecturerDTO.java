package dto;

public class VwLecturerDTO {

	private String vlecturerSeq;
	private String vlecturerName;
	private String vlecturerRegistrationNum;
	private String vlecturerPhoneNum;
	private String vsubjectName;
	private String VsubjectSeq;
	
	public String getVlecturerSeq() {
		return vlecturerSeq;
	}
	public void setVlecturerSeq(String vlecturerSeq) {
		this.vlecturerSeq = vlecturerSeq;
	}
	public String getVlecturerName() {
		return vlecturerName;
	}
	public void setVlecturerName(String vlecturerName) {
		this.vlecturerName = vlecturerName;
	}
	public String getVlecturerRegistrationNum() {
		return vlecturerRegistrationNum;
	}
	public void setVlecturerRegistrationNum(String vlecturerRegistrationNum) {
		this.vlecturerRegistrationNum = vlecturerRegistrationNum;
	}
	public String getVlecturerPhoneNum() {
		return vlecturerPhoneNum;
	}
	public void setVlecturerPhoneNum(String vlecturerPhoneNum) {
		this.vlecturerPhoneNum = vlecturerPhoneNum;
	}
	public String getVsubjectName() {
		return vsubjectName;
	}
	public void setVsubjectName(String vsubjectName) {
		this.vsubjectName = vsubjectName;
	}
	public String getVsubjectSeq() {
		return VsubjectSeq;
	}
	public void setVsubjectSeq(String vsubjectSeq) {
		VsubjectSeq = vsubjectSeq;
	}

}
