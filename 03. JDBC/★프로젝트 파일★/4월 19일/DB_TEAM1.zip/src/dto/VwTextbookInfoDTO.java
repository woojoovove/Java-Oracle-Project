package dto;

public class VwTextbookInfoDTO {
	
	private String vTextbookSeq;
	private String vTextbookName;
	private String vPublisher;
	private String vTextbookState;
	
//-----------------------------------------------------------	
	
	public String getvTextbookSeq() {
		return vTextbookSeq;
	}
	public void setvTextbookSeq(String vTextbookSeq) {
		this.vTextbookSeq = vTextbookSeq;
	}
	public String getvTextbookName() {
		return vTextbookName;
	}
	public void setvTextbookName(String vTextbookName) {
		this.vTextbookName = vTextbookName;
	}
	public String getvPublisher() {
		return vPublisher;
	}
	public void setvPublisher(String vPublisher) {
		this.vPublisher = vPublisher;
	}
	public String getvTextbookState() {
		return vTextbookState;
	}
	public void setvTextbookState(String vTextbookState) {
		this.vTextbookState = vTextbookState;
	}

	
}
