package dto;

public class VwStudentCountDTO {

	private String vtotalcount;

	public String getVtotalcount() {
		return vtotalcount;
	}

	public void setVtotalcount(String vtotalcount) {
		this.vtotalcount = vtotalcount;
	}
	
	
}
