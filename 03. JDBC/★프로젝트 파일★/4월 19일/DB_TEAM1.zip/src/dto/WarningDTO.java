package dto;

public class WarningDTO {

	
	private String STUDENTSEQ;
	private String STUDENTNAME;
	private String ATTENDANCEGRADE;
	private String COURSESEQ;
	private String COURSENAME;
	private String LECTURERSEQ;
	public String getLECTURERSEQ() {
		return LECTURERSEQ;
	}
	public void setLECTURERSEQ(String lECTURERSEQ) {
		LECTURERSEQ = lECTURERSEQ;
	}
	private String LECTURERNAME;
	
	public String getSTUDENTSEQ() {
		return STUDENTSEQ;
	}
	public void setSTUDENTSEQ(String sTUDENTSEQ) {
		STUDENTSEQ = sTUDENTSEQ;
	}
	public String getSTUDENTNAME() {
		return STUDENTNAME;
	}
	public void setSTUDENTNAME(String sTUDENTNAME) {
		STUDENTNAME = sTUDENTNAME;
	}
	public String getATTENDANCEGRADE() {
		return ATTENDANCEGRADE;
	}
	public void setATTENDANCEGRADE(String aTTENDANCEGRADE) {
		ATTENDANCEGRADE = aTTENDANCEGRADE;
	}
	public String getCOURSESEQ() {
		return COURSESEQ;
	}
	public void setCOURSESEQ(String cOURSESEQ) {
		COURSESEQ = cOURSESEQ;
	}
	public String getCOURSENAME() {
		return COURSENAME;
	}
	public void setCOURSENAME(String cOURSENAME) {
		COURSENAME = cOURSENAME;
	}
	public String getLECTURERNAME() {
		return LECTURERNAME;
	}
	public void setLECTURERNAME(String lECTURERNAME) {
		LECTURERNAME = lECTURERNAME;
	}
	
	
}
