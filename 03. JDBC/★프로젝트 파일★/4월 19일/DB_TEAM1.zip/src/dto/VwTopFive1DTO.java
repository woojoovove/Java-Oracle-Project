package dto;

public class VwTopFive1DTO {

	private String vseq;
	private String vname;
	private String vphonenum;
	private String vregistrationdate;
	private String vtotal;
	private String vadminconfirm;
	private String vlecturerrecommendation;
	private String vstudentSeq;
	private String vranking;
	private String vlename;
	private String vcoursename;
	private String vstart;
	private String vend;
	private String vcourseseq;
	private String vdate;
	private String vrank;
	
//-------------------------------------------------------------------	
	
	public String getVrank() {
		return vrank;
	}
	public void setVrank(String vrank) {
		this.vrank = vrank;
	}
	public String getVdate() {
		return vdate;
	}
	public void setVdate(String vdate) {
		this.vdate = vdate;
	}
	public String getVcourseseq() {
		return vcourseseq;
	}
	public void setVcourseseq(String vcourseseq) {
		this.vcourseseq = vcourseseq;
	}
	public String getVstart() {
		return vstart;
	}
	public void setVstart(String vstart) {
		this.vstart = vstart;
	}
	public String getVend() {
		return vend;
	}
	public void setVend(String vend) {
		this.vend = vend;
	}
	public String getVcoursename() {
		return vcoursename;
	}
	public void setVcoursename(String vcoursename) {
		this.vcoursename = vcoursename;
	}
	public String getVseq() {
		return vseq;
	}
	public void setVseq(String vseq) {
		this.vseq = vseq;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVphonenum() {
		return vphonenum;
	}
	public void setVphonenum(String vphonenum) {
		this.vphonenum = vphonenum;
	}
	public String getVregistrationdate() {
		return vregistrationdate;
	}
	public void setVregistrationdate(String vregistrationdate) {
		this.vregistrationdate = vregistrationdate;
	}
	public String getVtotal() {
		return vtotal;
	}
	public void setVtotal(String vtotal) {
		this.vtotal = vtotal;
	}
	public String getVadminconfirm() {
		return vadminconfirm;
	}
	public void setVadminconfirm(String vadminconfirm) {
		this.vadminconfirm = vadminconfirm;
	}
	public String getVlecturerrecommendation() {
		return vlecturerrecommendation;
	}
	public void setVlecturerrecommendation(String vlecturerrecommendation) {
		this.vlecturerrecommendation = vlecturerrecommendation;
	}
	public String getVstudentSeq() {
		return vstudentSeq;
	}
	public void setVstudentSeq(String vstudentSeq) {
		this.vstudentSeq = vstudentSeq;
	}
	public String getVranking() {
		return vranking;
	}
	public void setVranking(String vranking) {
		this.vranking = vranking;
	}
	public String getVlename() {
		return vlename;
	}
	public void setVlename(String vlename) {
		this.vlename = vlename;
	}

	
	
}	