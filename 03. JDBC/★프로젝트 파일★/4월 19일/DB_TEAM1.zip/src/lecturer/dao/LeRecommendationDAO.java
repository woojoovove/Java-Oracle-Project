package lecturer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwTopFive1DTO;
import util.DBUtil;

public class LeRecommendationDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public LeRecommendationDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : LeRecommendationDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close

//=====================================================================================================================================
	
	public ArrayList<VwTopFive1DTO> leRecommendation(String rank) {
		
		try {

			String sql = "select * from vwTopFive1 where ranking = ?";
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, rank);
			
			ResultSet rs = pstat.executeQuery();
			
			
		
	
			ArrayList<VwTopFive1DTO> leRecommendation = new ArrayList<VwTopFive1DTO>();
			
			while(rs.next()) {
				
				VwTopFive1DTO dto = new VwTopFive1DTO();
				
				dto.setVname(rs.getString("vname"));
				dto.setVlecturerrecommendation(rs.getString("lecturerrecommendation"));
				dto.setVlename(rs.getString("vlename"));
				dto.setVadminconfirm(rs.getString("adminconfirm"));
				dto.setVcoursename(rs.getString("vcoursename"));
				
				leRecommendation.add(dto);
				
			}
			
			return leRecommendation;
			
			
		
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}

		
		return null;
		
	}

//=====================================================================================================================================
	
	public ArrayList<VwTopFive1DTO> recommendationList() {

		try {

			String sql = "select * from vwTopFive1";
			
			ResultSet rs = stat.executeQuery(sql);


			ArrayList<VwTopFive1DTO> recommendationList =  new ArrayList<VwTopFive1DTO>();
			
			
			while(rs.next()) {
				
				VwTopFive1DTO dto = new VwTopFive1DTO();
				
				dto.setVcourseseq(rs.getString("vcourseseq"));
				dto.setVcoursename(rs.getString("vcoursename"));
				dto.setVranking(rs.getString("ranking"));
				dto.setVname(rs.getString("vname"));
				dto.setVphonenum(rs.getString("vphonenum"));
				dto.setVregistrationdate(rs.getString("vregistrationdate"));
				dto.setVtotal(rs.getString("vtotal"));
				dto.setVstart(rs.getString("vstart"));
				dto.setVend(rs.getString("vend"));
				dto.setVadminconfirm(rs.getString("adminconfirm"));
				
				
				recommendationList.add(dto);
			}

			
			return recommendationList;
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return null;
		
	}

//=====================================================================================================================================
	
	public VwTopFive1DTO leRecommendationAddList(String rank) {
		
		
		try {

			
			String sql = "select * from vwTopFive1 where ranking = ?";
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, rank);
			
			
			ResultSet rs = pstat.executeQuery();


			
			VwTopFive1DTO dto =  new VwTopFive1DTO();
			
			
		
			if(rs.next()) {
				
				dto.setVranking(rs.getString("ranking"));
				dto.setVname(rs.getString("vname"));
				dto.setVphonenum(rs.getString("vphonenum"));
				dto.setVregistrationdate(rs.getString("vregistrationdate"));
				dto.setVtotal(rs.getString("vtotal"));
				
				
				return dto;
			
			
			
		}} catch (Exception e) {
			System.out.println(e.toString());
		}
	
		return null;
	}

//=====================================================================================================================================
	
	public int insert(VwTopFive1DTO dto) {
		
	try {
			
			String sql = "update tblrecommendation set  lecturerrecommendation = ?, adminconfirm = ? where ranking = ?";
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, dto.getVlecturerrecommendation());
			pstat.setString(2, dto.getVadminconfirm());
			pstat.setString(3, dto.getVrank());
			
			return pstat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	
		return 0;
		
	}
	
//=====================================================================================================================================	

	public String sysdate() {
		
		try {
	
			String sys = "select * from dual";
			
			pstat = conn.prepareStatement(sys);
			
			ResultSet rs = pstat.executeQuery();
			
			VwTopFive1DTO dto =  new VwTopFive1DTO();
			
			if(rs.next()) {
				dto.setVdate(rs.getString(sys));
			}
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
			
		return null;

	}

}//class : LeRecommendationDAO


