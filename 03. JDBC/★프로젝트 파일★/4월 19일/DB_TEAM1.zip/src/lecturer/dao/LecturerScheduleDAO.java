package lecturer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCountStudentDTO;
import dto.VwCourseDTO;
import dto.VwStudentDTO;
import dto.VwSubjectDTO;
import util.DBUtil;

public class LecturerScheduleDAO {

	private Connection conn;
	private Statement stat;
	@SuppressWarnings("unused")
	private PreparedStatement pstat;



	public LecturerScheduleDAO() {
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("LecturerScheduleDAO.Constructor");
		}	
	}//LecturerScheduleDAO()
//------------------------------------------------------------
	
	public boolean isConnected() {
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}//isConnected()

//--------------------------------------------------------	
	public void close() {
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//close()
//-------------------------------------------------	

	public ArrayList<VwCourseDTO> willcoursecheck() {
		//강의예정 과정정보
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate > sysdate",2);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> detailcoursecheck = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseName(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					detailcoursecheck.add(dto);
					
				}//while
				
			return detailcoursecheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}//willcoursecheck
	


	public ArrayList<VwSubjectDTO> willsubjectcheck() {
		//강의예정 과목정보
		try {
			String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject WHERE vlecturerseq = %s ", 3);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> detailsubjectcheck = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					dto.setvTextbook(rs.getString("vTextbook"));
	
		
					detailsubjectcheck.add(dto);
					
				}//while
				
			return detailsubjectcheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//willsubjectcheck

	
	public ArrayList<VwCourseDTO> progcoursecheck() {
		//강의중 과정정보
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate < sysdate AND VcourseEndDate > sysdate", 3);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> detailcoursecheck = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseSeq(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					detailcoursecheck.add(dto);
					
				}//while
				
			return detailcoursecheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}//progcoursecheck
	
	
	
	public ArrayList<VwCountStudentDTO> progcountcheck() {
		//강의중 과정 등록인원
		try {
			String sql = String.format("SELECT vcount FROM VwCountStudent WHERE vlecturerSeq = %s AND VcourseStartDate < sysdate AND VcourseEndDate > sysdate", 3);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCountStudentDTO> progcountcheck = new ArrayList<VwCountStudentDTO>();
			
				while(rs.next()) {
					
					VwCountStudentDTO dto = new VwCountStudentDTO();
					
					dto.setVcount(rs.getString("vcount"));
					
					progcountcheck.add(dto);
					
				}//while
				
				return progcountcheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}
	
	
	public ArrayList<VwSubjectDTO> progsubjectcheck() {
		//강의중 과목정보
		try {
			String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject WHERE vsubjectStartDate < sysdate AND  vsubjectEndDate > sysdate AND vlecturerseq = %s ", 3);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> detailsubjectcheck = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					dto.setvTextbook(rs.getString("vTextbook"));
	
		
					detailsubjectcheck.add(dto);
					
				}//while
				
			return detailsubjectcheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//willsubjectcheck
	
	
	public ArrayList<VwSubjectDTO> subjectcheck(String selectnum, String inputnum) {
	//선택한 과목정보	
		try {
		
		String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook, vlecturerName FROM VwSubject  WHERE vlecturerseq = %s AND vsubjectSeq= %s", selectnum, inputnum);
		ResultSet rs = stat.executeQuery(sql);

		ArrayList<VwSubjectDTO> subjectcheck = new ArrayList<VwSubjectDTO>();
		
			while(rs.next()) {
				
				VwSubjectDTO dto = new VwSubjectDTO();
				
				dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
				dto.setVsubjectName(rs.getString("vsubjectName"));
				dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
				dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
				dto.setvTextbook(rs.getString("vTextbook"));
				dto.setVlecturerName(rs.getString("vlecturerName"));

				subjectcheck.add(dto);
			}//while	
		return subjectcheck;
		
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}	
	
	
	
	public ArrayList<VwStudentDTO> courseStudent(String selectnum, String inputnum) {
		//강의중 과정 교육생
		try {
			String sql = String.format("SELECT vstudentSeq, vstudentName,  vphoneNum, vregistrationtime, vstudentstatus FROM vwStudent WHERE vcourseSeq = %s ", 3);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwStudentDTO> courseStudent = new ArrayList<VwStudentDTO>();
			
				while(rs.next()) {
					
					VwStudentDTO dto = new VwStudentDTO();
					
					dto.setVstudentSeq(rs.getString("vstudentSeq"));
					dto.setVstudentName(rs.getString("vstudentName"));
					dto.setVphoneNum(rs.getString("vphoneNum"));
					dto.setVregistrationtime(rs.getString("vregistrationtime"));
					dto.setVstudentstatus(rs.getString("vstudentstatus"));
	
		
					courseStudent.add(dto);
					
				}//while
				
			return courseStudent;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//willsubjectcheck
	
	
	
	
}//class










