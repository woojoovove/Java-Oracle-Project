package admin.controller;

import java.util.Scanner;

import admin.service.AdAttendanceService;
import admin.service.AdBasicInfoService;
import admin.service.AdCourseService;
import admin.service.AdGradeService;
import admin.service.AdLecturerInfoService;
import admin.service.AdStudentService;
import admin.service.AdWarningService;
import admin.service.IAdAttendanceService;
import admin.service.IAdBasicInfoService;
import admin.service.IAdCourseService;
import admin.service.IAdLecturerInfoService;
import admin.service.IAdWarningService;
import admin.view.AdminGradeView;
import admin.view.AdminStudentView;
import admin.view.AdministratorAttendanceView;
import admin.view.AdministratorBasicInfoView;
import admin.view.AdministratorCourseView;
import admin.view.AdministratorLecturerManageView;
import admin.view.AdministratorWarningView;
import util.Cls;

public class AdministratorController {

	private static AdministratorCourseView administratorCourseView;
	private static AdminGradeView adminGradeView;
	private static AdminStudentView adminStudentView;
	private static AdministratorAttendanceView administratorAttendanceView;
	private static AdministratorLecturerManageView administratorLecturerManageView;
	private static AdministratorBasicInfoView administratorBasicInfoView;
	private static AdministratorWarningView administratorWarningView;
	
	private static IAdCourseService adCourseService;
	private static IAdAttendanceService adAttendanceService;
	private static IAdBasicInfoService adBasicInfoService;
	private static IAdLecturerInfoService adLecturerInfoService;
	private static IAdWarningService adWarningService;
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
		
		administratorCourseView = new AdministratorCourseView();
		adminGradeView = new AdminGradeView();
		adminStudentView = new AdminStudentView();
		administratorAttendanceView = new AdministratorAttendanceView();
		administratorLecturerManageView = new AdministratorLecturerManageView();
		administratorBasicInfoView = new AdministratorBasicInfoView();
		administratorWarningView = new AdministratorWarningView();
		
		adCourseService = new AdCourseService();
		new AdStudentService();
		adAttendanceService = new AdAttendanceService();
		new AdGradeService();
		adBasicInfoService = new AdBasicInfoService();
		adLecturerInfoService = new AdLecturerInfoService();
		adWarningService = new AdWarningService();
	}
	
//=================================================================================================================================
	
	public static void main() {

		boolean administratorLoop = true;
		
		while (administratorLoop) {
			
			Cls.clearScreen();
			
			administratorCourseView.begin();
			administratorCourseView.menu();
			String select = scan.nextLine();
			
	//------------------------------------------------------------------------------------------------------
			
			if (select.equals("1")) { //기초 정보 관리
							
				boolean adBasicInfoLoop = true;
				
				while (adBasicInfoLoop) {
					
					Cls.clearScreen();
					administratorBasicInfoView.title(AdministratorBasicInfoView.courseMenu);
					
					administratorBasicInfoView.basicInfomenu();
					select = scan.nextLine();

					if (select.equals("1")) { // 과정명 보기
						
						firstCourseName();

					} else if (select.equals("2")) { // 과목명 보기
						
						secondSubjectName();
						
					} else if (select.equals("3")) { // 강의실명 보기
						
						ThirdClassRoom();
						
					} else if (select.equals("4")) { // 교재명 보기
						
						FourthTextBook();
						
					} else if (select.equals("0")) { // 돌아가기

						System.out.println("이전 화면으로 돌아갑니다");
						adBasicInfoLoop = false;
						administratorBasicInfoView.menu();

					} else {
						
						System.out.println("다시 입력해 주세요");
						continue;
					}
					
				}//While : adBasicInfoLoop		
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("2")) { //교사 계정 관리

				boolean adLecturerInfoLoop = true;
				
				while (adLecturerInfoLoop) {
					
					Cls.clearScreen();
					administratorLecturerManageView.lecturerBasicInfomenu();
					
					select = scan.nextLine();
				
					if(select.equals("1")) {  //교사 추가하기
						
						adLecturerInfoService.Lectureradd();   //교사 추가
						
						boolean lectureraddLoop = true;
						while (lectureraddLoop) {
							
							administratorLecturerManageView.plusAddAvlb();
							String select1 = scan.nextLine();
							
							if(select1.contentEquals("+")) {
								
								adLecturerInfoService.subjectadd();
								
							}else if(select1.contentEquals("0")){
								lectureraddLoop = false;
								administratorLecturerManageView.menu();
							}
						
						}
						
					} else if(select.equals("2")) {//교사 정보 조회
						
						detailLecturerInfo();
						
					} else if(select.equals("0")) {
						
						System.out.println("이전 화면으로 돌아갑니다");
						adLecturerInfoLoop = false;
						
					}
					
				}//while : adLecturerInfoLoop
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("3")) { //개설 과정 관리
										
				boolean adCourseLoop = true;
				
				while (adCourseLoop) {
					
					Cls.clearScreen();
					administratorCourseView.courseManagement();
					
					select = scan.nextLine();
					
					//개설 과정 신규 등록
					if (select.equals("1")) adCourseService.courseAdd();
					
					//개설 과정 수정
					else if (select.equals("2")) adCourseService.courseEdit();
						
					//개설 과정 삭제
					else if (select.equals("3")) adCourseService.courseDelete();
						
					//개설 과정 조회
					else if (select.equals("4")) adCourseService.courseList();
						
					//이전 메뉴로 돌아가기
					else if (select.equals("0")) adCourseLoop = false; 
						
					//그 외
					else System.out.println("\t\t\t\t잘못된 입력입니다");						
					
				}//While : adCourseLoop	
								
	//------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("4")) { //교육생 관리
								
				boolean adStudentLoop = true;
				
				while (adStudentLoop) {
					
					Cls.clearScreen();
					adminStudentView.menuAdStudent();
					String sel = scan.nextLine();
					
					if (sel.equals("1")) {
						
						System.out.println("\t'[1] 교육생 등록' 메뉴로 이동합니다.");
						adminStudentView.pressEnter();
						AdStudentService.studentAdd();
							
			//-----------------------------------------------------------------------------------
						
					} else if (sel.equals("2")) {
						
						boolean bool = true;
						
						while(bool) {
							
							System.out.println("\t'[2]' 교육생 정보 관리' 메뉴로 이동합니다.");
							adminStudentView.pressEnter();														
							adminStudentView.menuManageStudent();
						
							String p = scan.nextLine();
							if (p.equals("1")) {
								
								System.out.println("\t'[1]'이름으로 교육생 검색' 메뉴로 이동합니다.");
								adminStudentView.pressEnter();							
								AdStudentService.searchByName();
								
							} else if (p.equals("2")) {
								System.out.println("\t'[2]'과정명으로 교육생 검색' 메뉴로 이동합니다.");
								adminStudentView.pressEnter();								
															
								AdStudentService.searchByCourse();
															
							} else bool=false;
							
						}//while : bool
						
					} else adStudentLoop = false;
					
				}//while : adStudentLoop
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("5")) { //성적 관리
							
				boolean adGradeLoop = true;
				
				while (adGradeLoop) {
					
					Cls.clearScreen();
					adminGradeView.menuGrade();
										
					String pick = scan.nextLine();
					
					if (pick.equals("1")) {
						
						System.out.println("\t과정별 시험 및 성적 관리 메뉴로 이동합니다.");
						AdGradeService.gradeByCourse();
						adminGradeView.pressEnter();
						
					} else if (pick.equals("2")) {
						
						System.out.println("\t교육생별 시험 및 성적 관리 메뉴로 이동합니다.");
						AdGradeService.gradeByName();
						adminGradeView.pressEnter();
						
					} else adGradeLoop = false;
					
				}//while : adGradeLoop
						
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("6")) { //출결 관리
								
				boolean adAttendanceLoop = true;
				
				while (adAttendanceLoop) {
					
					Cls.clearScreen();
					administratorAttendanceView.menuAttendance();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
						
						boolean p = true;
						
						while(p) {
							
							administratorAttendanceView.title(AdministratorAttendanceView.ATTENDANCEBYCOURSE);
							administratorAttendanceView.menuCourse();
							String courseSeq = scan.nextLine();
							administratorAttendanceView.menuCourseSub();
							
							
							select = scan.nextLine();
							
							if(select.equals("1")) {
								adAttendanceService.fullAttendance(courseSeq);
							} else if (select.equals("2")) {
								adAttendanceService.attendanceByMonth(courseSeq);
							} else {
								p = false;
								break;
							}		
						}
					}
					
					else if (select.equals("0")) adAttendanceLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("7")) { //특별 상담 관리
				
				boolean adWarningLoop = true;
				
				while (adWarningLoop) {
					
					Cls.clearScreen();
					administratorWarningView.title(AdministratorWarningView.WARNING);
					administratorWarningView.warningMenu();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
						
						adWarningService.listStudents();
						administratorWarningView.warningSubMenu();
						select = scan.nextLine();
						
						if (select.equals("1")) {
							adWarningService.notifyLecturer();
						}
					} else {
						adWarningLoop = false;
					}
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("0")) { //로그아웃
								
				administratorLoop = false;	
				administratorCourseView.logOut();
				Cls.clearScreen();
				
			}
			
		}//While : administratorLoop
		
	}//Method : main

	
	
//기초 정보 관리	
//=================================================================================================================================	

	private static void firstCourseName() {

		Cls.clearScreen();
		boolean basicCourseName = true;

		while (basicCourseName) {
			
			adBasicInfoService.basicCourseList(); 
			
			String select = scan.nextLine();

			if (select.equals("*")) { // 과정 추가 삭제 수정
				
				courseInDeUp(); // 과정 추가삭제수정 메소드
				
			} else if (select.equals("0")) { // 돌아가기
				
				System.out.println("\t이전 화면으로 돌아갑니다");
				
				basicCourseName = false;

			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
		
	}	
	
//-------------------------------------------------------------------------------------------------
	
	private static void secondSubjectName() { // 과목명선택 메소드
		
		Cls.clearScreen();
		boolean basicSubjectName = true;
		
		while (basicSubjectName) {
			
			adBasicInfoService.subjectName();
			String select = scan.nextLine();

			if (select.equals("*")) { 
			
				subjectInDeUp();	
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				basicSubjectName = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}
	
//-------------------------------------------------------------------------------------------------	
	
	private static void ThirdClassRoom() {
		

		Cls.clearScreen();
		boolean basicClassRoom = true;
		
		while (basicClassRoom) {
			
			adBasicInfoService.classRoom();
			String select = scan.nextLine();

			if (select.equals("*")) {
				
				adBasicInfoService.modifyClassRoomName();
				
			} else if (select.equals("#")) {
				
				adBasicInfoService.modifyclassRoomNum();
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				basicClassRoom = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
		}
		
	}
	
//-------------------------------------------------------------------------------------------------
	
	private static void FourthTextBook() { // 교재 선택
		
		Cls.clearScreen();
		boolean textBook = true;
		
		while (textBook) {
			
			adBasicInfoService.textBook();
			String select = scan.nextLine();

			if (select.equals("*")) {
				textBookUpdate(); // 교재 추가 수정 삭제
				
			} else if (select.equals("0")) {
				
				System.out.print("\t이전화면으로 돌아갑니다.");
				
				textBook = false;
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}
	
//-------------------------------------------------------------------------------------------------
	
	private static void subjectInDeUp() { // 과목명 추가 수정 삭제 메소드

		boolean subjectUpdate = true;

		while (subjectUpdate) {
			
			administratorBasicInfoView.title(AdministratorBasicInfoView.subjectNameInMoDe);
			
			administratorBasicInfoView.subjectNameMenu(); 

			String select = scan.nextLine();

			if (select.equals("1")) {
				adBasicInfoService.insertSubject();
			} else if (select.equals("2")) {
				adBasicInfoService.modifySubject();
			} else if (select.equals("3")) {
				adBasicInfoService.deleteSubject();
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				subjectUpdate = false;			
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}
			
		}

	}
	
//-------------------------------------------------------------------------------------------------
	
	private static void courseInDeUp() {   // 과정 추가삭제수정 메소드
		
		 Cls.clearScreen();
		 boolean courseUpdate = true;

		 while (courseUpdate) {
			 
			 administratorBasicInfoView.title(AdministratorBasicInfoView.courseNameInMoDe);
			 
			 administratorBasicInfoView.courseNameMenu();
			 String select = scan.nextLine();
			 
			if(select.equals("1")) {
				
				adBasicInfoService.insertCourseName();
				
			}else if(select.equals("2")) {
				
				adBasicInfoService.modifyCourseName();
				
			}else if(select.equals("3")) {
				
				adBasicInfoService.deleteCourseName();
				
			} else if (select.equals("0")) { // 돌아가기
				
				System.out.println("\t이전 화면으로 돌아갑니다");
			
				courseUpdate = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
	
	}
	
//-------------------------------------------------------------------------------------------------	
	
	private static void textBookUpdate() { // 교재 수정 추가 삭제
		
		
		boolean textBookUpdate = true;

		while (textBookUpdate) {
			
			administratorBasicInfoView.title(AdministratorBasicInfoView.textBook);
			 
			administratorBasicInfoView.textBookMenu();
			String select = scan.nextLine(); 
			
			if (select.equals("1")) {
				
				selectContent();	
				
			} else if (select.equals("2")) {
				
				adBasicInfoService.deletetextBook();
				
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				//administratorView.basicInfomenu();
				textBookUpdate = false;
				
			} else {
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
			}
			
		}
	}	
	
//-------------------------------------------------------------------------------------------------		

	private static void selectContent() { 		
		
		boolean selectContent = true;
		
		while (selectContent) {
			
			administratorBasicInfoView.textbookContentSelect();
			String select = scan.nextLine();
			
			if (select.equals("1")) {
				
				adBasicInfoService.modifytextBook();
							
			} else if (select.equals("2")) {
				
				adBasicInfoService.modifypublisher(); 
													  
			} else if (select.equals("0")) {
				
				System.out.println("\t이전화면으로 돌아갑니다.");
				selectContent = false;
				
			} else {
				
				System.out.println("\t\t\t\t잘못된 입력입니다");	
				continue;
				
			}	
			
		}
		
	}

//=================================================================================================================================
	


//교사 관리
//=================================================================================================================================
			
	//교사 #003
	private static void detailLecturerInfo() {

		boolean detailLecturerInfo = true;
		
		while (detailLecturerInfo) {
			
			adLecturerInfoService.Lecturerlist();
			
			@SuppressWarnings("unused")
			String select = scan.nextLine();

		}//while	

	}//detailLecturerInfo()
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	public static void detailLecturerInfoend() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하세요");
		System.out.print("\t\t\t\t입력 : ");
		
		String selectnum = scan.nextLine();

		if (!selectnum.equals("0")) {
			
			adLecturerInfoService.detailLecturer(selectnum); // 교사 세부사항

		} else if (selectnum.equals("0")) {

			System.out.println("\t\t\t\t돌아가기");
			administratorLecturerManageView.lecturerBasicInfomenu();
			
		}
		
	}
	
//---------------------------------------------------------------------------------------------------------------------------------
		
	public static  void detailLecturer(String selectnum) {

		boolean detailLecturer = true;

		while (detailLecturer) {

			System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
			System.out.print("\t\t\t\t입력: ");	
			
			String selectq = scan.nextLine();

			if (selectq.equals("*")) {
				administratorLecturerManageView.editchoice(selectnum);
			} else if (selectq.equals("#")) {
				adLecturerInfoService.checkcourse(selectnum);
			} else if (selectq.equals("0")) {
				administratorLecturerManageView.lecturerBasicInfomenu();

			}
			
		}
		
	}	
	
//=================================================================================================================================	
	
}//Class : AdministratorController


