package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.controller.AdministratorController;
import admin.dao.AdLecturerInfoDAO;
import admin.view.AdministratorLecturerManageView;
import dto.VwCourseDTO;
import dto.VwLecturerDTO;
import dto.VwSubjectDTO;
import dto.VwSubjectTypeDTO;

public class AdLecturerInfoService implements IAdLecturerInfoService {

	private static AdministratorLecturerManageView administratorLecturerManageView;
	private static Scanner scan;
	
	public AdLecturerInfoService() {
		administratorLecturerManageView = new AdministratorLecturerManageView();
		scan = new Scanner(System.in);
	}//AdLecturerInfoService()
	
//===============================================================================================================================              
	
	public  void Lectureradd() {
		
		administratorLecturerManageView.title(AdministratorLecturerManageView.ADDLECTURER);
	
		System.out.println(" ");
		System.out.print("\t\t\t\t교사 이름 :  ");
		String name =  scan.nextLine();
		name = name.replace("'", "''");
		
		administratorLecturerManageView.thinLine();
		
		System.out.print("\t\t\t\t주민번호 뒷자리 :  ");
		String ssn = scan.nextLine();
		ssn = ssn.replace("'", "''");
		
		administratorLecturerManageView.thinLine();
		
		System.out.print("\t\t\t\t전화번호 :  ");
		String tel = scan.nextLine();
		tel = tel.replace("'", "''");
		
		administratorLecturerManageView.thinLine();
		
		//tbllecturer에 이름, 주민번호, 전화번호 레코드 추가
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		dao.AdLecturerInfoadd(name, ssn, tel);
		dao.close();
		
		
		System.out.println("\t\t\t\t[강의 가능 과목]");
		
		administratorLecturerManageView.thickLine();
		
			

		//**전체 과목 목록
		
		System.out.println("\t[과목유형번호]\t[과목유형명]");
		administratorLecturerManageView.thickLine();
		
		
		AdLecturerInfoDAO listdao = new AdLecturerInfoDAO();
		ArrayList<VwSubjectTypeDTO> subjectlist = listdao.subjectAllList();
		
		for(VwSubjectTypeDTO dto : subjectlist) {
			
			System.out.printf("\t[%s] ", dto.getvTypeSeq());
			
			System.out.printf("\t%s \n", dto.getvTypeName());
		}
		
		administratorLecturerManageView.addavlbsubject();
		String sbseq = scan.nextLine();

		AdLecturerInfoDAO dao2 = new AdLecturerInfoDAO();
		dao2.AdLeAvlbadd(sbseq);
		dao2.close();
		
		
		
		
		
		
	}//Lectureradd()
	
//===============================================================================================================================
	
	public void subjectadd() {
		administratorLecturerManageView.addavlbsubject();
		String sbseq = scan.nextLine();

		AdLecturerInfoDAO dao2 = new AdLecturerInfoDAO();
		dao2.AdLeAvlbadd(sbseq);
		dao2.close();
	}
	
//===============================================================================================================================
	
	public void Lecturerlist() {
	
		
		administratorLecturerManageView.title(AdministratorLecturerManageView.LECTURERINFO);
		
		
		administratorLecturerManageView.thickLine();
		System.out.println("\t[교사번호]\t[교사이름]\t[주민번호 뒷자리]\t[전화번호]\t\t[강의가능과목]");
		administratorLecturerManageView.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> lecturerinfolist = dao.lecturerinfolist();
		
	//	System.out.println(lecturerinfolist == null);
		
		//rs.next() -> 컬럼값	//재탐색 불가능, 부가 기능 X
		//배열 탐색(컬렉션 탐색) //재탐색 가능, 부가 기능O
		for(VwLecturerDTO dto : lecturerinfolist) {
			System.out.printf("\t[%s] ", dto.getVlecturerSeq());
			
			System.out.printf("\t%s ", dto.getVlecturerName());
			
			System.out.printf("\t%s ", dto.getVlecturerRegistrationNum());
			
			System.out.printf("\t%s ", dto.getVlecturerPhoneNum());
			
			System.out.print("\t세부사항 참조\n");
			
		}
		administratorLecturerManageView.thinLine();
		
		System.out.println("\t\t\t[ ] 안의 번호를 입력하면 해당 교사의 세부사항 페이지로 이동합니다.");
		System.out.println("\t\t\t[0] 돌아가기");
		
		
		dao.close();
		
		AdministratorController.detailLecturerInfoend();
		
	}//Lecturerlist()

//===============================================================================================================================

	//교사목록에서 선택된 번호를 받아와서 세부사항 출력
	public void detailLecturer(String selectnum) {
		administratorLecturerManageView.title(AdministratorLecturerManageView.DETAILLECTURER);
		administratorLecturerManageView.thickLine();
		
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> lecturerinfolist = dao.detailLecturerInfo(selectnum);
		
			
		
		for(VwLecturerDTO dto : lecturerinfolist) {
			System.out.printf("\t[%s]\t%s\t%s\t\t%s\t 세부사항 참조\n"
								, dto.getVlecturerSeq()
								, dto.getVlecturerName()
								, dto.getVlecturerRegistrationNum()
								, dto.getVlecturerPhoneNum());
		}//for	
		dao.close();	
		avlbsubject(selectnum);
		
	}//detailLecturer(String selectnum)

//===============================================================================================================================
	
	//강의가능 과목 출력
	public void avlbsubject(String selectnum) {
		
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> detailinfo = dao.detailLeInfo(selectnum);
		
		System.out.println(" ");
		System.out.print("\t[강의 가능 과목] : ");
		
		
			for(VwLecturerDTO dto2 : detailinfo) {
			
			System.out.printf("%s,", dto2.getVsubjectName());
			}
			
			
			dao.close();
			
			administratorLecturerManageView.avlbSubjectSelect();
			
			AdministratorController.detailLecturer(selectnum);
	}
		
//===============================================================================================================================
	
	//교사-교사이름 수정
	public static void editLecturerName(String selectnum) {
		administratorLecturerManageView.title(AdministratorLecturerManageView.UPDATELECTURERNAME);
		
		//선택된 교사의 기존이름 출력
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> lecturerinfolist = dao.detailLecturerInfo(selectnum);

		for(VwLecturerDTO dto : lecturerinfolist) {
			System.out.printf("\t\t\t\t[기존이름] : %s\n", dto.getVlecturerName());
		}//for	
		
		
		//수정할 교사이름 수정
			System.out.println(" ");
			System.out.print("\t\t\t\t[교사 이름] :  ");
			String name =  scan.nextLine();
			name = name.replace("'", "''");
			
			VwLecturerDTO dto = new VwLecturerDTO();
			dto.setVlecturerName(name);
			
			
			administratorLecturerManageView.thinLine();
			
			int result = dao.editLecturerName(selectnum,  dto);
			
			if(result ==1) {
				System.out.println("\t\t\t\t이름 수정 완료");
			}else {
				System.out.println("\t\t\t\t이름 수정 실패");
			}
			
			System.out.println("");
			administratorLecturerManageView.enterpause( );
			
	}

//===============================================================================================================================
	
	//교사-교사 주민번호 뒷자리 수정
	public static void editLecturerssn(String selectnum) {
		
		administratorLecturerManageView.title(AdministratorLecturerManageView.UPDATELECTURERREG);
		
		//선택된 교사의 기존 주민번호 뒷자리 출력
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> lecturerinfolist = dao.detailLecturerInfo(selectnum);

		for(VwLecturerDTO dto : lecturerinfolist) {
			System.out.printf("\t\t\t\t[기존 주민번호] : %s\n", dto.getVlecturerRegistrationNum());
		}//for	
		
		
		//수정할 교사의 주민번호 뒷자리 입력
			System.out.println(" ");
			System.out.print("\t\t\t\t[수정할 주민번호] :  ");
			String ssn =  scan.nextLine();
			ssn = ssn.replace("'", "''");
			
			VwLecturerDTO dto = new VwLecturerDTO();
			dto.setVlecturerRegistrationNum(ssn);
			
			
			administratorLecturerManageView.thinLine();
			
			int result = dao.editLecturerssn(selectnum,  dto);
			
			if(result ==1) {
				System.out.println("\t\t\t\t주민번호 수정 완료");
			}else {
				System.out.println("\t\t\t\t주민번호 수정 실패");
			}
			
			administratorLecturerManageView.enterpause( );
			
	}
	
//===============================================================================================================================
	
	//교사-교사 전화번호 수정
	public static void editLecturertel(String selectnum) {
		
		administratorLecturerManageView.title(AdministratorLecturerManageView.UPDATELECTURERTEL);
		
		//선택된 교사의 기존 전화번호 출력
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwLecturerDTO> lecturerinfolist = dao.detailLecturerInfo(selectnum);

		for(VwLecturerDTO dto : lecturerinfolist) {
			System.out.printf("\t\t\t\t[기존 전화번호] : %s\n", dto.getVlecturerPhoneNum());
		}//for	
		
		
		//수정할 교사의 전화번호 입력
			System.out.println(" ");
			System.out.print("\t\t\t\t[수정할 전화번호] :  ");
			String tel =  scan.nextLine();
			tel = tel.replace("'", "''");
			
			VwLecturerDTO dto = new VwLecturerDTO();
			dto.setVlecturerPhoneNum(tel);
			
			
			administratorLecturerManageView.thinLine();
			
			int result = dao.editLecturerPhoneNum(selectnum,  dto);
			
			if(result ==1) {
				System.out.println("\t\t\t\t전화번호 수정 완료");
			}else {
				System.out.println("\t\t\t\t전화번호 수정 실패");
			}
			
			administratorLecturerManageView.enterpause( );
			
	}
		
//===============================================================================================================================
	
	//교사-교사 강의가능과목 수정
	//선택된 교사의 기존 강의가능 과목 출력후 선택
	public static void editLeSbChoice(String selectnum) {
		administratorLecturerManageView.title(AdministratorLecturerManageView.UPDATELECTURERSUBJECT );
		System.out.println(" ");
		System.out.println("\t\t\t기존 강의가능 과목유형 중 수정할 과목유형 선택");
		
		administratorLecturerManageView.thickLine();
		System.out.println("\t[과목유형번호]\t[과목유형명]");
		administratorLecturerManageView.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwSubjectTypeDTO> subjectlist = dao.subjectList(selectnum);
		

		for(VwSubjectTypeDTO dto : subjectlist) {
			System.out.printf("\t[%s] ", dto.getvTypeSeq());
			
			System.out.printf("\t%s \n", dto.getvTypeName());
		}
		
		System.out.println("\t\t\t\t수정할 과목유형의 번호를 선택하세요.");
		
		administratorLecturerManageView.thickLine();
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하세요");
		System.out.print("\t\t\t\t입력 : ");
		
		String beforeSeq = scan.nextLine();

		
		AdLecturerInfoService.editLectureravlb(selectnum, beforeSeq);
		
	}//editLeSbChoice(String selectnum)

//===============================================================================================================================
		
	//전체 과목 목록
	public static void editLectureravlb(String selectnum, String beforeSeq) {
		
		//**전체 과목 목록
		administratorLecturerManageView.thickLine();
		System.out.println("\t[과목유형번호]\t[과목유형명]");
		administratorLecturerManageView.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwSubjectTypeDTO> subjectlist = dao.subjectAllList();
		
		for(VwSubjectTypeDTO dto : subjectlist) {
			
			System.out.printf("\t\t[%s] ", dto.getvTypeSeq());
			
			System.out.printf("\t%s \n", dto.getvTypeName());
		}
		
		//수정할 교사의 강의가능과목 입력

			System.out.print("\t\t\t\t[수정할 과목유형] :  ");
			String typeSeq =  scan.nextLine();
			
			String typeSeq2 = typeSeq.replace("'", "''");
			
			
			VwSubjectTypeDTO dto = new VwSubjectTypeDTO();
			dto.setvTypeSeq(typeSeq2);
			
			int result = dao.editLecturerAvlb(selectnum, typeSeq2, beforeSeq);
			
			administratorLecturerManageView.thinLine();
			
			
			
			if(result ==1) {
				System.out.println("\t\t\t\t강의가능 과목유형 수정 완료");
			}else {
				System.out.println("\t\t\t\t강의가능 과목유형 수정 실패");
			}
			
			dao.close();
			administratorLecturerManageView.enterpause( );
			AdministratorController.main();
	}

//===============================================================================================================================
	
	//#과정확인
	public void checkcourse(String selectnum) {
		//[교사과정확인]
		administratorLecturerManageView.title(AdministratorLecturerManageView.LECTURERCOURSEINFO);
		//[담당과정확인]
		administratorLecturerManageView.title(AdministratorLecturerManageView.SELECTCOURSE);
		
		AdLecturerInfoDAO dao = new AdLecturerInfoDAO();
		ArrayList<VwCourseDTO> coursecheck = dao.coursecheck(selectnum);

			for(VwCourseDTO dto : coursecheck) {
				System.out.printf("\t[개설과정명] : %s\n\t[개설과정기간] : %s ~ %s\n\t[강의실] : %s\n\t[강의 진행 여부] : 강의중\n"
									
									, dto.getVcourseName()
									, dto.getVcourseStartDate()
									, dto.getVcourseEndDate()
									, dto.getVclassroom());
			}//for	
		dao.close();
		this.checksubject(selectnum);
	}//checkcourse
	
//===============================================================================================================================
	
	public void checksubject(String selectnum) {
		//[과목]
		administratorLecturerManageView.title(AdministratorLecturerManageView.SELECTSUBJECT);
		
		AdLecturerInfoDAO dao2 = new AdLecturerInfoDAO();
		ArrayList<VwSubjectDTO> subjectcheck = dao2.subjectcheck(selectnum);

			for(VwSubjectDTO dto : subjectcheck) {
				System.out.printf("\t[과목명] : %s (%s ~ %s)\n\t[교재명] : %s\n", dto.getVsubjectName(), dto.getVsubjectStartDate(), dto.getVsubjectEndDate(), dto.getvTextbook());
			}//for	
			
		dao2.close();	
		
		 administratorLecturerManageView.mainpause();
	}//checksubject
	
}//class


	

