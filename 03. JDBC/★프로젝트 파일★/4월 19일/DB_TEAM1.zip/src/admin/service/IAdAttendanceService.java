package admin.service;

public interface IAdAttendanceService {

	void fullAttendance(String courseSeq);

	void attendanceByMonth(String courseSeq);
	
}
