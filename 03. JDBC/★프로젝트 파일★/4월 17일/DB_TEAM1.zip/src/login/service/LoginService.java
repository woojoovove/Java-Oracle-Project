package login.service;

import java.util.ArrayList;
import java.util.Scanner;

import dto.LecturerDTO;
import dto.StudentInfoDTO;
import login.controller.LoginController;
import login.dao.LoginDAO;
import login.view.LoginView;

public class LoginService implements ILoginService {

	private static LoginView loginView;
	private static Scanner scan;
	
	static {
		loginView = new LoginView();
		scan = new Scanner(System.in);
	}

//--------------------------------------------------------------------------------------------	
	
	@Override
	public int loginProcess() {
				
		loginView.login();
				
		if (LoginController.id.startsWith("admin")) {
			
			loginView.loginProcess();
			return 1;			
			
		} else if (!LoginController.id.startsWith("admin")) {
			
			loginView.loginProcess();
			
			boolean lecturerFlag = false;
			boolean studentFlag = false;

			LoginDAO loginDao = new LoginDAO();	
			
			ArrayList<LecturerDTO> lecturerList = loginDao.lecturerLogin();	
			ArrayList<StudentInfoDTO> studentList = loginDao.studentLogin();	
			
			for (LecturerDTO lecturerDto : lecturerList) {
				if (LoginController.id.equals(lecturerDto.getName()) && LoginController.pw.equals(lecturerDto.getRegistrationNum())) {
					lecturerFlag = true;
					LoginController.lecturerSeq = lecturerDto.getSeq();
				}
			}
			
			for (StudentInfoDTO studentDto : studentList) {
				if (LoginController.id.equals(studentDto.getName()) && LoginController.pw.equals(studentDto.getRegistrationNum())) {
					studentFlag = true;
					LoginController.studentSeq = studentDto.getSeq();
				}
			}
			
			loginDao.close();
			
			if (lecturerFlag == true) return 2;
			if (studentFlag == true) return 3;
									
		}
			
		loginView.loginError(); 
		return 0;
		
	}//method : loginProcess

}//Class : LoginService
