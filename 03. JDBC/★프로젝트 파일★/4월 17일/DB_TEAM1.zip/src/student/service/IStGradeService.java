package student.service;

public interface IStGradeService {

	void gradeList();

	void quizList();
	
	

}
