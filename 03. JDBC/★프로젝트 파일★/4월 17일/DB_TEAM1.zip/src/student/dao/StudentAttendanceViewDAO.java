package student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.CourseNameDTO;
import dto.VwsubjectAttendanceDTO;
import util.DBUtil;

public class StudentAttendanceViewDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public StudentAttendanceViewDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : StudentAttendanceViewDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close	
	
	
	
//학생명	
//=====================================================================================================================================	
	
	public String studentName(String studentSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblStudentInfo WHERE seq = %s", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String studentName = rs.getString("name");
				return studentName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : studentName
	
//=====================================================================================================================================	

	
	
//전체 기간 조회
//=====================================================================================================================================	
	
	//전체 기간 출결사항
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//=====================================================================================================================================		
	
	
	
//과목별 조회
//=====================================================================================================================================	
	
	//과목 리스트
	public ArrayList<String> subjectAttendanceView(String studentSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwsubjectAttendance WHERE vstudentseq = %s", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwsubjectAttendanceDTO> subjectAttendanceList = new ArrayList<VwsubjectAttendanceDTO>();
			
			while (rs.next()) {				
				VwsubjectAttendanceDTO vwsubjectAttendanceDTO = new VwsubjectAttendanceDTO();
				
				vwsubjectAttendanceDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				vwsubjectAttendanceDTO.setvSubjectName(rs.getString("vSubjectName"));
				vwsubjectAttendanceDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				vwsubjectAttendanceDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				
				subjectAttendanceList.add(vwsubjectAttendanceDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwsubjectAttendanceDTO vwsubjectAttendanceDTO : subjectAttendanceList) {
				tempList.add(
						"\t[" + vwsubjectAttendanceDTO.getvSubjectSeq() + "]" 
						+ "\t과목명\t\t" + vwsubjectAttendanceDTO.getvSubjectName()
						+"\n\t\t과목기간\t" + vwsubjectAttendanceDTO.getvSubjectStart().substring(0, 10) + " ~ "
											+ vwsubjectAttendanceDTO.getvSubjectEnd().substring(0, 10));
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectAttendanceView
	
	
	
	//과목별 출결사항
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//=====================================================================================================================================
	
}//class : StudentAttendanceViewDAO



