package lecturer.service;

public class LeScheduleService implements ILeScheduleService{

	@Override
	public void will() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void prog() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void substu(String temp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subject(String selcou) {
		// TODO Auto-generated method stub
		
	}

}
