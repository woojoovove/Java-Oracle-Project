package lecturer.service;

public class LeRecommendationService implements ILeRecommendationService {

}
