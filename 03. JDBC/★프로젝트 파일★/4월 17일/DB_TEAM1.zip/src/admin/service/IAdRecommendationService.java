package admin.service;

public interface IAdRecommendationService {

	void recommendation();
	
}
