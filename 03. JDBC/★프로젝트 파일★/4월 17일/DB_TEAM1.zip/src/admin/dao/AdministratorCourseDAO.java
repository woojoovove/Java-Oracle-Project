package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.ClassRoomDTO;
import dto.CourseDTO;
import dto.CourseNameDTO;
import dto.LecturerDTO;
import dto.SubjectDTO;
import dto.SubjectNameDTO;
import dto.VwCourseEditInfoDTO;
import dto.VwCourseInfoDTO;
import dto.VwCourseStudentInfoDTO;
import dto.VwCourseSubjectListDTO;
import dto.VwTextbookInfoDTO;
import util.DBUtil;

public class AdministratorCourseDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public AdministratorCourseDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : AdministratorDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close

	
	
//과정추가	
//=====================================================================================================================================
		
	public ArrayList<String> courseNameList() {
		
		try {
			
			String sql = "SELECT * FROM tblCourseName";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<CourseNameDTO> courseNameList = new ArrayList<CourseNameDTO>();
			
			while (rs.next()) {				
				CourseNameDTO courseNameDto = new CourseNameDTO();
				
				courseNameDto.setSeq(rs.getString("seq"));
				courseNameDto.setName(rs.getString("name"));	
				
				courseNameList.add(courseNameDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (CourseNameDTO courseNameDto : courseNameList) {
				tempList.add("\t[" + courseNameDto.getSeq() + "]\t" 
						+ courseNameDto.getName());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : courseNameList

//------------------------------------------------------------------------------------------------------------------------
	
	public String selectCourseName(String courseNameSeq) {
			
		try {
			
			String sql = String.format("SELECT name FROM tblCourseName WHERE seq = %s", courseNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("name");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseName

//-----------------------------------------------------------------------------------------------------------------------
	
	public ArrayList<String> classroomList() {
		
		try {
			
			String sql = "SELECT * FROM tblClassroom";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<ClassRoomDTO> classroomList = new ArrayList<ClassRoomDTO>();
			
			while (rs.next()) {				
				ClassRoomDTO classroomDto = new ClassRoomDTO();
				
				classroomDto.setSeq(rs.getString("seq"));
				classroomDto.setName(rs.getString("name"));
				classroomDto.setNum(rs.getString("num"));
				
				classroomList.add(classroomDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (ClassRoomDTO classroomDTO : classroomList) {
				tempList.add("\t[" + classroomDTO.getSeq() + "]\t" 
						+ classroomDTO.getName() + "\t"
							+ classroomDTO.getNum());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : classroomList

//-----------------------------------------------------------------------------------------------------------------------
	
	public ArrayList<String> lecturerList() {
		
		try {	
			
			String sql = "SELECT * FROM tblLecturer";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<LecturerDTO> lecturerList = new ArrayList<LecturerDTO>();
			
			while (rs.next()) {				
				LecturerDTO lecturerDto = new LecturerDTO();
				
				lecturerDto.setSeq(rs.getString("seq"));
				lecturerDto.setName(rs.getString("name"));
				lecturerDto.setRegistrationNum(rs.getString("registrationNum"));
				lecturerDto.setPhoneNum(rs.getString("phoneNum"));
				
				lecturerList.add(lecturerDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (LecturerDTO lecturerDto : lecturerList) {
				tempList.add("\t[" + lecturerDto.getSeq() + "]\t" 
						+ lecturerDto.getName() + "\t\t"
							+ lecturerDto.getRegistrationNum() + "\t\t\t"
								+ lecturerDto.getPhoneNum());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : lecturerList

//-----------------------------------------------------------------------------------------------------------------------
	
	public String selectLecturer(String lecturerSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblLecturer WHERE seq = %s", lecturerSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("name");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectLecturer
	
//-----------------------------------------------------------------------------------------------------------------------
	
	public int courseAdd(CourseDTO courseDto) {
		
		String sql = "INSERT INTO tblCourse (seq, startDate, endDate, courseNameSeq, classroomSeq, lecturerSeq) "
			    		+ "VALUES (tblCourseSeq.NEXTVAL, ?, ?, ?, ?, ?)";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getStartDate());
			pstat.setString(2, courseDto.getEndDate());
			pstat.setString(3, courseDto.getCourseNameSeq());
			pstat.setString(4, courseDto.getClassroomSeq());
			pstat.setString(5, courseDto.getLecturerSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : courseAdd

//=====================================================================================================================================	

	
	
//과정수정
//=====================================================================================================================================
	
	//수정할 과정 선택
	public ArrayList<String> courseEdit() {
		
		try {
			
			String sql = "SELECT * FROM vwCourseEditInfo";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseEditInfoDTO> courseEditList = new ArrayList<VwCourseEditInfoDTO>();
			
			while (rs.next()) {				
				VwCourseEditInfoDTO courseEditInfoDto = new VwCourseEditInfoDTO();
				
				courseEditInfoDto.setvCourseNum(rs.getString("vCourseNum"));
				courseEditInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseEditInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseEditInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseEditInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				courseEditInfoDto.setvCourseLecturer(rs.getString("vCourseLecturer"));
				
				courseEditList.add(courseEditInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseEditInfoDTO courseEditInfoDto : courseEditList) {
				tempList.add(
					"\t[" + courseEditInfoDto.getvCourseNum() + "] " + courseEditInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseEditInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseEditInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseEditInfoDto.getvCourseClassroom()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t교사\t\t" + courseEditInfoDto.getvCourseLecturer()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : courseEdit
	
//-----------------------------------------------------------------------------------------------------------------------

	//수정할 과정
	public String selectCourseEdit(String courseSeq) {
			
		try {
			
			String sql = String.format("SELECT * FROM vwCourseInfo WHERE \"vCourseNum\" = %s", courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vCourseName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseEdit

//-----------------------------------------------------------------------------------------------------------------------
	
	//현재 과정 정보
	public ArrayList<String> editCourseType(String courseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseEditInfoDTO> courseEditList = new ArrayList<VwCourseEditInfoDTO>();
			
			while (rs.next()) {				
				VwCourseEditInfoDTO courseEditInfoDto = new VwCourseEditInfoDTO();
				
				courseEditInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseEditInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseEditInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseEditInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				courseEditInfoDto.setvCourseLecturer(rs.getString("vCourseLecturer"));
				
				courseEditList.add(courseEditInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseEditInfoDTO courseEditInfoDto : courseEditList) {
				tempList.add(
					"\t과정명\t" + courseEditInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseEditInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseEditInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseEditInfoDto.getvCourseClassroom()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t교사\t\t" + courseEditInfoDto.getvCourseLecturer()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : editCourseType
	
//-----------------------------------------------------------------------------------------------------------------------
	
	//과정명 수정
	public String oldCourseName(String oldCourseNameSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", oldCourseNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vCourseName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldCourseName
	
	public int editCourseName(CourseDTO courseDto) {
		
		String sql = "UPDATE tblCourse SET coursenameseq = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getCourseNameSeq());
			pstat.setString(2, courseDto.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editCourseName
	
//-----------------------------------------------------------------------------------------------------------------------
	
	//과정 기간 수정
	public String oldCourseDate(String oldCourseNameSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", oldCourseNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseStart = rs.getString("vCourseStart").substring(0, 10);
				String courseEnd = rs.getString("vCourseEnd").substring(0, 10);
				String oldCourseDate = courseStart + " ~ " + courseEnd;
				return oldCourseDate;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldCourseName
	
	public int editCourseDate(CourseDTO courseDto) {
		
		String sql = "UPDATE tblCourse SET startdate = ?, enddate = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getStartDate());
			pstat.setString(2, courseDto.getEndDate());
			pstat.setString(3, courseDto.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editCourseDate
	
//-----------------------------------------------------------------------------------------------------------------------
	
	//강의실 수정
	public String oldCourseClassroom(String oldCourseNameSeq) {

		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", oldCourseNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseClassroom = rs.getString("vCourseClassroom");
				return courseClassroom;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldCourseClassroom
	
	public int editCourseClassroom(CourseDTO courseDto) {
		
		String sql = "UPDATE tblCourse SET classroomSeq = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getClassroomSeq());
			pstat.setString(2, courseDto.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editCourseClassroom
	
//-----------------------------------------------------------------------------------------------------------------------
	
	//교사 수정
	public String oldCourseLecturer(String oldCourseNameSeq) {

		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", oldCourseNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseClassroom = rs.getString("vCourseLecturer");
				return courseClassroom;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldCourseLecturer
	
	public int editCourseLecturer(CourseDTO courseDto) {
		
		String sql = "UPDATE tblCourse SET lecturerSeq = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getLecturerSeq());
			pstat.setString(2, courseDto.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editCourseLecturer

	
//=====================================================================================================================================		

	
	
//과정 삭제	
//=====================================================================================================================================

	public int courseDelete(CourseDTO courseDto) {
		
		String sql = "DELETE FROM tblCourse WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, courseDto.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
//=====================================================================================================================================

	
	
//과정조회	
//=====================================================================================================================================
	
	public ArrayList<String> courseList() {
		
		try {
			
			String sql = "SELECT * FROM vwCourseInfo";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseInfoDTO> courseList = new ArrayList<VwCourseInfoDTO>();
			
			while (rs.next()) {				
				VwCourseInfoDTO courseInfoDto = new VwCourseInfoDTO();
				
				courseInfoDto.setvCourseNum(rs.getString("vCourseNum"));
				courseInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				courseInfoDto.setSubjectState(rs.getString("subjectState"));
				courseInfoDto.setStudentCount(rs.getString("studentCount"));
				
				courseList.add(courseInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseInfoDTO courseInfoDto : courseList) {
				tempList.add(
					"\t[" + courseInfoDto.getvCourseNum() + "] " + courseInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseInfoDto.getvCourseClassroom()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과목 등록 여부\t" + courseInfoDto.getSubjectState()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t교육생 인원수\t" + courseInfoDto.getStudentCount()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : courseList
	
//----------------------------------------------------------------------------------------------------

	public String selectCourseListName(String courseSeq) {
			
		try {
			
			String sql = String.format("SELECT * FROM vwCourseInfo WHERE \"vCourseNum\" = %s", courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vCourseName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseListName
	
//----------------------------------------------------------------------------------------------------
	
	public String selectCourseLecturer(String courseSeq) {
		
		try {
			
			String sql = String.format("SELECT DISTINCT \"vLecturerName\" FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s", courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vLecturerName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseLecturer

//----------------------------------------------------------------------------------------------------
	
	public ArrayList<String> selectCourseListInfo(String courseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseInfo WHERE \"vCourseNum\" = %s", courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseInfoDTO> courseList = new ArrayList<VwCourseInfoDTO>();
			
			while (rs.next()) {				
				VwCourseInfoDTO courseInfoDto = new VwCourseInfoDTO();
				
				courseInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				
				courseList.add(courseInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseInfoDTO courseInfoDto : courseList) {
				tempList.add(
					"\t과정명\t\t" + courseInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseInfoDto.getvCourseClassroom()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseListInfo
	
//=====================================================================================================================================
	

	
//과목 추가
//=====================================================================================================================================	
	
	//과목명 선택
	public ArrayList<String> subjectNameList(String courseLecturer) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwSubjectName WHERE \"vLecturerName\" = '%s'", courseLecturer);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<SubjectNameDTO> subjectNameList = new ArrayList<SubjectNameDTO>();
			
			while (rs.next()) {				
				SubjectNameDTO subjectNameDTO = new SubjectNameDTO();
				
				subjectNameDTO.setSeq(rs.getString("vSeq"));
				subjectNameDTO.setName(rs.getString("vAvailableSubject"));	
				
				subjectNameList.add(subjectNameDTO);				
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (SubjectNameDTO subjectNameDTO : subjectNameList) {
				tempList.add("\t[" + subjectNameDTO.getSeq() + "]\t" 
						+ subjectNameDTO.getName());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectNameList
	
	public String selectSubjectName(String subjectNameSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblSubjectName WHERE seq = %s", subjectNameSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("name");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectSubjectName
	
//------------------------------------------------------------------------------------------------------------	
	
	//교재 선택
	public ArrayList<String> subjectTextbookList() {
		
		try {
			
			String sql = "SELECT * FROM vwTextbookInfo";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwTextbookInfoDTO> textbookInfoList = new ArrayList<VwTextbookInfoDTO>();
			
			while (rs.next()) {				
				VwTextbookInfoDTO textbookInfoDTO = new VwTextbookInfoDTO();
				
				textbookInfoDTO.setvTextbookSeq(rs.getString("vTextbookSeq"));
				textbookInfoDTO.setvTextbookName(rs.getString("vTextbookName"));
				textbookInfoDTO.setvPublisher(rs.getString("vPublisher"));
				
				textbookInfoList.add(textbookInfoDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwTextbookInfoDTO textbookInfoDTO : textbookInfoList) {
				tempList.add("\t[" + textbookInfoDTO.getvTextbookSeq() + "]\t" 
						+ "교재명\t" + textbookInfoDTO.getvTextbookName()
						+ "\n\t\t출판사\t" + textbookInfoDTO.getvPublisher());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectTextbookList
	
	public String subjectTextbookName(String subjectTextbookSeq) {

		try {
			
			String sql = String.format("SELECT name FROM tblTextbook WHERE seq = %s", subjectTextbookSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("name");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : subjectTextbookName
	
	
	
	//INSERT 실행
	public int subjectAdd(SubjectDTO subjectDTO) {
		
		String sql = "INSERT INTO tblSubject VALUES(seq.NEXTVAL, ?, ?, NULL, NULL, NULL, ?, ?, ?, DEFAULT)";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getStartDate());
			pstat.setString(2, subjectDTO.getEndDate());
			pstat.setString(3, subjectDTO.getSubjectNameSeq());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getTextbookSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : subjectAdd
	
//=====================================================================================================================================
	
	
	
//과목정보	
//=====================================================================================================================================
	
	public ArrayList<String> subjectList(String vCourseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND state = 1", vCourseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseSubjectListDTO> courseSubjectList = new ArrayList<VwCourseSubjectListDTO>();
			
			while (rs.next()) {				
				VwCourseSubjectListDTO courseSubjectListDTO = new VwCourseSubjectListDTO();
				
				courseSubjectListDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				courseSubjectListDTO.setvSubjectName(rs.getString("vSubjectName"));	
				courseSubjectListDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				courseSubjectListDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				courseSubjectListDTO.setvTextbookName(rs.getString("vTextbookName"));
				courseSubjectListDTO.setvLecturerName(rs.getString("vLecturerName"));
				
				courseSubjectList.add(courseSubjectListDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseSubjectListDTO courseSubjectListDTO : courseSubjectList) {
				tempList.add(
						"\n\t=========================================================================="
						+ "\n\t과목번호\t[" + courseSubjectListDTO.getvSubjectSeq() + "]"
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목명\t\t" + courseSubjectListDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목기간\t" + courseSubjectListDTO.getvSubjectStart().substring(0, 10) + " ~ "
												+ courseSubjectListDTO.getvSubjectEnd().substring(0, 10)
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교재명\t\t" + courseSubjectListDTO.getvTextbookName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교사명\t\t" + courseSubjectListDTO.getvLecturerName()
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectList

//=====================================================================================================================================

	
	
//과목 수정
//=====================================================================================================================================	
	
	//수정할 과목의 이름
	public String selectEditSubjectName(String subjectSeq) {

		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vSubjectSeq\" = %s", subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("vSubjectName");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectEditSubjectName
	
//----------------------------------------------------------------------------------------------------
	
	//수정할 과목의 세부정보
	public ArrayList<String> editSubjectType(String vCourseSeq, String subjectSeq) {

		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND \"vSubjectSeq\" = %s"
					, vCourseSeq, subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseSubjectListDTO> courseSubjectList = new ArrayList<VwCourseSubjectListDTO>();
			
			while (rs.next()) {				
				VwCourseSubjectListDTO courseSubjectListDTO = new VwCourseSubjectListDTO();
				
				courseSubjectListDTO.setvSubjectName(rs.getString("vSubjectName"));	
				courseSubjectListDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				courseSubjectListDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				courseSubjectListDTO.setvTextbookName(rs.getString("vTextbookName"));
				courseSubjectListDTO.setvLecturerName(rs.getString("vLecturerName"));
				
				courseSubjectList.add(courseSubjectListDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseSubjectListDTO courseSubjectListDTO : courseSubjectList) {
				tempList.add(
						"\n\t=========================================================================="
						+ "\n\t과목명\t\t" + courseSubjectListDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목기간\t" + courseSubjectListDTO.getvSubjectStart().substring(0, 10) + " ~ "
												+ courseSubjectListDTO.getvSubjectEnd().substring(0, 10)
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교재명\t\t" + courseSubjectListDTO.getvTextbookName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교사명\t\t" + courseSubjectListDTO.getvLecturerName()
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : editSubjectType
		
//----------------------------------------------------------------------------------------------------
	
	//과목명 수정
	public String oldSubjectName(String courseSeq, String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND \"vSubjectSeq\" = %s"
					, courseSeq, subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("vSubjectName");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldSubjectName
	
	public int editSubjectName(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET subjectnameSeq = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getSubjectNameSeq());
			pstat.setString(2, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editSubjectName
	
//----------------------------------------------------------------------------------------------------	
	
	//과목 기간 수정
	public String oldSubjectDate(String courseSeq, String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND \"vSubjectSeq\" = %s"
					, courseSeq, subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectStart = rs.getString("vSubjectStart").substring(0, 10);
				String subjectEnd = rs.getString("vSubjectEnd").substring(0, 10);
				String oldSubjectDate = subjectStart + " ~ " + subjectEnd;
				return oldSubjectDate;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldCourseName
	
	public int editSubjectDate(SubjectDTO subjectDTO) {

		String sql = "UPDATE tblSubject SET startdate = ?, enddate = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getStartDate());
			pstat.setString(2, subjectDTO.getEndDate());
			pstat.setString(3, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : editSubjectDate
	
//----------------------------------------------------------------------------------------------------	
	
	//교재 수정
	public String oldSubjectTextbookName(String courseSeq, String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND \"vSubjectSeq\" = %s"
					, courseSeq, subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String textbookName = rs.getString("vTextbookName");
				return textbookName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldSubjectTextbookName
	
	public String oldSubjectPublisherName(String courseSeq, String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND \"vSubjectSeq\" = %s"
					, courseSeq, subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String publisherName = rs.getString("vPublisherName");
				return publisherName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : oldSubjectPublisherName
	
	public int editSubjectTextbook(SubjectDTO subjectDTO) {
				
		String sql = "UPDATE tblSubject SET textbookSeq = ? WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getTextbookSeq());
			pstat.setString(2, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;			
				
	}//method : editSubjectTextbook
	
//=====================================================================================================================================	
	
	
	
//과목삭제	
//=====================================================================================================================================	
	
	public ArrayList<String> deleteSubjectList(String vCourseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s AND state = 1", vCourseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseSubjectListDTO> courseSubjectList = new ArrayList<VwCourseSubjectListDTO>();
			
			while (rs.next()) {				
				VwCourseSubjectListDTO courseSubjectListDTO = new VwCourseSubjectListDTO();
				
				courseSubjectListDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				courseSubjectListDTO.setvSubjectName(rs.getString("vSubjectName"));	
				courseSubjectListDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				courseSubjectListDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				courseSubjectListDTO.setvTextbookName(rs.getString("vTextbookName"));
				courseSubjectListDTO.setvLecturerName(rs.getString("vLecturerName"));
				
				courseSubjectList.add(courseSubjectListDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseSubjectListDTO courseSubjectListDTO : courseSubjectList) {
				tempList.add(
						"\n\t[" + courseSubjectListDTO.getvSubjectSeq() + "]"
						+ "\n\t=========================================================================="
						+ "\n\t과목명\t\t" + courseSubjectListDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목기간\t" + courseSubjectListDTO.getvSubjectStart().substring(0, 10) + " ~ "
												+ courseSubjectListDTO.getvSubjectEnd().substring(0, 10)
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교재명\t\t" + courseSubjectListDTO.getvTextbookName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t교사명\t\t" + courseSubjectListDTO.getvLecturerName()
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : deleteSubjectList
	
//----------------------------------------------------------------------------------------------------
	
	public String deleteSubjectName(String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblSubjectName WHERE seq = %s", subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("name");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : deleteSubjectName

//----------------------------------------------------------------------------------------------------
	
	public int deleteSubject(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET state = 0 WHERE seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : deleteSubject
	
//=====================================================================================================================================	
	
	

//특정 과정을 수강하는 교육생 목록
//=====================================================================================================================================	
	
	public ArrayList<String> CourseStudentList(String vCourseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseStudentInfo WHERE \"vCourseSeq\" = %s AND \"vState\" = 1", vCourseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseStudentInfoDTO> courseStudentList = new ArrayList<VwCourseStudentInfoDTO>();
			
			while (rs.next()) {				
				VwCourseStudentInfoDTO courseStudentInfoDTO = new VwCourseStudentInfoDTO();
				
				courseStudentInfoDTO.setvName(rs.getString("vName"));
				courseStudentInfoDTO.setvRegistrationNum(rs.getString("vRegistrationNum"));
				courseStudentInfoDTO.setvPhoneNum(rs.getString("vPhoneNum"));
				courseStudentInfoDTO.setvRegistrationDate(rs.getString("vRegistrationDate"));
				courseStudentInfoDTO.setvState(rs.getString("vState"));
				courseStudentInfoDTO.setvStatus(rs.getString("vStatus"));
				
				courseStudentList.add(courseStudentInfoDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseStudentInfoDTO courseStudentInfoDTO : courseStudentList) {
				
				String status = "";
				
				if (courseStudentInfoDTO.getvStatus().equals("1")) {
					status = "교육예정";
				} else if (courseStudentInfoDTO.getvStatus().equals("2")) {
					status = "교육중";
				} else if (courseStudentInfoDTO.getvStatus().equals("3")) {
					status = "수료";
				} else if (courseStudentInfoDTO.getvStatus().equals("4")) {
					status = "중도탈락";
				}
				
				tempList.add(
						"\n\t=========================================================================="
						+ "\n\t이름\t\t\t" + courseStudentInfoDTO.getvName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t주민번호 뒷자리\t\t" + courseStudentInfoDTO.getvRegistrationNum()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t전화번호\t\t" + courseStudentInfoDTO.getvPhoneNum()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t등록일\t\t\t" + courseStudentInfoDTO.getvRegistrationDate().substring(0, 10)
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t수료/탈락여부\t\t" + status
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : CourseStudentList
	
	
	
//=====================================================================================================================================	
	
}//Class : AdministratorDAO


