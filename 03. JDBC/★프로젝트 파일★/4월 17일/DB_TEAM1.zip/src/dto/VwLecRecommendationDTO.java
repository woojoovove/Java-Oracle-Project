package dto;

public class VwLecRecommendationDTO {

	private String vseq;
	private String vname;
	private String vphonenum;
	private String vregistrationdate;
	private String vtotal;
	
	
	public String getVseq() {
		return vseq;
	}
	public void setVseq(String vseq) {
		this.vseq = vseq;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVphonenum() {
		return vphonenum;
	}
	public void setVphonenum(String vphonenum) {
		this.vphonenum = vphonenum;
	}
	public String getVregistrationdate() {
		return vregistrationdate;
	}
	public void setVregistrationdate(String vregistrationdate) {
		this.vregistrationdate = vregistrationdate;
	}
	public String getVtotal() {
		return vtotal;
	}
	public void setVtotal(String vtotal) {
		this.vtotal = vtotal;
	}
	
	
	
}
