package lecturer.view;

import java.util.Scanner;

public class LecturerRecommendationView {
	
	//추천서관리
	public final static int RECOMMENDATION = 580;	
	public final static int RECOMMENDATIONADD = 581;
	
//===============================================================================================================================
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 교사]");
		
	}//Method : begin
	
//------------------------------------------------------------------------------------------------------------------
	
	@SuppressWarnings("resource")
	public void pause() {
		
		System.out.println();
		System.out.println("\t\t\t계속하려면 ENTER키를 누르십시오.");
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
		
	}

//------------------------------------------------------------------------------------------------------------------
	
	@SuppressWarnings("resource")
	public void error() {
		
		System.out.println("\t잘못 입력하셨습니다. 다시 입력해주세요.");
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
		
	}

	public void select() {
		System.out.println("\t==========================================================================\n");

		System.out.println("\t[1] 추천서 확인\n");
		System.out.println("\t[2] 추천서 사유 입력\n");
		
		System.out.println("\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		
	}	
	
//===============================================================================================================================
	
	public void title(int n) {
	
		switch(n)
		{
		
		//추천서 관리
		case LecturerRecommendationView.RECOMMENDATION : 
				System.out.println("\t\t\t\t\t[추천서 관리]")
				; break;
		case LecturerRecommendationView.RECOMMENDATIONADD : 
				System.out.println("\t\t   [추천서 사유 입력]")
				; break;
		
		}//switch End
	
	}

}//Class : LecturerView
