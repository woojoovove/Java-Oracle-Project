package login.service;

public interface ILoginService {

	int loginProcess();

}
