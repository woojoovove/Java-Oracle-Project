package admin.view;

import java.util.ArrayList;
import java.util.Scanner;

import admin.dao.AdAttendanceDAO;
import dto.CourseNameDTO;

public class AdministratorWarningView {

	//출결, 추천서
	public final static int ATTENDANCEBYCOURSE = 600;
	public static final int ATTENDANCE = 601;
	public static final int FULLATTENDANCE = 602;
	public static final int RECOMMENDATION = 700;
	
	//특별 상담

	public static final int WARNING = 800;
	
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
//관리자 메뉴 메인	
//------------------------------------------------------------------------------------------------------------------	
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 관리자]");
		
	}//Method : begin
	
	public void menu() {
		
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 기초 정보 관리\n");
		System.out.println("\t\t\t\t[2] 교사 계정 관리\n");
		System.out.println("\t\t\t\t[3] 개설 과정 관리\n");
		System.out.println("\t\t\t\t[4] 교육생 관리\n");
		System.out.println("\t\t\t\t[5] 성적 관리\n");
		System.out.println("\t\t\t\t[6] 출결 관리\n");
		System.out.println("\t\t\t\t[7] 추천서 관리\n\n");
		System.out.println("\t\t\t\t[8] 특별 상담 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu
	
//------------------------------------------------------------------------------------------------------------------


	
//출결, 추천서	
//------------------------------------------------------------------------------------------------------------------	

	public void menuAttendance() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과정별 출결 조회\n");

		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
	}
	
	
	public void menuCourse() {

		//[과정별 출결 조회]
		
		/* 
		 * A07-002.와 같이 출력
		 * 과정별 출결 조회를 위한 과정 목록 출력 : 10개씩 끊어서 보여주기
		최신순으로 정렬,
		SELECT coursename FROM course ORDER BY startdate desc; 
		
		*/
		
		AdAttendanceDAO adAttendanceDAO = new AdAttendanceDAO();
		ArrayList<CourseNameDTO> courseNameDTO = adAttendanceDAO.courseNameList();
		
		System.out.println("\n\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		for(CourseNameDTO dto : courseNameDTO) {
			
			System.out.printf("\t[%s] %s\n", dto.getSeq(), dto.getName());
			System.out.println("\t--------------------------------------------------------------------------\n");
		}
		System.out.println("\t==========================================================================\n");
		System.out.println("\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		
	}
	
	public void menuCourseSub() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t조회 방법을 선택하십시오");
		System.out.println("\t\t\t\t[1] 전체 조회\n");
		System.out.println("\t\t\t\t[2] 기간별 조회\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}

	
	
	
	public void pause(int n) {
		
		if (n == AdministratorWarningView.RECOMMENDATION) { 
			
			System.out.println("추천서 입력을 계속 하시려면 엔터를 입력해주세요");
			scan.nextLine();
		} else if (n == AdministratorWarningView.WARNING) {
			System.out.println("\n\t\t\t\t담당 선생님께 특별상담 알림 완료.");
			System.out.println("\n\t\t\t\t이전 메뉴로 돌아갑니다. \n\t\t\t\t계속하시려면 엔터를 입력해주세요");
			scan.nextLine();
		}
	}
	
//------------------------------------------------------------------------------------------------------------------		

	public void warningMenu() {
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 특별 상담 대상 조회\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}
	
	public void warningSubMenu() {
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 선생님께 알림 보내기\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}


//------------------------------------------------------------------------------------------------------------------		

	
	public void title(int n) {
		
		switch(n)
		{
		
		//출결, 추천서 관리
		case AdministratorWarningView.ATTENDANCEBYCOURSE		: System.out.println("\t\t\t\t[과정별 출결 관리]"); break;
		case AdministratorWarningView.ATTENDANCE				: System.out.println("\t\t[출결 관리]"); break;
		case AdministratorWarningView.RECOMMENDATION			: System.out.println("\t\t[추천서 관리]"); break;
		case AdministratorWarningView.FULLATTENDANCE			: System.out.println("\t\t[전체 기간 조회]"); break;
		
	//--------------------------------------------------------------------------------------------------------------
	
		// 특별 상담 관리
		case AdministratorWarningView.WARNING					: System.out.println("\t\t\t\t[특별 상담 관리]"); break;

		}//switch End
				
	}//Method : title

}//Class : AdministratorView



