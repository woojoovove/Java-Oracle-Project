package admin.view;

import java.util.Scanner;

public class AdministratorBasicInfoView {
		
	//기초 정보 관리(과정명 관리)
		public final static int courseName = 100;
		public final static int insertCourseName = 101;
		public final static int modifyCourseName = 102;
		public final static int deleteCourseName = 103;
		
		//기초 정보 관리(과목명 관리)
		public final static int subjectName = 104;
		public final static int insertSubject = 105;
		public final static int modifySubjectName = 106;
		public final static int deleteSubjectName = 107;
		
		//기초 정보 관리(강의실명 관리)
		public final static int classRoom = 108;
		public final static int modifyClassRoomName = 109;
		public final static int modifyClassRoomNum = 110;
		
		//기초 정보 관리(교재명 관리)
		public final static int textBook = 111;
		public final static int inserttextBook = 112;
		public final static int modifytextBook = 113;
		public final static int deletetextBook = 114;
		public final static int selectPublisher = 115;
		
		//기초 정보 관리 (추가)
		public final static int courseNameInMoDe = 116;
		public final static int courseMenu = 117;
		
		public final static int subjectNameInMoDe = 118;
		public final static int subjectTypeName = 119; 
		
		private static Scanner scan;
		
		static {
			scan = new Scanner(System.in);
		}
		

//관리자 메뉴 메인	
//==================================================================================================================================
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 관리자]");
		
	}//Method : begin
	
	public void menu() {
		
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 기초 정보 관리\n");
		System.out.println("\t\t\t\t[2] 교사 계정 관리\n");
		System.out.println("\t\t\t\t[3] 개설 과정 관리\n");
		System.out.println("\t\t\t\t[4] 교육생 관리\n");
		System.out.println("\t\t\t\t[5] 성적 관리\n");
		System.out.println("\t\t\t\t[6] 출결 관리\n");
		System.out.println("\t\t\t\t[7] 추천서 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu
	
//==================================================================================================================================		
		
		
	
//기초정보 관리	
//===============================================================================================================================		

	public void basicInfomenu() {
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과정명\n");
		System.out.println("\t\t\t\t[2] 과목명\n");
		System.out.println("\t\t\t\t[3] 강의실명\n");
		System.out.println("\t\t\t\t[4] 교재명\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		
	}
	
	
	public void courseNameMenu() {
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과정 추가\n");
		System.out.println("\t\t\t\t[2] 과정 수정\n");
		System.out.println("\t\t\t\t[3] 과정 삭제\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}
	
	
	public void subjectNameMenu() {
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과목 추가\n");
		System.out.println("\t\t\t\t[2] 과목 수정\n");
		System.out.println("\t\t\t\t[3] 과목 삭제\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
	}
	
	public void textBookMenu() {
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 교재 수정\n");
		System.out.println("\t\t\t\t[2] 교재 삭제\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}
		
		
//===============================================================================================================================		
		
		
		
//기초 정보 관리 - 과정
//==================================================================================================================================

	public void basicInfoCourseAddDelMo() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t[*] 추가/삭제/수정하기 ");
		System.out.println("\t[0] 돌아가기 ");
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[]안의 번호를 입력하십시오 ");
		System.out.print("\t입력 : ");
		
	}
	
	public void basicInfoCourseAdd() {
		
		System.out.println("\n\t==========================================================================");
		System.out.print("\t새로운 과정명을 입력해주세요 ");
		System.out.println("\n\t--------------------------------------------------------------------------");
		
		
	}
	
	public void basicInfoCourseAddFin() {
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t추가를 완료하였습니다.");
		System.out.println("\t이전화면으로 돌아갑니다.");
		System.out.println("\t계속하시려면 ENTER 키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public String basicInfoCourseModDel01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정/삭제하고자 하는 과정 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	public void basicInfoCourseModDel02(String courseName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s' 과정을 선택하였습니다\n\n", courseName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	
	public String basicInfoMod01() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.print("\t수정할 과정명 : ");
		String name = scan.nextLine();
		
		return name;
		
	}
	
	
	public void editBasicCourseName(String basicNewCourseName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t과정명을 '%s'으로 변경합니다\n\n", basicNewCourseName);
		System.out.print("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	
	public void basicInfoCourseModFin() {
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t수정을 완료하였습니다.");
		System.out.println("\t이전화면으로 돌아갑니다.");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public void delBasicCourseName(String basicDelCourseName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'과정을 삭제합니다. \n\n", basicDelCourseName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
//기초 정보 관리 - 과목	
//=============================================================================================================		
	
	public void basicSubjectListAddDelMo() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t[*] 추가/삭제/수정하기 ");
		System.out.println("\t[0] 돌아가기 ");
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[]안의 번호를 입력하십시오 ");
		System.out.print("\t입력 : ");
		
	}
	
	
	public void basicSubjectAdd01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.print("\t과목 유형을 선택해주십시오.\n");
		System.out.print("\t입력 : ");
		
		
	}
	
	public void basicSubjectAdd02() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.print("\t새로운 과목명을 입력하십시오 \n");
		
		
	}
	
	
	public String basicSubjectModDel01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정/삭제하고자 하는 과목 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	public void basicSubjectModDel02(String subjectName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s' 과목을 선택하였습니다\n\n", subjectName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public String basicSubjectMod01() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.print("\t수정할 과목명: ");
		String name = scan.nextLine();
		
		return name;
		
	}
	
//기초 정보 관리 - 강의실	
//=============================================================================================================
	
	public void basicClassroomListDelMo() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t[*] 강의실명 수정하기 ");
		System.out.println("\t[#] 강의실 정원 수정하기");
		System.out.println("\t[0] 돌아가기 ");
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[]안의 번호를 입력하십시오 ");
		System.out.print("\t입력 : ");
		
	}
	
	public String basicClassroomModDel01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정할 강의실 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	public void basicClassroomModDel02() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t수정화면으로 이동합니다.\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public void editBasicClassroomName(String basicNewClassroomName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t강의실명을 '%s'으로 변경합니다.\n", basicNewClassroomName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public void editBasicClassroomNum(String basicNewClassroomNum) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t강의실 정원을 '%s'명으로 변경합니다.\n", basicNewClassroomNum);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}

//기초 정보 관리 - 교재 	
//=============================================================================================================	
	
	public void textbookContentSelect() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정할 내용을 선택하십시오.");
		System.out.println("\t[1] 교재명 ");
		System.out.println("\t[2] 출판사명 ");
		System.out.println();
		System.out.println("\t[0] 돌아가기 ");
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.print("\t입력 : ");
	
	}
	
	
	public void basicTextbookAddDelMo01() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t[*] 추가/삭제/수정하기 ");
		System.out.println("\t[0] 돌아가기 ");
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[]안의 번호를 입력하십시오 ");
		System.out.print("\t입력 : ");
		
	}
	
	public void basicTextbookAddDelMo02() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t 교재 추가/수정/삭제 화면으로 이동합니다.\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public void basicTextbookAdd() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t새로운 교재를 입력하십시오. ");
		
	}
	
	public void basicPublisherAdd01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t출판사를 선택하십시오. ");
		System.out.println("\n\t==========================================================================");
	}
	
	public void basicPublisherAdd02() {
		
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t[]안의 번호를 입력하십시오 ");
		System.out.print("\t입력 : ");
		
	}
	
	public void basicTextbookAddFin() {
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t추가를 완료하였습니다.");
		System.out.println("\t이전화면으로 돌아갑니다.");
		System.out.println("\t계속하시려면 ENTER 키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	
	
	
	public String basicTextbookMod01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정하고자 하는 교재 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	
	public void basicTextbookMod02(String basictextbookName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s' 교재를 선택하였습니다\n\n", basictextbookName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public String basicTextbookMod03() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.print("\t수정할 교재명: ");
		String name = scan.nextLine();
		
		return name;
		
	}
	
	public void editTextbookName(String basicNewTextbookName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t교재명을 '%s' 으로 변경합니다\n\n", basicNewTextbookName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public String basicPublisherMod01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t수정하고자 하는 출판사 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	public void basicPublisherMod02(String basicPublisherName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'를 선택하였습니다\n\n", basicPublisherName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	public String basicPublisherMod03() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.print("\t수정할 출판사명: ");
		String name = scan.nextLine();
		
		return name;
		
	}
	
	public void editPublisherName(String basicNewPublisherName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t출판사 명을 '%s' 으로 변경합니다\n\n", basicNewPublisherName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();

	}

	
	public String basicTextbookDel01() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t삭제하고자 하는 교재 번호를 입력하십시오");
		System.out.print("\t입력 : ");
		String select = scan.nextLine();
		
		return select;
		
	}
	
	public void basicTextbookDel02(String basicDelTextbook) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s' 교재를 선택하였습니다\n\n", basicDelTextbook);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		@SuppressWarnings("unused")
		String enter = scan.nextLine();
	}
	
	
//=============================================================================================================		
	
	public void thinLine() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		
	}//method : line
	
	public void thickLine() {
		
		System.out.println("\t==========================================================================");
		
	}//method : line
	
	public void blank() {
		
		System.out.println();
		System.out.println();
		System.out.println();
		
	}
	
//=============================================================================================================		
	
	public void title(int n) {
		
		switch(n)
		{
		
		//기초 정보 관리(과정명 관리)
		case AdministratorBasicInfoView.courseMenu : 
			System.out.println("\t\t\t\t[기초 정보 관리]\n"); 
			break;
		case AdministratorBasicInfoView.courseName : 
			System.out.println("\t\t\t\t[과정명 리스트]\n"); 
			break;
		case AdministratorBasicInfoView.courseNameInMoDe : 
			System.out.println("\t\t\t\t[과정 추가/수정/삭제]\n"); 
			break;
		case AdministratorBasicInfoView.insertCourseName :
			System.out.println("\t\t\t\t[과정명 추가]\n"); 
			break;
		case AdministratorBasicInfoView.modifyCourseName : 
			System.out.println("\t\t\t\t[과정명 수정]\n"); 
			break;
		case AdministratorBasicInfoView.deleteCourseName : 
			System.out.println("\t\t\t\t[과정명 삭제]\n"); 
			break;
		
	//--------------------------------------------------------------------------------------------------------------	
		
		//기초 정보 관리(과목명 관리)
		case AdministratorBasicInfoView.subjectName : 
			System.out.println("\t\t\t\t[과목명 리스트]\n"); 
			break;
		case AdministratorBasicInfoView.subjectTypeName : 
			System.out.println("\t\t\t\t[과목유형 리스트]\n"); 
			break;
		case AdministratorBasicInfoView.subjectNameInMoDe : 
			System.out.println("\t\t\t\t[과목 추가/수정/삭제]\n"); 
			break;
		case AdministratorBasicInfoView.insertSubject : 
			System.out.println("\t\t\t\t[과목명 추가]\n"); 
			break;
		case AdministratorBasicInfoView.modifySubjectName : 
			System.out.println("\t\t\t\t[과목명 수정]\n"); 
			break;
		case AdministratorBasicInfoView.deleteSubjectName : 
			System.out.println("\t\t\t\t[과목명 삭제]\n"); 
			break;
		
	//--------------------------------------------------------------------------------------------------------------	
		
		//기초 정보 관리(강의실명 관리)	
		case AdministratorBasicInfoView.classRoom : 
			System.out.println("\t\t\t\t[강의실명]\n"); 
			break;
		case AdministratorBasicInfoView.modifyClassRoomName : 
			System.out.println("\t\t\t\t[강의실명 수정]\n"); 
			break;
		case AdministratorBasicInfoView.modifyClassRoomNum : 
			System.out.println("\t\t\t\t[강의실 정원 수정]\n"); 
			break;
		
	//--------------------------------------------------------------------------------------------------------------	
		
		//기초 정보 관리(교재명 관리)			
		case AdministratorBasicInfoView.textBook : 
			System.out.println("\t\t\t\t[교재 추가/수정/삭제]\n"); 
			break;
		case AdministratorBasicInfoView.inserttextBook : 
			System.out.println("\t\t\t\t[교재 추가]\n"); 
			break;
		case AdministratorBasicInfoView.modifytextBook : 
			System.out.println("\t\t\t\t[교재 수정]\n"); 
			break;
		case AdministratorBasicInfoView.deletetextBook : 
			System.out.println("\t\t\t\t[교재 삭제]\n"); 
			break;
		case AdministratorBasicInfoView.selectPublisher : 
			System.out.println("\t\t\t\t[출판사 선택]\n"); 
			break;

		}//switch
			
	}//title
		
}//class : AdministratorBasicInfoView
