package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.WarningDTO;
import util.DBUtil;

public class AdWarningDAO {

	private static Connection conn;
	private static Statement stat;
	private static PreparedStatement pstat;
	
	static {
		try {
			DBUtil util = new DBUtil();
			conn = util.connect();
			stat = conn.createStatement();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
	public ArrayList<WarningDTO> getStudent() {
		
		ArrayList<WarningDTO> list = new ArrayList<WarningDTO>();
		
		try {
			
			String sql = "SELECT * FROM vwWarning";
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				
				WarningDTO dto = new WarningDTO();
				
				dto.setATTENDANCEGRADE(rs.getString("ATTENDANCEGRADE"));
				dto.setLECTURERSEQ(rs.getString("LECTURERSEQ"));
				dto.setCOURSENAME(rs.getString("COURSENAME"));
				dto.setCOURSESEQ(rs.getString("COURSESEQ"));
				dto.setLECTURERNAME(rs.getString("LECTURERNAME"));
				dto.setSTUDENTNAME(rs.getString("STUDENTNAME"));
				dto.setSTUDENTSEQ(rs.getString("STUDENTSEQ"));
				
				list.add(dto);
			}
			return list;
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}

	public void notifyLecturer(ArrayList<WarningDTO> studentList) {
		
//		String sql = "INSERT tblWarning VALUES (tblWarningSeq.NEXTVAL, STUDENTSEQ, WARNINGDATE, COUNSELING)";

			
			for (WarningDTO student : studentList) {
				
				String sql = "INSERT INTO tblWarning VALUES (tblWarningSeq.NEXTVAL, ?, ?, DEFAULT, 0)";
				try {
					
					pstat = conn.prepareStatement(sql);
					pstat.setString(1, student.getSTUDENTSEQ());
					pstat.setString(2, student.getLECTURERSEQ());
					pstat.executeUpdate();
					
				} catch (SQLException e1) {
					e1.printStackTrace();
					System.out.println("AdWarningDAO.notifyLecturer");
				}
			}
	}
}


