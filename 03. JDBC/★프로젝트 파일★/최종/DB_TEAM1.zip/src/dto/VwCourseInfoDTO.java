package dto;

public class VwCourseInfoDTO {
	
	private String vCourseNum;
	private String vCourseName;
	private String vCourseStart;
	private String vCourseEnd;
	private String vCourseClassroom;
	private String subjectState;
	private String studentCount;
	
//----------------------------------------------------------	
	
	public String getvCourseNum() {
		return vCourseNum;
	}
	public void setvCourseNum(String vCourseNum) {
		this.vCourseNum = vCourseNum;
	}
	public String getvCourseName() {
		return vCourseName;
	}
	public void setvCourseName(String vCourseName) {
		this.vCourseName = vCourseName;
	}
	public String getvCourseStart() {
		return vCourseStart;
	}
	public void setvCourseStart(String vCourseStart) {
		this.vCourseStart = vCourseStart;
	}
	public String getvCourseEnd() {
		return vCourseEnd;
	}
	public void setvCourseEnd(String vCourseEnd) {
		this.vCourseEnd = vCourseEnd;
	}
	public String getvCourseClassroom() {
		return vCourseClassroom;
	}
	public void setvCourseClassroom(String vCourseClassroom) {
		this.vCourseClassroom = vCourseClassroom;
	}
	public String getSubjectState() {
		return subjectState;
	}
	public void setSubjectState(String subjectState) {
		this.subjectState = subjectState;
	}
	public String getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(String studentCount) {
		this.studentCount = studentCount;
	}
	
}
