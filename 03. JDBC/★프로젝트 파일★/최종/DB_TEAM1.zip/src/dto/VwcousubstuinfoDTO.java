package dto;

public class VwcousubstuinfoDTO {

	private String vcouname;
	private String vcoustart;
	private String vcounend;
	private String vroomname;
	private String vsubname;
	private String vsubstart;
	private String vsubend;
	private String vbookname;
	private String vsubat;
	private String vsubwri;
	private String vsubprac;
	private String vsubseq;
	private String vcouseq;
	
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcounend() {
		return vcounend;
	}
	public void setVcounend(String vcounend) {
		this.vcounend = vcounend;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVsubstart() {
		return vsubstart;
	}
	public void setVsubstart(String vsubstart) {
		this.vsubstart = vsubstart;
	}
	public String getVsubend() {
		return vsubend;
	}
	public void setVsubend(String vsubend) {
		this.vsubend = vsubend;
	}
	public String getVbookname() {
		return vbookname;
	}
	public void setVbookname(String vbookname) {
		this.vbookname = vbookname;
	}
	public String getVsubat() {
		return vsubat;
	}
	public void setVsubat(String vsubat) {
		this.vsubat = vsubat;
	}
	public String getVsubwri() {
		return vsubwri;
	}
	public void setVsubwri(String vsubwri) {
		this.vsubwri = vsubwri;
	}
	public String getVsubprac() {
		return vsubprac;
	}
	public void setVsubprac(String vsubprac) {
		this.vsubprac = vsubprac;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	
	
	
	
	
}
