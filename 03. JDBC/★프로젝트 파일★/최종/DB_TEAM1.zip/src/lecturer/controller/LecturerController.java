package lecturer.controller;

import java.util.Scanner;

import dto.WarningDTO;
import lecturer.service.ILeAttendanceService;
import lecturer.service.ILeGradeService;
import lecturer.service.ILePercentQuizService;
import lecturer.service.ILeRecommendationService;
import lecturer.service.ILeScheduleService;
import lecturer.service.ILeWarningService;
import lecturer.service.LeAttendanceService;
import lecturer.service.LeGradeService;
import lecturer.service.LePercentQuizService;
import lecturer.service.LeRecommendationService;
import lecturer.service.LeScheduleService;
import lecturer.service.LeWarningService;
import lecturer.view.LecturerAttendanceView;
import lecturer.view.LecturerGradeView;
import lecturer.view.LecturerPercentQuizView;
import lecturer.view.LecturerRecommendationView;
import lecturer.view.LecturerScheduleView;
import lecturer.view.WarningView;
import util.Cls;

public class LecturerController {

	private static LecturerPercentQuizView lecturerPQView;
	private static LecturerRecommendationView lecturerRecommendationView;
	private static LecturerAttendanceView lecturerAttendanceView;
	private static LecturerGradeView lecturerGradeView;
	private static LecturerScheduleView lecturerScheduleView;
	private static WarningView warningView;
	
	private static ILeAttendanceService leAttendanceService;
	private static ILeGradeService leGradeService;
	private static ILePercentQuizService lePercentQuizService;
	private static ILeRecommendationService leRecommendationService;
	private static ILeScheduleService leScheduleService;
	private static ILeWarningService leWarningService;
	
	private static Scanner scan;
	
	static {
		lecturerPQView = new LecturerPercentQuizView();	
		lecturerRecommendationView = new LecturerRecommendationView();
		lecturerAttendanceView = new LecturerAttendanceView();
		lecturerGradeView = new LecturerGradeView();
		lecturerScheduleView = new LecturerScheduleView();
		warningView = new WarningView();
		
		leAttendanceService = new LeAttendanceService();
		leGradeService = new LeGradeService();
		lePercentQuizService = new LePercentQuizService();
		leRecommendationService = new LeRecommendationService();
		leScheduleService = new LeScheduleService();
		leWarningService = new LeWarningService();
		
		scan = new Scanner(System.in);
	}
	
//=================================================================================================================================	
	
	public static void main(String lecturerSeq) throws Exception {

		boolean lecturerLoop = true;
		
		while (lecturerLoop) {
			
			Cls.clearScreen();
			
			lecturerPQView.begin();
			lecturerPQView.menu();
			String select = scan.nextLine();
			
	//---------------------------------------------------------------------------------------------------------
					
			if (select.equals("1")) { //강의 스케줄 관리 메뉴
				
				boolean leScheduleLoop = true;
				
				while (leScheduleLoop) {

					Cls.clearScreen();
					lecturerScheduleView.schedulecheck();//강의 스케줄 첫번째 메뉴
					//강의 스케쥴 관리 view
	
					switch(scan.nextLine()) {
					
					case "1" : //강의예정
						
						leScheduleService.will();
						lecturerScheduleView.thickLine();
						lecturerScheduleView.enterpause();
						
						//main(args);
						break; 
					
					case "2" : //강의 중
						
						leScheduleService.prog(); 
						lecturerScheduleView.inputNum();
						lecturerScheduleView.thickLine();
						//leScheduleService.selectSubject();
						//leScheduleService.selectSubjectcount();
						//leScheduleService.coursestudent();
						
						
						//main(args);
						break; 
					
					case "3" : //강의 종료
						
						//leScheduleService.end();  //return 필요 
//						System.out.println(" 번호를 입력하세요 ");
//						temp1= scan.nextLine();	
//						leScheduleService.substu(temp1);
						
						break; //과정 선택 후 과목,학생 출력
									
					case "0" : leScheduleLoop = false; break;
					
					default : System.out.println("잘못된 입력입니다."); break;
					
					}
					
				}//while : leScheduleLoop			
				
	//---------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("2")) { //배점, 시험 관리 메뉴
				
				lecturerPQView.percentManagement01();
				
				boolean lePercentQuizLoop = true;
				
				while (lePercentQuizLoop) {
					
					Cls.clearScreen();
					select = lecturerPQView.percentManagement02();
					
					//배점, 시험 관리
					if (select.equals("1")) lePercentQuizService.percentQuizManagementMain(lecturerSeq);
					
					//이전 메뉴로 돌아가기
					else if (select.equals("0")) lePercentQuizLoop = false;
					
					//잘못 입력했을 경우
					else continue;

				}//while : lePercentQuizLoop				
				
	//---------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("3")) { //성적 관리 메뉴
							
				boolean leGradeLoop = true;
				
				while (leGradeLoop) {
					
					Cls.clearScreen();
					lecturerGradeView.main();
					
					lecturerGradeView.requireSelct();
					
					String subselect = scan.nextLine();
					
				//-----------------------------------------				
					
					String lecseq = "4";  
					
				//-----------------------------------------					
						
					switch(subselect) 
					
					{
					case "1" : 
								System.out.println("\t성적 입력 메뉴로 이동합니다.");
								lecturerGradeView.pressEnter();
								leGraInsert(lecseq); break;
					
					case "2" : 	System.out.println("\t성적 수정 메뉴로 이동합니다.");
								lecturerGradeView.pressEnter();
								leGraModify(lecseq); break;
					
					case "0" : leGradeLoop = false; break;
					
					default : System.out.println("\t번호를 다시 입력해주세요.");
					}
					
				}//while : leGradeLoop
				
	//---------------------------------------------------------------------------------------------------------			
								
			} else if (select.equals("4")) { //출결 관리 메뉴
				
				//출결 관리
				boolean leAttendanceLoop = true;
				
				while (leAttendanceLoop) {
					
					Cls.clearScreen();
					lecturerAttendanceView.attendanceMenu();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
							
						boolean b = true;
						
						while (b) {
							
							lecturerAttendanceView.title(LecturerAttendanceView.ATTENDANCE);
							leAttendanceService.courseMenu(lecturerSeq);
							
							String courseSeq = scan.nextLine();
							
							lecturerAttendanceView.attendanceSubMenu();
							
							select = scan.nextLine();
							
							if (select.equals("1")) {
								
								leAttendanceService.fullAttendance(courseSeq);
							} else if (select.equals("2") ) {
								
								leAttendanceService.attendanceBySubject(courseSeq);
							} else {
								b = false;
							}
							
						}
					} else {
						leAttendanceLoop = false;
					}
					
				}
				
	//---------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("5")) { //추천서 관리 메뉴
							
				Cls.clearScreen();
				leRecommendationService.recommendationList();
				lecturerRecommendationView.pause();
				
	//---------------------------------------------------------------------------------------------------------
				
				
			} else if (select.equals("6")) {
				
				Cls.clearScreen();
				warningView.title(WarningView.INIMENU);
				select = scan.nextLine();
				
				if (select.equals("1")) {
					
					boolean warningLoop	 = true;
					while (warningLoop)	{
						
						Cls.clearScreen();
						leWarningService.listStudents(lecturerSeq);
						warningView.warningSubMenu();
						select = scan.nextLine();
						
						if (!select.equals("0")) {
							
							WarningDTO student = leWarningService.counsel(lecturerSeq, select);
							int result = leWarningService.insert(student);
							
							if (result == 1) {
								warningView.success();
							} else {
								warningView.failure();
							}
							
						} else {
							warningLoop = false;
						}
					}
				} 
				
	//---------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("0")) { //로그아웃
				
				lecturerLoop = false;
				Cls.clearScreen();
				
			}
			
		}//While : lecturerLoop					
		
	}//Method : main
	

	
//성적 관리
//=================================================================================================================================
	
	private static void leGraModify(String lecseq) {
		
		leGradeService.subject(lecseq); //B03-006 출력 //교사 seq 필요할 듯
		boolean loop = true;
		lecturerGradeView.requireSelct();
		System.out.println("\t[0] 뒤로가기");
		System.out.println("\t[x] 과목 선택");
		
		String select = scan.nextLine();
		while(loop) {
			if(select.equals("0")){
				
				loop = false;
				
			} else {	
				
				leGraallStudent(select); // B03-007 출력
				loop=false;
			}
			
		}					
		
	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void leGraallStudent(String nextLine) {
		
		leGradeService.allstudent(nextLine);//특정 과목 student들 
		String subseq = nextLine; //subject seq
		
		boolean loop = true;
		lecturerGradeView.requireSelct();
		
		System.out.println("\t[0] 뒤로가기");
		System.out.println("\t[x] 선택");
		String select = scan.nextLine();
	
		while(loop) {
			if(select.equals("0")){
				
				loop = false;
				
			} else {	
				
				String temp =leGradeService.alleachstudent(subseq,select); //대상 학생
				leGraallScore(temp);
				
				loop=false;
			}
			
		}
		
	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void leGraallScore(String temp) {
		
		boolean loop = true;
		
		
		while(loop) {
			System.out.println();
			System.out.println("\t\t\t\t[성적수정]");
			lecturerGradeView.title(LecturerGradeView.DOUBLELINE);
			System.out.println("\t[1] 필기점수 수정");
			System.out.println("\t[2] 실기점수 수정");
			System.out.println("\t[0] 뒤로가기");
			lecturerGradeView.title(LecturerGradeView.DOUBLELINE);
			
			lecturerGradeView.requireSelct();
			
			String select = scan.nextLine();
			switch(select) {
			
			case "1" : leGradeService.written(temp);  break;
			
			case "2" : leGradeService.practical(temp);  break;
			
			case "0" :  loop = false; break;
			
			default : System.out.println("잘못된 입력입니다."); System.out.println("번호를 입력하세요."); break;
			
			}
			
		}
		
	}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void leGraInsert(String lecseq) {
		
		boolean loop = true;
		
		while(loop) {
			leGradeService.subject(lecseq); //B03-001 출력
			System.out.println("\t[0] 뒤로가기");
			System.out.println("\t[x] 과목 선택");
			lecturerGradeView.requireSelct();
			
			String select = scan.nextLine();
			if(select.equals("0")){
				loop = false;
			} else {	
				leGraStudent(select); // B03-002 출력
				loop = false;
			}
			
		}
							
		}

//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void leGraStudent(String subinput) {
		
		boolean loop = true;
		while(loop) {
		leGradeService.student(subinput);//특정 과목 student들 
		String subseq = subinput; //subject seq
		
		System.out.println("\t[0] 뒤로가기");
		System.out.println("\t[x] 선택");
		lecturerGradeView.requireSelct();
			
		String select = scan.nextLine();
			if(select.equals("0")){
				
				loop = false;
				
			} else {	
				
			String gradeseq =leGradeService.eachstudent(subseq,select); //대상 학생
																			//student
				leGraScore(gradeseq);
				
				loop = false;
				
			}
			
		}
		
	}
	
//---------------------------------------------------------------------------------------------------------------------------------
	
	private static void leGraScore(String gradeseq) {
		
		boolean loop = true;
		
		while(loop) {
			System.out.println();
			System.out.println();
			System.out.println("\t\t\t\t[성적입력]");
			lecturerGradeView.title(LecturerGradeView.DOUBLELINE);
			System.out.println("\t[1] 필기점수 입력");
			System.out.println("\t[2] 실기점수 입력");
			System.out.println("\t[0] 뒤로가기");
			lecturerGradeView.requireSelct();
			String select = scan.nextLine();
			
			switch(select) {
			
			case "1" : leGradeService.written(gradeseq);   break;
						
			case "2" : leGradeService.practical(gradeseq);  break;
			
			case "0" :  loop = false; break;
			
			default : System.out.println("\t잘못된 입력입니다."); break;
			
			}
		}
		
	}

//=================================================================================================================================
	
		
}//Class : lecturerController


