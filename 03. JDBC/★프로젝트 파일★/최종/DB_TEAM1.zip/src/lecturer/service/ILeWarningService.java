package lecturer.service;

import dto.WarningDTO;

public interface ILeWarningService {

	void listStudents(String lecturerSeq);

	WarningDTO counsel(String lecturerSeq, String select);

	int insert(WarningDTO student);

	


}
