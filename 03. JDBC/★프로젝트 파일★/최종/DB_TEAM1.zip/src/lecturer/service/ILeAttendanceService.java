package lecturer.service;

public interface ILeAttendanceService {

	void courseMenu(String lecturerSeq);
	
	void fullAttendance(String courseSeq);
	
	void attendanceBySubject(String courseSeq);

}
