package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import dto.QuizDTO;
import dto.SubjectDTO;
import lecturer.dao.LecturerPercentQuizDAO;
import lecturer.view.LecturerPercentQuizView;
import util.Cls;

public class LePercentQuizService implements ILePercentQuizService{

	private static LecturerPercentQuizView lecturerPQView;
	private static LecturerPercentQuizDAO lecturerPQDAO;
	private static Scanner scan;
	
	static {
		lecturerPQView = new LecturerPercentQuizView();	
		lecturerPQDAO = new LecturerPercentQuizDAO();
		scan = new Scanner(System.in);
	}
		
	
	
//배점, 시험 관리 - 과정 목록 > 과목 목록 > 배점관리 / 시험관리 선택	
//===================================================================================================================================
	
	@Override
	public void percentQuizManagementMain(String lecturerSeq) {
		
		boolean couseListLoop = true;
		
		while (couseListLoop) {
			
			Cls.clearScreen();
			
			//해당 교사가 강의하는 과정 리스트
			lecturerPQView.title(LecturerPercentQuizView.PERCENTQUIZCOURSELIST);
			
			ArrayList<String> courseList = lecturerPQDAO.courseList(lecturerSeq);
			
			for (int i=0; i<courseList.size(); i++) {
				System.out.println(courseList.get(i));			
			}
			
			String courseSeq = lecturerPQView.courseList01();
			
			if (!courseSeq.equals("0")) {
				
				String courseName = lecturerPQDAO.selectCourseListName(courseSeq);
				lecturerPQView.courseList02(courseName);
				
	//---------------------------------------------------------------------------------------------------------------
				
				//해당 과정 중 강의가 종료된 과목 리스트
				boolean subjectListLoop = true;
				
				while (subjectListLoop) {
					
					Cls.clearScreen();
					
					lecturerPQView.title(LecturerPercentQuizView.PERCENTQUIZSUBJECTLIST);
					
					ArrayList<String> subjectList = lecturerPQDAO.subjectList(courseSeq);
					
					for (int i=0; i<subjectList.size(); i++) {
						System.out.println(subjectList.get(i));			
					}
					
					String subjectSeq = lecturerPQView.subjectList01();
					
					if (!subjectSeq.equals("0")) {
						
						String subjectName = lecturerPQDAO.selectSubjectListName(subjectSeq);
						lecturerPQView.subjectList02(subjectName);
						
	//---------------------------------------------------------------------------------------------------------------
						
						//배점, 시험 관리 선택 화면
						boolean percentQuizManagementLoop = true;
						
						while (percentQuizManagementLoop) {
							
							Cls.clearScreen();
							
							lecturerPQView.title(LecturerPercentQuizView.PERCENTQUIZMANAGEMENT);
							
							ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
							
							for (int i=0; i<subjectPercentQuizList.size(); i++) {
								System.out.println(subjectPercentQuizList.get(i));			
							}
							
							String menuSelect = lecturerPQView.percentQuizManagement();
							
	//---------------------------------------------------------------------------------------------------------------
							
							//배점 관리 메뉴
							if (menuSelect.equals("1")) { 
								
								boolean percentManagementLoop = true;
								
								while (percentManagementLoop) {
									
									Cls.clearScreen();
									
									lecturerPQView.title(LecturerPercentQuizView.PERCENT);
									
									subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
									
									for (int i=0; i<subjectPercentQuizList.size(); i++) {
										System.out.println(subjectPercentQuizList.get(i));			
									}
									
									menuSelect = lecturerPQView.percentManagement();
									
									//배점 추가
									if (menuSelect.equals("1")) percentAdd(courseSeq, subjectSeq);

									//배점 수정
									else if (menuSelect.equals("2")) percentEdit(courseSeq, subjectSeq);
	
									//배점 삭제
									else if (menuSelect.equals("3")) percentDelete(courseSeq, subjectSeq);

									//이전 화면으로 이동
									else if (menuSelect.equals("0")) percentManagementLoop = false; else continue;
									
								}//while : percentManagementLoop
									
	//---------------------------------------------------------------------------------------------------------------
								
							//시험 관리 메뉴
							} else if (menuSelect.equals("2")) { 
								
								boolean quizManagementLoop = true;
								
								while (quizManagementLoop) {
									
									Cls.clearScreen();
									
									lecturerPQView.title(LecturerPercentQuizView.QUIZ);
									
									subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
									
									for (int i=0; i<subjectPercentQuizList.size(); i++) {
										System.out.println(subjectPercentQuizList.get(i));			
									}
									
									menuSelect = lecturerPQView.quizManagement();
									
	//---------------------------------------------------------------------------------------------------------------
									
									//시험 날짜 관리 메뉴
									if (menuSelect.equals("1")) {
										
										boolean quizDateLoop = true;
										
										while (quizDateLoop) {
											
											Cls.clearScreen();
											
											lecturerPQView.title(LecturerPercentQuizView.QUIZDATE);
											
											subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
											
											for (int i=0; i<subjectPercentQuizList.size(); i++) {
												System.out.println(subjectPercentQuizList.get(i));			
											}
											
											menuSelect = lecturerPQView.quizDateManagement();
											
											//시험날짜 입력
											if(menuSelect.equals("1")) quizDateAdd(courseSeq, subjectSeq);
												
											//시험날짜 수정
											else if (menuSelect.equals("2")) quizDateEdit(courseSeq, subjectSeq);
												
											//시험날짜 삭제
											else if (menuSelect.equals("3")) quizDateDelete(courseSeq, subjectSeq);
												
											//이전 화면으로 이동
											else if (menuSelect.equals("0")) quizDateLoop = false; else continue;
											
										}//while : quizDateLoop
										
	//---------------------------------------------------------------------------------------------------------------
										
									//시험 문제 관리 메뉴
									} else if (menuSelect.equals("2")) {
										
										boolean quizQuestionLoop = true;
										
										while (quizQuestionLoop) {
											
											Cls.clearScreen();
											
											lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTION);
											
											subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
											
											for (int i=0; i<subjectPercentQuizList.size(); i++) {
												System.out.println(subjectPercentQuizList.get(i));			
											}
											
											menuSelect = lecturerPQView.quizQuestionManagement();
											
											//시험문제 입력
											if(menuSelect.equals("1")) quizQuestionAdd(courseSeq, subjectSeq);
												
											//시험날짜 수정
											else if (menuSelect.equals("2")) quizQuestionEdit(courseSeq, subjectSeq);
												
											//시험날짜 삭제
											else if (menuSelect.equals("3")) quizQuestionDelete(courseSeq, subjectSeq);
												
											//이전 화면으로 이동
											else if (menuSelect.equals("0")) quizQuestionLoop = false; else continue;
											
										}//while : quizQuestionLoop
										
									} else if (menuSelect.equals("0")) quizManagementLoop = false; else continue;
									
								}//while : quizManagementLoop
																
							} else if (menuSelect.equals("0")) percentQuizManagementLoop = false; else continue;

						}//while : percentQuizManagementLoop(배점관리 / 시험관리 선택 화면)
						
					} else if(subjectSeq.equals("0")) subjectListLoop = false;
					
				}//while : subjectListLoop(과목 선택 화면)
				
			} else if (courseSeq.equals("0")) couseListLoop = false;
			
		}//while : couseListLoop(과정 선택 화면)
		
	}//method : percentManagementMain
	
//===================================================================================================================================

	
	
//배점 입력
//===================================================================================================================================	
	
	@Override
	public void percentAdd(String courseSeq, String subjectSeq) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.PERCENTADD);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
					
			System.out.println("\n");
			System.out.print("\t필기배점 입력(0~100) : ");
			String writtenPercent = scan.nextLine();
			
			System.out.println();
			System.out.print("\t실기배점 입력(0~100) : ");
			String practicalPercent = scan.nextLine();
			
			System.out.println();
			System.out.print("\t출결배점 입력(0~100) : ");
			String attendancePercent = scan.nextLine();
			
			
			//UPDATE 작업
			SubjectDTO subjectDTO = new SubjectDTO();
			subjectDTO.setCourseSeq(courseSeq); //개설 과정 번호
			subjectDTO.setSeq(subjectSeq); //개설 과목 번호
			subjectDTO.setWrittenPercent(writtenPercent);
			subjectDTO.setPracticalPercent(practicalPercent);
			subjectDTO.setAttendancePercent(attendancePercent);

			int result = lecturerPQDAO.percentAdd(subjectDTO);
			
			if (result == 1) {
				lecturerPQView.percentAdd();
			} else {
				System.out.println("실패하였습니다");
			}
		
	}//method : percentAdd
	
//===================================================================================================================================
	
	
	
//배점 수정
//===================================================================================================================================
	
	@Override
	public void percentEdit(String courseSeq, String subjectSeq) {
		
		Cls.clearScreen();
		lecturerPQView.title(LecturerPercentQuizView.PERCENTADD);
		
		ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
		
		for (int i=0; i<subjectPercentQuizList.size(); i++) {
			System.out.println(subjectPercentQuizList.get(i));			
		}
				
		System.out.println();
		System.out.print("\t필기배점 입력(0~100) : ");
		String writtenPercent = scan.nextLine();
		
		System.out.println();
		System.out.print("\t실기배점 입력(0~100) : ");
		String practicalPercent = scan.nextLine();
		
		System.out.println();
		System.out.print("\t출결배점 입력(0~100) : ");
		String attendancePercent = scan.nextLine();
		
		
		//UPDATE 작업
		SubjectDTO subjectDTO = new SubjectDTO();
		subjectDTO.setCourseSeq(courseSeq); //개설 과정 번호
		subjectDTO.setSeq(subjectSeq); //개설 과목 번호
		subjectDTO.setWrittenPercent(writtenPercent);
		subjectDTO.setPracticalPercent(practicalPercent);
		subjectDTO.setAttendancePercent(attendancePercent);

		int result = lecturerPQDAO.percentEdit(subjectDTO);
		
		if (result == 1) {
			lecturerPQView.percentEdit();
		} else {
			System.out.println("실패하였습니다");
		}
		
	}//method : percentEdit
	
//===================================================================================================================================
	
	
	
//배점 삭제
//===================================================================================================================================
	
	@Override
	public void percentDelete(String courseSeq, String subjectSeq) {
		
		boolean percentDeleteLoop = true;
		
		while (percentDeleteLoop) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.PERCENTDELETE);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			String execute = lecturerPQView.percentDelete01();
			
			if (execute.equals("1")) {
				
				//UPDATE 작업
				SubjectDTO subjectDTO = new SubjectDTO();
				subjectDTO.setCourseSeq(courseSeq); //개설 과정 번호
				subjectDTO.setSeq(subjectSeq); //개설 과목 번호

				int result = lecturerPQDAO.percentDelete(subjectDTO);
				
				if (result == 1) {
					lecturerPQView.percentDelete02();
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (execute.equals("0")) percentDeleteLoop = false; else continue;
			
		}//while : percentDeleteLoop
		
	}//method : percentDelete

//===================================================================================================================================
	
	
	
//시험날짜 입력
//===================================================================================================================================
	
	@Override
	public void quizDateAdd(String courseSeq, String subjectSeq) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZDATEADD);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			System.out.println();
			System.out.print("\t시험날짜 입력(0000-00-00) : ");
			String quizDate = scan.nextLine();
			
			
			//UPDATE 작업
			QuizDTO quizDTO = new QuizDTO();
			quizDTO.setSubjectSeq(subjectSeq);; //개설 과목 번호
			quizDTO.setQuizDate(quizDate);

			@SuppressWarnings("unused")
			int result = lecturerPQDAO.quizDateAdd(quizDTO);
			
			lecturerPQView.quizDateAdd();
		
	}//method : quizDateAdd

//===================================================================================================================================
	
	
	
//시험날짜 수정	
//===================================================================================================================================
	
	@Override
	public void quizDateEdit(String courseSeq, String subjectSeq) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZDATEEDIT);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			System.out.println();
			System.out.print("\t새로운 시험날짜 입력(0000-00-00) : ");
			String quizDate = scan.nextLine();
			
			
			//UPDATE 작업
			QuizDTO quizDTO = new QuizDTO();
			quizDTO.setSubjectSeq(subjectSeq);; //개설 과목 번호
			quizDTO.setQuizDate(quizDate);

			@SuppressWarnings("unused")
			int result = lecturerPQDAO.quizDateEdit(quizDTO);
			
			lecturerPQView.quizDateEdit();
		
	}//method : quizDateEdit
	
//===================================================================================================================================
	
	
	
//시험날짜 삭제
//===================================================================================================================================
	
	@Override
	public void quizDateDelete(String courseSeq, String subjectSeq) {
		
		boolean quizDateDeleteLoop = true;
		
		while (quizDateDeleteLoop) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZDATEDELETE);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			String execute = lecturerPQView.quizDateDelete01();
			
			if (execute.equals("1")) {
				
				//UPDATE 작업
				QuizDTO quizDTO = new QuizDTO();
				quizDTO.setSubjectSeq(subjectSeq);; //개설 과목 번호

				int result = lecturerPQDAO.quizDateDelete(quizDTO);
				
				if (result == 1) {
					lecturerPQView.quizDateDelete02();
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (execute.equals("0")) quizDateDeleteLoop = false; else continue;

		}//while : quizDateDeleteLoop
		
	}//method : quizDateDelete

//===================================================================================================================================
	
	
	
//시험문제 추가(INSERT) : 반드시 10문제
//===================================================================================================================================
	
	@Override
	public void quizQuestionAdd(String courseSeq, String subjectSeq) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONADD);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			lecturerPQView.quizQuestionAdd01();
			
			//주관식 문제 입력
			lecturerPQView.quizQuestionAdd02();
			
			for (int i=1; i<=5; i++) {
				
				String quizNumber = Integer.toString(i);
				
				System.out.printf("\t문제%02d : ", i);
				String quizContent = scan.nextLine();
				System.out.print("\n\t정답 : ");
				String quizAnswer = scan.nextLine();
				
				if (i == 5) {
					lecturerPQView.thickLine();
				} else {
					lecturerPQView.thinLine();
				}
				
				//INSERT 작업
				QuizDTO quizDTO = new QuizDTO();
				quizDTO.setNum(quizNumber);
				quizDTO.setContents(quizContent);
				quizDTO.setAnswer(quizAnswer);
				quizDTO.setSubjectSeq(subjectSeq); //개설 과목 번호
				
				lecturerPQDAO.quizQuestionAdd(quizDTO);
				
			}
						
			//객관식 문제 입력
			lecturerPQView.quizQuestionAdd03();
			
			for (int i=6; i<=10; i++) {
				
				String quizNumber = Integer.toString(i);
				
				System.out.printf("\t문제%02d : ", i);
				String quizContent = scan.nextLine();
				System.out.print("\n\t정답 : ");
				String quizAnswer = scan.nextLine();
				
				if (i == 10) {
					lecturerPQView.thickLine();
				} else {
					lecturerPQView.thinLine();
				}
				
				//INSERT 작업
				QuizDTO quizDTO = new QuizDTO();
				quizDTO.setNum(quizNumber);
				quizDTO.setContents(quizContent);
				quizDTO.setAnswer(quizAnswer);
				quizDTO.setSubjectSeq(subjectSeq); //개설 과목 번호
				
				lecturerPQDAO.quizQuestionAdd(quizDTO);
				
			}
		
			lecturerPQView.quizQuestionAdd04();
			
	}//method : quizQuestionAdd

//===================================================================================================================================
	
	
	
//시험문제 수정(UPDATE contents, answer)
//===================================================================================================================================
		
	@Override
	public void quizQuestionEdit(String courseSeq, String subjectSeq) {
		
		boolean quizQuestionEditLoop = true;
		
		while (quizQuestionEditLoop) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONEDIT);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			ArrayList<String> quizQuestionEditList = lecturerPQDAO.quizQuestionDelete(courseSeq, subjectSeq);
			
			for (int i=0; i<quizQuestionEditList.size(); i++) {
				System.out.println(quizQuestionEditList.get(i));	
				if (i != quizQuestionEditList.size() - 1) {
					lecturerPQView.thinLine();
				}	
			}
			
			String quizNumber = lecturerPQView.quizQuestionEdit01();
			
			if (!quizNumber.equals("0")) {
				
				lecturerPQView.quizQuestionEdit02(quizNumber);
				
				boolean quizQuestionEditElementLoop = true;
				
				while (quizQuestionEditElementLoop) {
					
					Cls.clearScreen();
					lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONEDIT);
					
					subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
					
					for (int i=0; i<subjectPercentQuizList.size(); i++) {
						System.out.println(subjectPercentQuizList.get(i));			
					}
					
					String select = lecturerPQView.quizQuestionEdit03();
					
	//---------------------------------------------------------------------------------------------------------------
					
					if (select.equals("1")) { //시험 내용 수정
						
						Cls.clearScreen();
						lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONEDIT);
						
						subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
						
						for (int i=0; i<subjectPercentQuizList.size(); i++) {
							System.out.println(subjectPercentQuizList.get(i));			
						}
						
						System.out.println();
						System.out.print("\t문제 내용 입력 : ");
						String quizContent = scan.nextLine();
						
						QuizDTO quizDTO = new QuizDTO();
						quizDTO.setContents(quizContent);
						quizDTO.setNum(quizNumber);
						quizDTO.setSubjectSeq(subjectSeq); //개설 과목 번호

						int result = lecturerPQDAO.quizQuestionContentEdit(quizDTO);
						
						if (result == 1) {
							lecturerPQView.quizQuestionEdit04(quizNumber);
						} else {
							System.out.println("실패하였습니다");
						}

	//---------------------------------------------------------------------------------------------------------------
						
					} else if (select.equals("2")) { //시험 정답 수정
						
						Cls.clearScreen();
						lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONEDIT);
						
						subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
						
						for (int i=0; i<subjectPercentQuizList.size(); i++) {
							System.out.println(subjectPercentQuizList.get(i));			
						}
						
						System.out.println();
						System.out.print("\t문제 정답 입력 : ");
						String quizAnswer = scan.nextLine();
						
						QuizDTO quizDTO = new QuizDTO();
						quizDTO.setAnswer(quizAnswer);
						quizDTO.setNum(quizNumber);
						quizDTO.setSubjectSeq(subjectSeq); //개설 과목 번호

						int result = lecturerPQDAO.quizQuestionAnswerEdit(quizDTO);
						
						if (result == 1) {
							lecturerPQView.quizQuestionEdit05(quizNumber);
						} else {
							System.out.println("실패하였습니다");
						}
						
					} else if (select.equals("0")) quizQuestionEditElementLoop = false; else continue;
										
				}//while : quizQuestionEditElementLoop
								
			} else if (quizNumber.equals("0")) quizQuestionEditLoop = false;

		}//while : quizQuestionEditLoop
		
	}//method : quizQuestionEdit

//===================================================================================================================================	
	
	
	
//시험문제 삭제(UPDATE state)
//===================================================================================================================================
	
	@Override
	public void quizQuestionDelete(String courseSeq, String subjectSeq) {
		
		boolean quizQuestionDeleteLoop = true;
		
		while (quizQuestionDeleteLoop) {
			
			Cls.clearScreen();
			lecturerPQView.title(LecturerPercentQuizView.QUIZQUESTIONDELETE);
			
			ArrayList<String> subjectPercentQuizList = lecturerPQDAO.subjectPercentQuiz(courseSeq, subjectSeq);
			
			for (int i=0; i<subjectPercentQuizList.size(); i++) {
				System.out.println(subjectPercentQuizList.get(i));			
			}
			
			ArrayList<String> quizQuestionDeleteList = lecturerPQDAO.quizQuestionDelete(courseSeq, subjectSeq);
			
			for (int i=0; i<quizQuestionDeleteList.size(); i++) {
				System.out.println(quizQuestionDeleteList.get(i));	
				if (i != quizQuestionDeleteList.size() - 1) {
					lecturerPQView.thinLine();
				}	
			}
			
			String quizNumber = lecturerPQView.quizQuestionDelete01();
			
			if (!quizNumber.equals("0")) {
				
				//UPDATE 작업
				QuizDTO quizDTO = new QuizDTO();
				quizDTO.setSubjectSeq(subjectSeq);; //개설 과목 번호
				quizDTO.setNum(quizNumber);

				int result = lecturerPQDAO.quizQuestionDeleteExecute(quizDTO);
				
				if (result == 1) {
					lecturerPQView.quizQuestionDelete02(quizNumber);
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (quizNumber.equals("0")) quizQuestionDeleteLoop = false;

		}//while : quizQuestionDeleteLoop
		
	}//method : quizQuestionDelete
	
}//Class : LePercentQuizService
