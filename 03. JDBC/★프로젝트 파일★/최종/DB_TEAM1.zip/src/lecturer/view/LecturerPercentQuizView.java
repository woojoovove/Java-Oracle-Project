package lecturer.view;

import java.util.Scanner;

public class LecturerPercentQuizView {
				
	//배점, 시험관리
	public final static int PERCENTQUIZCOURSELIST = 520;
	public final static int PERCENTQUIZSUBJECTLIST = 521;
	public final static int PERCENTQUIZMANAGEMENT = 522;
	
	public final static int PERCENT = 523;
	public final static int PERCENTADD = 524;
	public final static int PERCENTEDIT = 525;
	public final static int PERCENTDELETE = 526;
	
	public final static int QUIZ = 527;
	
	public final static int QUIZDATE = 528;
	public final static int QUIZDATEADD = 529;
	public final static int QUIZDATEEDIT = 530;
	public final static int QUIZDATEDELETE = 531;
	
	public final static int QUIZQUESTION = 532;
	public final static int QUIZQUESTIONADD = 533;	
	public final static int QUIZQUESTIONEDIT = 534;
	public final static int QUIZQUESTIONDELETE = 535;		
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
//교사 메뉴 메인	
//===============================================================================================================================
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 교사]");
		
	}//Method : begin
	
	public void menu() {
	
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 강의 스케줄 관리\n");
		System.out.println("\t\t\t\t[2] 배점, 시험 관리\n");
		System.out.println("\t\t\t\t[3] 성적 관리\n");
		System.out.println("\t\t\t\t[4] 출결 관리\n");
		System.out.println("\t\t\t\t[5] 추천서 관리\n");
		System.out.println("\t\t\t\t[6] 상담 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu

//===============================================================================================================================

	
	
//배점, 시험 관리
//===============================================================================================================================
			
	public void thinLine() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		
	}//method : line
	
	public void thickLine() {
		
		System.out.println("\t==========================================================================");
		
	}//method : line
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점, 시험 관리 - 메인 메뉴
	public void percentManagement01() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t\t\t\t배점, 시험 관리 메뉴로 이동합니다\n");
		System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");				
		
		scan.nextLine();
		
	}//method : percentManagement01
	
	public String percentManagement02() {
				
		System.out.println("\t\t\t\t[배점, 시험 관리]");
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 과정 선택\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t과정 선택 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : percentManagement02
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점, 시험 관리 - 과정 선택
	public String courseList01() {

		System.out.println("\t과정번호를 선택하면 해당 과정의 과목 정보 페이지로 이동합니다");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0]돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		String select = scan.nextLine();
		
		if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {			
			return select;			
		}
		
	}//method : courseList01
	
	public void courseList02(String courseName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s' 과정을 선택하였습니다\n", courseName);
		System.out.println("\t해당 과정의 과목 관리 페이지로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : courseList02
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점, 시험 관리 - 과목 선택
	public String subjectList01() {
		
		System.out.println("\t종료된 과목만 출력합니다\n");
		System.out.println("\t과목번호를 선택하면 해당 과목의 배점, 시험 관리 페이지로 이동합니다");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0] 돌아가기");	
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {	
			
			return select;
			
		}
		
	}//method : subjectList01
	
	public void subjectList02(String subjectName) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t선택하신 과목명은\n\t'%s'입니다\n\n", subjectName);
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : subjectList02
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점, 시험 관리 선택 화면
	public String percentQuizManagement() {

		System.out.println();
		System.out.println("\t\t\t\t[1] 배점 관리\n");
		System.out.println("\t\t\t\t[2] 시험 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t배점 관리 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 관리 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : percentQuizManagement

//=====================================================================================================================================	
	
	
	
//배점 관리	
//=====================================================================================================================================
	
	//배점 관리 화면
	public String percentManagement() {
		
		System.out.println();
		System.out.println("\t\t\t\t[1] 배점 입력\n");
		System.out.println("\t\t\t\t[2] 배점 수정\n");
		System.out.println("\t\t\t\t[3] 배점 삭제\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t배점 입력 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t배점 수정 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if (select.equals("3")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t배점 삭제 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : percentManagement
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점 추가 화면
	public void percentAdd() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t배점 입력을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : percentAdd
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점 수정 화면
	public void percentEdit() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t배점 수정을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : percentAdd
	
//------------------------------------------------------------------------------------------------------------------------
	
	//배점 삭제 화면
	public String percentDelete01() {
		
		System.out.println();
		System.out.println("\t\t\t\t[1] 삭제 실행\n\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		}
			
	}//method : percentDelete01
	
	public void percentDelete02() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t배점 초기화를 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : percentDelete
	
//=====================================================================================================================================

	
	
//시험 관리
//=====================================================================================================================================
	
	//시험 관리 화면
	public String quizManagement() {
		
		System.out.println();
		System.out.println("\t\t\t\t[1] 시험 날짜 관리\n");
		System.out.println("\t\t\t\t[2] 시험 문제 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 날짜 관리 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 문제 관리 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : quizManagement
	
//------------------------------------------------------------------------------------------------------------------------
	
	//시험 날짜 관리 화면
	public String quizDateManagement() {

		System.out.println();
		System.out.println("\t\t\t\t[1] 시험 날짜 입력\n");
		System.out.println("\t\t\t\t[2] 시험 날짜 수정\n");
		System.out.println("\t\t\t\t[3] 시험 날짜 삭제\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 날짜 입력 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 날짜 수정 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if (select.equals("3")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 날짜 삭제 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
		
		}
	
	}//method : quizDateManagement
	
//------------------------------------------------------------------------------------------------------------------------
	
	//시험날짜 입력 화면
	public void quizDateAdd() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t시험날짜 입력을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizDateAdd
	
//------------------------------------------------------------------------------------------------------------------------
	
	//시험날짜 수정 화면
	public void quizDateEdit() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t시험날짜 수정을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizDateEdit
	
//------------------------------------------------------------------------------------------------------------------------
	
	//시험날짜 삭제 화면
	public String quizDateDelete01() {

		System.out.println();
		System.out.println("\t\t\t\t[1] 삭제 실행\n\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		}
		
	}//method : quizDateDelete01
	
	public void quizDateDelete02() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t시험날짜 초기화를 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizDateDelete02
	
//------------------------------------------------------------------------------------------------------------------------

	//시험 문제 관리 화면
	public String quizQuestionManagement() {

		System.out.println();
		System.out.println("\t\t\t\t[1] 시험 문제 입력\n");
		System.out.println("\t\t\t\t[2] 시험 문제 수정\n");
		System.out.println("\t\t\t\t[3] 시험 문제 삭제\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 문제 입력 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 문제 수정 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if (select.equals("3")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t시험 문제 삭제 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
		
		}
		
	}//method : quizQuestionManagement
	
//------------------------------------------------------------------------------------------------------------------------	
	
	//시험 문제 입력 화면
	public void quizQuestionAdd01() {
		
		System.out.println("\t고용노동부 지침에 따라 반드시 10문제를 모두 입력해야 합니다");
		System.out.println("\t문제 내용은 60자를 넘지 않아야 합니다");
		System.out.println("\t==========================================================================");
		
	}//method : quizQuestionAdd01
	
	public void quizQuestionAdd02() {
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t주관식 문제 (1~5)");
		System.out.println("\t==========================================================================");
		
	}//method : quizQuestionAdd02
	
	public void quizQuestionAdd03() {
		
		System.out.println("\n\t==========================================================================");
		System.out.println("\t객관식 문제(6~10) : 맞으면 O , 틀리면 X");
		System.out.println("\t==========================================================================");
		
	}//method : quizQuestionAdd03

	public void quizQuestionAdd04() {
		
		System.out.println("\t시험문제 입력을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizQuestionAdd02
	
//------------------------------------------------------------------------------------------------------------------------	
	
	//시험문제 수정 화면 - 문제번호 선택
	public String quizQuestionEdit01() {

		System.out.println("\t==========================================================================");
		System.out.println("\t수정할 문제 번호를 선택하십시오");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (!select.equals("0")) {
			
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
		return null;
		
	}//method : quizQuestionEdit01
	
	public void quizQuestionEdit02(String quizNumber) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'번 문제를 수정합니다\n", quizNumber);
		System.out.println("\t수정 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizQuestionEdit02
	
	
	//수정 항목 선택
	public String quizQuestionEdit03() {
		
		System.out.println();
		System.out.println("\t\t\t\t[1] 내용 수정\n");
		System.out.println("\t\t\t\t[2] 정답 수정\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t내용 수정 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if (select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t정답 수정 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
		
		}
		
	}//method : quizQuestionEdit03
	
	
	//시험 문제 내용 수정
	public void quizQuestionEdit04(String quizNumber) {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'번 문제의 내용을 수정하였습니다\n", quizNumber);
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizQuestionEdit04
	
	
	//시험 문제 정답 수정
	public void quizQuestionEdit05(String quizNumber) {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'번 문제의 정답을 수정하였습니다\n", quizNumber);
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizQuestionEdit05
	
//------------------------------------------------------------------------------------------------------------------------	
	
	//시험문제 삭제 화면
	public String quizQuestionDelete01() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t삭제할 문제 번호를 선택하십시오");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (!select.equals("0")) {
			
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
		return null;
		
	}//method : quizQuestionDelete01
	
	public void quizQuestionDelete02(String quizNumber) {
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.printf("\t'%s'번 문제를 삭제하였습니다\n", quizNumber);
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}//method : quizQuestionDelete02
	
//===============================================================================================================================
	
	

//화면 타이틀	
//===============================================================================================================================
	
	public void title(int n) {
	
		switch(n)
		{
		
		//배점 관리
		case LecturerPercentQuizView.PERCENTQUIZCOURSELIST	: 
			System.out.println("\t\t\t\t[배점, 시험 관리 - 과정 목록]"); 
			System.out.println("\n\t==========================================================================");
			break;	
		case LecturerPercentQuizView.PERCENTQUIZSUBJECTLIST : 
			System.out.println("\t\t\t\t[배점, 시험 관리 - 과목 목록]"); 
			break;
		case LecturerPercentQuizView.PERCENTQUIZMANAGEMENT : 
			System.out.println("\t\t\t\t[배점, 시험 관리]");
			System.out.println("\n\t==========================================================================");			
			break;
			
			
		case LecturerPercentQuizView.PERCENT : 
			System.out.println("\t\t\t\t[배점 관리]"); 
			System.out.println("\n\t==========================================================================");
			break;	
		case LecturerPercentQuizView.PERCENTADD : 
			System.out.println("\t\t\t\t[배점 관리 - 배점 입력]"); 
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.PERCENTEDIT : 
			System.out.println("\t\t\t\t[배점 관리 - 배점 수정]");
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.PERCENTDELETE : 
			System.out.println("\t\t\t\t[배점 관리 - 배점 초기화]");
			System.out.println("\n\t==========================================================================");
			break;
			
			
		case LecturerPercentQuizView.QUIZ : 
			System.out.println("\t\t\t\t[시험 관리]"); 
			System.out.println("\n\t==========================================================================");
			break;	
			
			
		case LecturerPercentQuizView.QUIZDATE : 
			System.out.println("\t\t\t\t[시험날짜 관리]"); 
			System.out.println("\n\t==========================================================================");
			break;		
		case LecturerPercentQuizView.QUIZDATEADD : 
			System.out.println("\t\t\t\t[시험날짜 입력]"); 
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.QUIZDATEEDIT : 
			System.out.println("\t\t\t\t[시험날짜 수정]"); 
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.QUIZDATEDELETE : 
			System.out.println("\t\t\t\t[시험날짜 삭제]");
			System.out.println("\n\t==========================================================================");
			break;
			
			
		case LecturerPercentQuizView.QUIZQUESTION : 
			System.out.println("\t\t\t\t[시험문제 관리]"); 
			System.out.println("\n\t==========================================================================");
			break;	
		case LecturerPercentQuizView.QUIZQUESTIONADD : 
			System.out.println("\t\t\t\t[시험문제 입력]"); 
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.QUIZQUESTIONEDIT : 
			System.out.println("\t\t\t\t[시험문제 수정]"); 
			System.out.println("\n\t==========================================================================");
			break;
		case LecturerPercentQuizView.QUIZQUESTIONDELETE : 
			System.out.println("\t\t\t\t[시험문제 삭제]"); 
			System.out.println("\n\t==========================================================================");
			break;
		
		}//switch End	
		
	}
	
}//Class : LecturerView
