﻿package lecturer.view;

import java.util.Scanner;

public class LecturerScheduleView {
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
	//강의 스케줄 조회
	public final static int SCHEDULESERVICE = 510;
	public final static int SCHEDULESERVICEYET = 511;
	public final static int SCHEDULESERVICECURRENT = 512;
	public final static int SCHEDULESERVICEEND = 513;	
	
//-----------------------------------------------------------------
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 교사]");
		
	}//Method : begin
	
//-----------------------------------------------------------------
	
	public void menu() {
	
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 강의 스케줄 관리\n");
		System.out.println("\t\t\t\t[2] 배점 관리\n");
		System.out.println("\t\t\t\t[3] 성적 관리\n");
		System.out.println("\t\t\t\t[4] 출결 관리\n");
		System.out.println("\t\t\t\t[5] 추천서 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu

//라인
//==================================================================================================================================
				
	public void thinLine() {
			
		System.out.println("\t--------------------------------------------------------------------------");
			
	}//method : line
		
	public void thickLine() {
			
		System.out.println("\t==========================================================================");
			
	}//method : line
			
	
//============================================================================================
//강의스케줄관리
	
	//
	public void inputNum() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		scan.nextLine();
		
	}//method : addCourseName01

	
	public void enterpause() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t계속하려면 엔터를 입력하세요.");
		
		scan = new Scanner(System.in);
		scan.nextLine();
		
	}
	
//---------------------------------------------------------------------------------------------------
		
	//강의 스케줄 첫번째 메뉴
	public void schedulecheck() {
	
		System.out.println("\t\t\t\t[강의 스케줄 관리]");
		
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 강의 예정\n");
		System.out.println("\t\t\t\t[2] 강의 중\n");
		System.out.println("\t\t\t\t[3] 강의 종료\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}
	
//------------------------------------------------------------------------------------------------	
	
	public void title(int n) {
	
		switch(n)
		{

		//강의 스케줄 조회
		case LecturerScheduleView.SCHEDULESERVICE :
			System.out.println("\t\t\t\t[강의 스케줄 조회]"); 
			break;		
		case LecturerScheduleView.SCHEDULESERVICEYET : 
			System.out.println("\t\t\t\t[강의 예정 스케줄]"); 
			break;
		case LecturerScheduleView.SCHEDULESERVICECURRENT : 
			System.out.println("\t\t\t\t[강의 중 스케줄]"); 
			break;
		case LecturerScheduleView.SCHEDULESERVICEEND : 
			System.out.println("\t\t\t\t[강의종료 스케줄]"); 
			break;	
		
		}
		
	}
	
}//Class : LecturerView

