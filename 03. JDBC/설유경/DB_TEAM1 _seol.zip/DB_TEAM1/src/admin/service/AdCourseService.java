package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.AdministratorCourseDAO;
import admin.AdministratorView;
import dto.CourseDTO;
import dto.CourseNameDTO;
import dto.SubjectDTO;
import util.Cls;

public class AdCourseService implements IAdCourseService {

	private static AdministratorView administratorView;
	private static AdministratorCourseDAO adminDAO;
	private static Scanner scan;
	
	static {
		administratorView = new AdministratorView();
		adminDAO = new AdministratorCourseDAO();
		scan = new Scanner(System.in);
	}
	
	
//과정 추가	
//===================================================================================================================================
	
	@Override
	public void courseAdd() {
		
		Cls.clearScreen();
				
		//과정명 선택
		administratorView.title(AdministratorView.ADDCOURSENAME);
		
		ArrayList<String> courseNameList = adminDAO.courseNameList();
		
		for (int i=0; i<courseNameList.size(); i++) {
			
			System.out.println(courseNameList.get(i));		
			if (i != courseNameList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String courseNameSeq = administratorView.addCourseName01();	
		String courseName = adminDAO.selectCourseName(courseNameSeq);
		administratorView.addCourseName02(courseName);
		
		Cls.clearScreen();

	//-----------------------------------------------------------------------------------------------		
		
		//과정 기간 입력
		administratorView.title(AdministratorView.ADDCOURSEDATE);
		
		System.out.println();
		System.out.print("\t과정 시작일(0000-00-00) : ");
		String startDate = scan.nextLine();
		
		System.out.println();
		System.out.print("\t과정 종료일(0000-00-00) : ");
		String endDate = scan.nextLine();
				
		administratorView.addCourseDate(startDate, endDate);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------
		
		//강의실 선택
		administratorView.title(AdministratorView.ADDCOURSECLASSROOM);
		
		ArrayList<String> classroomList = adminDAO.classroomList();
		
		for (int i=0; i<classroomList.size(); i++) {
			
			System.out.println(classroomList.get(i));		
			if (i != classroomList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String classroomSeq = administratorView.addCourseClassroom01();
		administratorView.addCourseClassroom02(classroomSeq);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------
		
		//교사 선택
		administratorView.title(AdministratorView.ADDCOURSELECTURER);
		
		ArrayList<String> lecturerList = adminDAO.lecturerList();
		
		for (int i=0; i<lecturerList.size(); i++) {
			
			System.out.println(lecturerList.get(i));		
			if (i != lecturerList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String lecturerSeq = administratorView.addLecturer01();
		String lecturerName = adminDAO.selectLecturer(lecturerSeq);
		administratorView.addLecturer02(lecturerName);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------

		//추가 작업 : INSERT
		CourseDTO courseDto = new CourseDTO();
		courseDto.setStartDate(startDate);
		courseDto.setEndDate(endDate);
		courseDto.setCourseNameSeq(courseNameSeq);
		courseDto.setClassroomSeq(classroomSeq);
		courseDto.setLecturerSeq(lecturerSeq);

		int result = adminDAO.courseAdd(courseDto);
		
		if (result == 1) {
			administratorView.courseAddFinish();
		} else {
			System.out.println("실패하였습니다");
		}
		
	}//Method : courseAdd

//===================================================================================================================================

	

//과정 수정	
//===================================================================================================================================	
	
	@Override
	public void courseEdit() {
		
		boolean courseEditLoop = true;
		
		while (courseEditLoop) {
			
			Cls.clearScreen();
					
			//수정할 과정 선택
			administratorView.title(AdministratorView.EDITCOURSE);
			
			ArrayList<String> courseEditList = adminDAO.courseEdit();
			
			for (int i=0; i<courseEditList.size(); i++) {
				System.out.println(courseEditList.get(i));			
			}
			
			String oldCourseNameSeq = administratorView.courseEdit01();
			
			if (!oldCourseNameSeq.equals("0")) {
				
				String courseName = adminDAO.selectCourseEdit(oldCourseNameSeq);
				administratorView.courseEdit02(courseName);
								
	//-----------------------------------------------------------------------------------------------		

				//수정할 요소 선택
				
				boolean courseEditElementLoop = true;
				
				while (courseEditElementLoop) {
					
					Cls.clearScreen();
					
					administratorView.title(AdministratorView.EDITCOURSEELEMENT);
					
					ArrayList<String> editCourseType = adminDAO.editCourseType(oldCourseNameSeq);
					
					for (int i=0; i<editCourseType.size(); i++) {
						System.out.println(editCourseType.get(i));			
					}
					
					String editElement = administratorView.courseEditElement();

					Cls.clearScreen();
					
	//-----------------------------------------------------------------------------------------------
							
					if (editElement.equals("1")) {
						
						//과정명 수정 - 새 과정명 선택
						administratorView.title(AdministratorView.EDITCOURSENAME);						
						String oldCourseName = adminDAO.oldCourseName(oldCourseNameSeq);
						System.out.println("\t기존 과정명 : " + oldCourseName);
						administratorView.thickLine();
						
						ArrayList<String> courseNameList = adminDAO.courseNameList();
						
						for (int i=0; i<courseNameList.size(); i++) {
							
							System.out.println(courseNameList.get(i));		
							if (i != courseNameList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newCourseNameSeq = administratorView.editCourseName01();	
						String newCourseName = adminDAO.selectCourseName(newCourseNameSeq);						
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setCourseNameSeq(newCourseNameSeq);

						int result = adminDAO.editCourseName(courseDto);
						
						if (result == 1) {
							administratorView.editCourseName02(newCourseName);
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("2")) {
						
						//과정기간 수정 - 기존 과정기간
						administratorView.title(AdministratorView.EDITCOURSEDATE);						
						String oldCourseDate = adminDAO.oldCourseDate(oldCourseNameSeq);
						System.out.println("\t기존 과정기간 : " + oldCourseDate);
						administratorView.thickLine();					
						
						
						//UPDATE 작업
						System.out.println();
						System.out.print("\t과정 시작일(0000-00-00) : ");
						String startDate = scan.nextLine();
						
						System.out.println();
						System.out.print("\t과정 종료일(0000-00-00) : ");
						String endDate = scan.nextLine();

						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setStartDate(startDate);
						courseDto.setEndDate(endDate);
						
						int result = adminDAO.editCourseDate(courseDto);
						
						if (result == 1) {
							administratorView.editCourseDate();
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("3")) {
						
						//강의실 수정 - 기존 강의실
						administratorView.title(AdministratorView.EDITCOURSECLASSROOM);						
						String oldCourseClassroom = adminDAO.oldCourseClassroom(oldCourseNameSeq);
						System.out.println("\t기존 강의실 : " + oldCourseClassroom);
						administratorView.thickLine();	
						administratorView.editCourseClassroom01();	
						
						ArrayList<String> classroomList = adminDAO.classroomList();
						
						for (int i=0; i<classroomList.size(); i++) {
							
							System.out.println(classroomList.get(i));		
							if (i != classroomList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newClassroomSeq = administratorView.addCourseClassroom01();												
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setCourseNameSeq(newClassroomSeq);

						int result = adminDAO.editCourseClassroom(courseDto);
						
						if (result == 1) {
							administratorView.editCourseClassroom02(newClassroomSeq);
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("4")) {
						
						//교사 수정 - 기존 교사
						administratorView.title(AdministratorView.EDITCOURSELECTURER);						
						String oldCourseLecturer = adminDAO.oldCourseLecturer(oldCourseNameSeq);
						System.out.println("\t기존 교사 : " + oldCourseLecturer);
						administratorView.thickLine();	
						administratorView.editCourseLecturer01();
						
						ArrayList<String> lecturerList = adminDAO.lecturerList();
						
						for (int i=0; i<lecturerList.size(); i++) {
							
							System.out.println(lecturerList.get(i));		
							if (i != lecturerList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newLecturerSeq = administratorView.addLecturer01();
						String lecturerName = adminDAO.selectLecturer(newLecturerSeq);
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setLecturerSeq(newLecturerSeq);;

						int result = adminDAO.editCourseLecturer(courseDto);
						
						if (result == 1) {
							administratorView.editCourseLecturer02(lecturerName);
						} else {
							System.out.println("실패하였습니다");
						}
											
					} else if (editElement.equals("0")) courseEditElementLoop = false;					
								
				}//while : courseEditElementLoop
								
			} else if (oldCourseNameSeq.equals("0")) courseEditLoop = false;	
			
		}//while : courseEditLoop
				
	}//method : courseEdit	
		
//===================================================================================================================================


	
//과정 삭제
//===================================================================================================================================	

	@Override
	public void courseDelete() {
		
		boolean courseDeleteLoop = true;
		
		while (courseDeleteLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.DELTETECOURSE);
			
			ArrayList<String> courseEditList = adminDAO.courseEdit();
			
			for (int i=0; i<courseEditList.size(); i++) {
				System.out.println(courseEditList.get(i));			
			}
			
			String deleteCourseSeq = administratorView.courseDelete();
			
			if (!deleteCourseSeq.equals("0")) {
				
				String deleteCourseName = adminDAO.selectCourseName(deleteCourseSeq);	
				
				//DELETE 작업
				CourseDTO courseDto = new CourseDTO();
				courseDto.setSeq(deleteCourseSeq);

				int result = adminDAO.courseDelete(courseDto);
				
				if (result == 1) {
					administratorView.courseDeleteFinish(deleteCourseName);
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (deleteCourseSeq.equals("0")) courseDeleteLoop = false;
			
		}//while : courseDeleteLoop
		
	}//method : courseDelete
	
//===================================================================================================================================



//과정 목록	
//===================================================================================================================================
	
	@Override
	public void courseList() {
		
		boolean courseListLoop = true;
		
		while (courseListLoop) {
			
			Cls.clearScreen();
			
			//개설 과정 리스트
			administratorView.title(AdministratorView.COURSELIST);
			
			ArrayList<String> courseList = adminDAO.courseList();
			
			for (int i=0; i<courseList.size(); i++) {
				System.out.println(courseList.get(i));			
			}
			
			String courseSeq = administratorView.courseList01();
			
			if (!courseSeq.equals("0")) {
				
				String courseName = adminDAO.selectCourseListName(courseSeq);			
				administratorView.courseList02(courseName);
								
	//-------------------------------------------------------------------------------
				
				//과목 관리 메뉴			
				boolean subjectManagementLoop = true;
				
				while (subjectManagementLoop) {
					
					Cls.clearScreen();
					
					administratorView.title(AdministratorView.COURSELIST);
					
					ArrayList<String> selectCourseListInfo = adminDAO.selectCourseListInfo(courseSeq);
					
					for (int i=0; i<selectCourseListInfo.size(); i++) {
						System.out.println(selectCourseListInfo.get(i));			
					}
					
					String subjectElement = administratorView.courseManagementMenu();
					
					if (!subjectElement.equals("0")) {
											
						if (subjectElement.equals("1")) 		subjectList(courseSeq);
						
						else if (subjectElement.equals("2")) 	subjectAdd();
						
						else if (subjectElement.equals("3")) 	subjectEdit();
						
						else if (subjectElement.equals("4")) 	subjectDelete(courseSeq);
						
						else if (subjectElement.equals("5")) 	courseStudentList();			
						
					} else if (subjectElement.equals("0")) subjectManagementLoop = false;
					
				}//while : subjectManagementLoop
								
			} else if (courseSeq.equals("0")) courseListLoop = false;
						
		}//while : courseListLoop
		
	}//Method ; courseList

//===================================================================================================================================	

	
	
//과목 추가	
//===================================================================================================================================	
	
	@Override
	public void subjectAdd() {
		
		boolean subjectAddLoop = true;
		
		while (subjectAddLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.ADDSUBJECT);
			
			
			
			
		}//while : subjectAddLoop
		
	}//method : subjectAdd

//===================================================================================================================================

	
	
//과목 정보
//===================================================================================================================================

	@Override
	public void subjectList(String courseSeq) {
		
		boolean subjectListLoop = true;
		
		while (subjectListLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.SUBJECTLIST);
			
			ArrayList<String> subjectList = adminDAO.subjectList(courseSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));			
			}
			
			String select = administratorView.subjectList();
			
			if (select.equals("0")) {
				subjectListLoop = false;
			} else {
				System.out.println("\t잘못된 입력입니다");
			}
			
		}//while : subjectListLoop
				
	}//method : subjectList

//===================================================================================================================================
	
	
	
//과목 수정
//===================================================================================================================================

	@Override
	public void subjectEdit() {
		
		boolean subjectEditLoop = true;
		
		while (subjectEditLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.EDITSUBJECT);
			
			
			
			
		}//while : subjectEditLoop
		
	}//method : subjectEdit

//===================================================================================================================================

	
	
//과목 삭제
//===================================================================================================================================
	
	@Override
	public void subjectDelete(String courseSeq) {
		
		boolean subjectDeleteLoop = true;
		
		while (subjectDeleteLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.DELETESUBJECT);
			
			ArrayList<String> deleteSubjectList = adminDAO.deleteSubjectList(courseSeq);
			
			for (int i=0; i<deleteSubjectList.size(); i++) {
				System.out.println(deleteSubjectList.get(i));			
			}
			
			String subjectSeq = administratorView.deleteSubjectList();
			
			if (!subjectSeq.equals("0")) {
				
				String deleteSubjectName = adminDAO.deleteSubjectName(subjectSeq);
				
				//과목 삭제 작업 : UPDATE state
				SubjectDTO subjectDTO = new SubjectDTO();
				subjectDTO.setSeq(subjectSeq);

				int result = adminDAO.deleteSubject(subjectDTO);
				
				if (result == 1) {
					administratorView.deleteSubjectFinish(deleteSubjectName);
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (subjectSeq.equals("0")) subjectDeleteLoop = false;	
			
		}//while : subjectDeleteLoop
		
	}//method : subjectDelete

//===================================================================================================================================

	
	
//교육생 정보
//===================================================================================================================================
	
	@Override
	public void courseStudentList() {
		
		boolean courseStudentListLoop = true;
		
		while (courseStudentListLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorView.COURSESTUDENT);
			
			
			
			
		}//while : courseStudentListLoop
		
	}//method : courseStudentList

}//Class : AdCourseService
