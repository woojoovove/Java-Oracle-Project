package admin.service;

public interface IAdminService {


	
}
