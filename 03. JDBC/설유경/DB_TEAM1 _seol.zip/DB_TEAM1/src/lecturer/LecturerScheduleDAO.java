package lecturer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCountStudentDTO;
import dto.VwCourseDTO;
import dto.VwStudentCountDTO;
import dto.VwStudentDTO;
import dto.VwSubjectDTO;
import util.DBUtil;



public class LecturerScheduleDAO {

	private static final Object input = null;
	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;



	public LecturerScheduleDAO() {
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("LecturerScheduleDAO.Constructor");
		}	
	}//LecturerScheduleDAO()
//------------------------------------------------------------
	
	public boolean isConnected() {
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}//isConnected()

//--------------------------------------------------------	
	public void close() {
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//close()
//-------------------------------------------------	

	public ArrayList<VwCourseDTO> willcoursecheck() {
		//강의예정 과정정보
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate > sysdate",2);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> willcoursecheck = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseName(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					willcoursecheck.add(dto);
					
				}//while
				
			return willcoursecheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}//willcoursecheck
	


	public ArrayList<VwSubjectDTO> willsubjectcheck() {
		//강의예정 과목정보
		try {
			String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject WHERE vlecturerseq = %s ", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> willsubjectcheck = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					dto.setvTextbook(rs.getString("vTextbook"));
	
		
					willsubjectcheck.add(dto);
					
				}//while
				
			return willsubjectcheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//willsubjectcheck

	
//-------------------------------------------------------------------------------------	
	
	public ArrayList<VwCourseDTO> progcoursecheck() {
		//강의중 과정정보
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate < sysdate AND VcourseEndDate > sysdate", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> progcoursecheck = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseSeq(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					progcoursecheck.add(dto);
					
				}//while
				
			return progcoursecheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}//progcoursecheck
	
	
	
	public ArrayList<VwCountStudentDTO> progcountcheck() {
		//강의중 과정 등록인원
		try {
			String sql = String.format("SELECT vcount FROM VWCountStudent WHERE vlecturerseq = %s AND VcourseStartDate < sysdate AND vcourseEndDate > sysdate", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCountStudentDTO> progcount = new ArrayList<VwCountStudentDTO>();
			
				while(rs.next()) {
					
					VwCountStudentDTO dto = new VwCountStudentDTO();
					
					dto.setVcount(rs.getString("vcount"));
					
					progcount.add(dto);
					
				}//while
				
				return progcount;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}
	
	
	public ArrayList<VwSubjectDTO> progsubjectcheck() {
		//강의중 과목정보
		try {
			String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject WHERE vlecturerseq = %s order by vsubjectSeq", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> progsubjectcheck = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					dto.setvTextbook(rs.getString("vTextbook"));
	
		
					progsubjectcheck.add(dto);
					
				}//while
				
			return progsubjectcheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//progsubjectcheck
	
	
	public ArrayList<VwSubjectDTO> subjectcheck(String selectnum, String inputnum) {
	//선택한 과목정보	
		try {
		
		String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook, vlecturerName FROM VwSubject  WHERE vlecturerseq = %s AND vsubjectSeq= %s", selectnum, input);
		ResultSet rs = stat.executeQuery(sql);

		ArrayList<VwSubjectDTO> subjectcheck = new ArrayList<VwSubjectDTO>();
		
			while(rs.next()) {
				
				VwSubjectDTO dto = new VwSubjectDTO();
				
				dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
				dto.setVsubjectName(rs.getString("vsubjectName"));
				dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
				dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
				dto.setvTextbook(rs.getString("vTextbook"));
				dto.setVlecturerName(rs.getString("vlecturerName"));

				subjectcheck.add(dto);
			}//while	
		return subjectcheck;
		
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}	
	
	public ArrayList<VwCountStudentDTO> progCount() {
		//강의중 과정 등록인원
		try {
			String sql = String.format("SELECT vcount FROM VwCountStudent WHERE vlecturerSeq = %s AND VcourseStartDate < sysdate AND VcourseEndDate > sysdate", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCountStudentDTO> progCount = new ArrayList<VwCountStudentDTO>();
			
				while(rs.next()) {
					
					VwCountStudentDTO dto = new VwCountStudentDTO();
					
					dto.setVcount(rs.getString("vcount"));
					
					progCount.add(dto);
					
				}//while
				
				return progCount;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}
	
	public ArrayList<VwStudentDTO> courseStudent(String selectnum, String inputnum) {
		//강의중 과정 교육생
		try {
			String sql = String.format("SELECT vstudentSeq, vstudentName,  vphoneNum, vregistrationtime, vstudentstatus FROM vwStudent WHERE vcourseSeq = %s ", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwStudentDTO> courseStudent = new ArrayList<VwStudentDTO>();
			
				while(rs.next()) {
					
					VwStudentDTO dto = new VwStudentDTO();
					
					dto.setVstudentSeq(rs.getString("vstudentSeq"));
					dto.setVstudentName(rs.getString("vstudentName"));
					dto.setVphoneNum(rs.getString("vphoneNum"));
					dto.setVregistrationtime(rs.getString("vregistrationtime"));
					dto.setVstudentstatus(rs.getString("vstudentstatus"));
	
		
					courseStudent.add(dto);
					
				}//while
				
			return courseStudent;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//willsubjectcheck
	
	
	public ArrayList<VwCourseDTO> endcourse() {
		//강의종료 과정출력
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s  AND VcourseEndDate < sysdate  ", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> endcourse = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseSeq(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					endcourse.add(dto);
					
				}//while
				
			return endcourse;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;
	}//endcourse
	
	public ArrayList<VwCourseDTO> end(String in) {
		//강의종료 과정정보
		try {
			String sql = String.format("SELECT VcourseSeq, VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate < sysdate AND VcourseSeq = %s",4, in);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwCourseDTO> willcoursecheck = new ArrayList<VwCourseDTO>();
			
				while(rs.next()) {
					
					VwCourseDTO dto = new VwCourseDTO();
					
					dto.setVcourseName(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("VcourseName"));
					dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
					dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
					dto.setVclassroom(rs.getString("Vclassroom"));
	
		
					willcoursecheck.add(dto);
					
				}//while
				
			return willcoursecheck;
			
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		return null;

	}//end
	
	public ArrayList<VwSubjectDTO> endsubject(String in) {
		//강의중 과목정보
		try {
			String sql = String.format("SELECT vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject WHERE vsubjectStartDate < sysdate AND  vsubjectEndDate > sysdate AND vlecturerseq = %s ", 4);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> endsubject = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					dto.setvTextbook(rs.getString("vTextbook"));
	
		
					endsubject.add(dto);
					
				}//while
				
			return endsubject;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//endsubject

	public ArrayList<VwSubjectDTO> substu(String course) {
		//강의중 과목정보
		try {
			String sql = String.format("SELECT vcourseSeq, vcourseName, vsubjectSeq, vsubjectName,  vsubjectStartDate, vsubjectEndDate FROM VwSubject WHERE vsubjectStartDate < sysdate AND  vsubjectEndDate > sysdate AND vlecturerseq = %s  AND vlecturerseq = %s", 4, course);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectDTO> substu = new ArrayList<VwSubjectDTO>();
			
				while(rs.next()) {
					
					VwSubjectDTO dto = new VwSubjectDTO();
					
					dto.setVcourseSeq(rs.getString("vcourseSeq"));
					dto.setVcourseName(rs.getString("vcourseName"));
					dto.setVsubjectSeq(rs.getString("vsubjectSeq"));
					dto.setVsubjectName(rs.getString("vsubjectName"));
					dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
					dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
					
	
		
					substu.add(dto);
					
				}//while
				
			return substu;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//substu
	

	public ArrayList<VwStudentDTO> endstudent(String selectnum, String in) {
		//강의중 과정 교육생
		try {
			String sql = String.format("SELECT vstudentSeq, vstudentName,  vphoneNum, vregistrationtime, vstudentstatus FROM vwStudent WHERE vcourseSeq = %s AND vcourseSeq =%s ", 4, in);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwStudentDTO> endstudent = new ArrayList<VwStudentDTO>();
			
				while(rs.next()) {
					
					VwStudentDTO dto = new VwStudentDTO();
					
					dto.setVstudentSeq(rs.getString("vstudentSeq"));
					dto.setVstudentName(rs.getString("vstudentName"));
					dto.setVphoneNum(rs.getString("vphoneNum"));
					dto.setVregistrationtime(rs.getString("vregistrationtime"));
					dto.setVstudentstatus(rs.getString("vstudentstatus"));
	
		
					endstudent.add(dto);
					
				}//while
				
			return endstudent;
			
			} catch (Exception e) {
				System.out.println(e.toString());
	
			}
		return null;
	}//endstudent
	
}//class










