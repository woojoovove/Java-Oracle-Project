package lecturer.service;

public interface ILeAttendanceService {

	void course();

	void course(String nextLine);

	void allview();

	void month();

	void month(String nextLine);

	void viewday();

}
