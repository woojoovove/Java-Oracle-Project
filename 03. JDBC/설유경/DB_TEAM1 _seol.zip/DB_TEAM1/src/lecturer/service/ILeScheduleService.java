package lecturer.service;

import java.util.Scanner;

public interface ILeScheduleService {

	void will();

	void prog();

	void substu(Scanner scan);

	void end();

	void subject(String selcou);

	void selectSubject();

	void selectSubjectcount();

	void coursestudent();

	String endcourse();

	Scanner endsubject(String in);

	void substu(String course);

	void endstudent(String selectnum, Scanner input);

	void end(Scanner input);

	void progcount();

	void progsubject();

	

	String selectSubject(String selectnum, Scanner input);

	
	
}
