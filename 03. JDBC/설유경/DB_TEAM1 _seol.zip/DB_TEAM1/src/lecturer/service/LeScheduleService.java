 package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;




import dto.VwCountStudentDTO;
import dto.VwCourseDTO;
import dto.VwLecturerDTO;
import dto.VwStudentCountDTO;
import dto.VwStudentDTO;
import dto.VwSubjectDTO;
import lecturer.LecturerScheduleDAO;
import lecturer.LecturerView;

public class LeScheduleService implements ILeScheduleService{

	private static Scanner scan;
	private static LecturerView view;
	static {
		scan = new Scanner(System.in);
		view = new LecturerView();
	}
	
//	view.thickLine();
//	view.thinLine();
	
	//강의 예정
	@Override
	public void will() {
		view.title(LecturerView.SCHEDULESERVICEYET);
		
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> willcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : willcoursecheck) {
				view.thickLine();
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				view.thinLine();
				System.out.printf("\t[강의실] : %s \n", dto.getVclassroom());
				
			}//for
		dao.close();	
		
		
		view.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t\t[과목기간]\t\t[교재명]");
		view.thickLine();
				
		LecturerScheduleDAO willdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> willsubjectcheck = willdao.willsubjectcheck();
		
			
		
		for(VwSubjectDTO dto : willsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t\t%s ~ %s\t%s\n"
								, dto.getVsubjectSeq()
								, dto.getVsubjectName()
								, dto.getVsubjectStartDate()
								, dto.getVsubjectEndDate()
								, dto.getvTextbook());
		}//for	
		dao.close();	
	}// will()

//-----------------------------------------------------------------	
	//강의중
	@Override
	public void prog() {
		view.title(LecturerView.SCHEDULESERVICECURRENT);
		
		
		//강의중 과정출력
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> progcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : progcoursecheck) {
				view.thickLine();
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				view.thinLine();
				System.out.printf("\t[강의실] : %s\n", dto.getVclassroom());
			}//for
		dao.close();
		
		
	}//prog()
	
	public void progcount() {
		//강의중 과정의 총 인원
		LecturerScheduleDAO progcountcheck = new LecturerScheduleDAO();
		ArrayList<VwCountStudentDTO> progcount = progcountcheck.progcountcheck();
			
				view.thinLine();
			for(VwCountStudentDTO dto : progcount) {
				
				System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());
				
		
			}//for
			
			progcountcheck.close();
		
			
	}//prog()
	
	public void progsubject() {
		//강의중 과목
		view.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t[과목기간]\t\t[교재명]");
		view.thickLine();
				
		LecturerScheduleDAO progdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> progsubjectcheck = progdao.progsubjectcheck();
		
			
		
		for(VwSubjectDTO dto2 : progsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t%s ~ %s\t%s\n"
								, dto2.getVsubjectSeq()
								, dto2.getVsubjectName()
								, dto2.getVsubjectStartDate()
								, dto2.getVsubjectEndDate()
								, dto2.getvTextbook());
		}//for	
		progdao.close();	
		
		System.out.println("\t==========================================================================");
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		Scanner input = new Scanner(System.in);
		input.nextLine();
		
		
	}//progsubject()
	
	//선택한 과목정보
	public void selectSubject(String selectnum, String input){
		view.title(LecturerView.SCHEDULESERVICECURRENT);
		view.thickLine();
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> subjectcheck = dao.subjectcheck( selectnum,  input);

			for(VwSubjectDTO dto : subjectcheck) {
				System.out.printf("\t[과목번호] : %s\n\t[과목명] : %s \n\t[과목시작기간] : %s \n\t[과목종료기간] %s \n\t[교재명] : %s \n\t[강사명] :  %s\n"
						,dto.getVsubjectSeq(), dto.getVsubjectName(), dto.getVsubjectStartDate(), dto.getVsubjectEndDate(), dto.getvTextbook(), dto.getVlecturerName());
			}//for	
		dao.close();	
	}
	
	public void selectSubjectcount(String selectnum, String input){
		//강의중 과정의 총 인원
			LecturerScheduleDAO countdao = new LecturerScheduleDAO();
			ArrayList<VwCountStudentDTO> progCount = countdao.progcountcheck();
					
			view.thinLine();
				for(VwCountStudentDTO dto : progCount) {		
					System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());	
				}
		
	}//selectSubjectcount
	//과정등록교육생목록
	public void coursestudent(String selectnum, String input) {
		view.thickLine();
		System.out.println("\t[교육생번호]\t[교육생이름]\t[TEL]\t[등록일]\t\t[상태]");
		view.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwStudentDTO> courseStudent = dao.courseStudent(selectnum,  input);
		
	
		for(VwStudentDTO dto : courseStudent) {
			System.out.printf("\t[%s] ", dto.getVstudentSeq());
			
			System.out.printf("\t%s ", dto.getVstudentName());
			
			System.out.printf("\t%s ", dto.getVphoneNum());
			
			System.out.printf("\t%s ", dto.getVregistrationtime());
			
			System.out.printf("\t%s ", dto.getVstudentstatus());
			
			System.out.print("\t세부사항 참조\n");
			
		}
		view.thinLine();
		dao.close();
	}//coursestudent
	
	
//--------------------------------------------------------------------------------	
	
	public String endcourse() {
		view.title(LecturerView.SCHEDULESERVICEEND);
		
		
		//강의종료 과정출력
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> endcourse = dao.endcourse();

			for(VwCourseDTO dto : endcourse) {
				view.thickLine();
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				view.thinLine();
				System.out.printf("\t[강의실] : %s\n", dto.getVclassroom());
			}//for
			
			System.out.println("\t==========================================================================");
			System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
			System.out.print("\t\t\t\t입력: ");
			Scanner input = new Scanner(System.in);
			String in = input.nextLine();
			return in;
			
		
	}
	
	public void end(String in) {
		//강의종료 과정출력
				LecturerScheduleDAO dao = new LecturerScheduleDAO();
				ArrayList<VwCourseDTO> end = dao.end(in);

					for(VwCourseDTO dto : end) {
						System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
						view.thinLine();
						System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
						view.thinLine();
						System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
						view.thinLine();
						System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
						view.thinLine();
						System.out.printf("\t[강의실] : %s\n", dto.getVclassroom());
					}//for
				dao.close();
	}
				
	public Scanner endsubject(String in) {
		//강의종료 과정출력			
				
				//강의종료 과목
				view.thickLine();
				System.out.println("\t[과목번호]\t[과목명]\t[과목기간]\t\t[교재명]");
				view.thickLine();
						
				LecturerScheduleDAO progdao = new LecturerScheduleDAO();
				ArrayList<VwSubjectDTO> endsubject = progdao.endsubject(in);
				
					
				
				for(VwSubjectDTO dto2 : endsubject) {
					System.out.printf("\t[%s]\t%s\t%s ~ %s\t%s\n"
										, dto2.getVsubjectSeq()
										, dto2.getVsubjectName()
										, dto2.getVsubjectStartDate()
										, dto2.getVsubjectEndDate()
										, dto2.getvTextbook());
				}//for	
				
				System.out.println("\t==========================================================================");
				System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
				System.out.print("\t\t\t\t입력: ");
				Scanner suseq = new Scanner(System.in);
				suseq.nextLine();
				
				progdao.close();	
				return suseq;
	}


	@Override
	public void substu(String in) {
		//강의종료 과정과목출력
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> end = dao.substu(in);

			for(VwSubjectDTO dto : end) {
				
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thickLine();
				System.out.printf("\t[과목번호] : %s \n", dto.getVsubjectSeq());
				view.thinLine();
				System.out.printf("\t[과목명] : %s \n", dto.getVsubjectName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVsubjectStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVsubjectEndDate());
				
			}//for
		dao.close();
		
	}

	
	public void endstudent(String selectnum, String in) {
		view.thickLine();
		System.out.println("\t[교육생번호]\t[교육생이름]\t[TEL]\t[등록일]\t\t[상태]");
		view.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwStudentDTO> courseStudent = dao.courseStudent(selectnum,  in);
		
	
		for(VwStudentDTO dto : courseStudent) {
			System.out.printf("\t[%s] ", dto.getVstudentSeq());
			
			System.out.printf("\t%s ", dto.getVstudentName());
			
			System.out.printf("\t%s ", dto.getVphoneNum());
			
			System.out.printf("\t%s ", dto.getVregistrationtime());
			
			int n = Integer.parseInt( dto.getVstudentstatus());
			
			if( n == 1) { 
				System.out.println("");
			}else if(n == 2){
				System.out.println("");
			}else if(n == 3 ){
				System.out.println("");
			}
			
			
			
			
		}
		view.thinLine();
		dao.close();
	}//coursestudent
	

	@Override
	public void subject(String selcou) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectSubjectcount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void coursestudent() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void substu(Scanner scan) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void endstudent(String selectnum, Scanner input) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end(Scanner input) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String selectSubject(String selectnum, Scanner input) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
