package student.service;

public class StGradeService implements IStGradeService {

	@Override
	public void gradeList() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void quizList() {
		// TODO Auto-generated method stub
		
	}

}
