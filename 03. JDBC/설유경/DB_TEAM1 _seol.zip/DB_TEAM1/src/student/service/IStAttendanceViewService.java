package student.service;

public interface IStAttendanceViewService {

	void entireAttendanceList();

	void monthlyAttendanceList();
	
	void dailyAttendanceList();

}
