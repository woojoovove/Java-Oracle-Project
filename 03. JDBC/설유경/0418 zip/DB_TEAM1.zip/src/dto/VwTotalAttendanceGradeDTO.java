package dto;

public class VwTotalAttendanceGradeDTO {

	private String vstudentSeq;
	private String vattendanceGrade;
	
	public String getVstudentSeq() {
		return vstudentSeq;
	}
	public void setVstudentSeq(String vstudentSeq) {
		this.vstudentSeq = vstudentSeq;
	}
	public String getVattendanceGrade() {
		return vattendanceGrade;
	}
	public void setVattendanceGrade(String vattendanceGrade) {
		this.vattendanceGrade = vattendanceGrade;
	}
	
	
}
