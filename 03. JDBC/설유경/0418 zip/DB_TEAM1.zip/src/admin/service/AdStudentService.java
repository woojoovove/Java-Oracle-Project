package admin.service;

public class AdStudentService implements IAdStudentService {

}
