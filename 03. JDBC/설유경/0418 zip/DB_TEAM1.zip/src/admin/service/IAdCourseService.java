package admin.service;

public interface IAdCourseService {
	
	void courseAdd();	
	void courseList();	
	void courseEdit();	
	void courseDelete();	
		
	void subjectAdd();
	void subjectList(String courseSeq);
	void subjectEdit();	
	void subjectDelete(String courseSeq);
	
	void courseStudentList();
	
}
