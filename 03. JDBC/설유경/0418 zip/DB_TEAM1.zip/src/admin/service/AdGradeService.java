package admin.service;

public class AdGradeService implements IAdGradeService {

}
