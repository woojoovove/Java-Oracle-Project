package admin.service;

public class AdBasicInfoService implements IAdBasicInfoService {

	@Override
	public void addLecturer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lecturerInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void detailLecturer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerReg() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerTel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLecturerSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void textBook() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void textBookMenu() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifytextBook() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletetextBook() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectPublisher() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void classRoom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyClassRoomName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyclassRoomNum() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subjectName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifySubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void basicInfomenu() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertCourseName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyCourseName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCourseName() {
		// TODO Auto-generated method stub
		
	}



	
	
}
