package admin.service;

public interface IAdAttendanceService {

	void fullAttendance();

	void attendanceByMonth();
	
}
