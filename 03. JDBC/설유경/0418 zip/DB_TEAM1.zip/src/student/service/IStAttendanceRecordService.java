package student.service;

public interface IStAttendanceRecordService {

	void attendanceRecordAdd();

}
