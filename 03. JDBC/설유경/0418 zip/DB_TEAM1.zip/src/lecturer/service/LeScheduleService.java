package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.AdLecturerInfoDAO;
import admin.AdministratorController;
import admin.AdministratorView;
import dto.VwCountStudentDTO;
import dto.VwCourseDTO;
import dto.VwLecturerDTO;
import dto.VwStudentCountDTO;
import dto.VwStudentDTO;
import dto.VwSubjectDTO;
import lecturer.LecturerScheduleDAO;
import lecturer.LecturerView;

public class LeScheduleService implements ILeScheduleService{

	private static Scanner scan;
	private static LecturerView view;
	static {
		scan = new Scanner(System.in);
		view = new LecturerView();
	}
	
//	view.thickLine();
//	view.thinLine();
	
	//강의 예정
	@Override
	public void will() {
		view.title(LecturerView.SCHEDULESERVICEYET);
		view.thickLine();
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> willcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : willcoursecheck) {
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				view.thinLine();
				System.out.printf("\t[강의실] : %s \n", dto.getVclassroom());
				
			}//for
		dao.close();	
		
		
		view.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t\t[과목기간]\t\t[교재명]");
		view.thickLine();
				
		LecturerScheduleDAO willdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> willsubjectcheck = willdao.willsubjectcheck();
		
			
		
		for(VwSubjectDTO dto : willsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t\t%s ~ %s\t%s\n"
								, dto.getVsubjectSeq()
								, dto.getVsubjectName()
								, dto.getVsubjectStartDate()
								, dto.getVsubjectEndDate()
								, dto.getvTextbook());
		}//for	
		dao.close();	
		
		
		
		
		
	}// will()

	@Override
	public void prog() {
		view.title(LecturerView.SCHEDULESERVICECURRENT);
		view.thickLine();
		
		//강의중 과정출력
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> willcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : willcoursecheck) {
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				view.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				view.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				view.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				view.thinLine();
				System.out.printf("\t[강의실] : %s\n", dto.getVclassroom());
			}//for
		dao.close();
		
		//강의중 과정의 총 인원
		LecturerScheduleDAO countdao = new LecturerScheduleDAO();
		ArrayList<VwCountStudentDTO> progcountcheck = countdao.progcountcheck();
			
				view.thinLine();
			for(VwCountStudentDTO dto : progcountcheck) {
				
				System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());
				
		
			}//for
		countdao.close();	
		
		//강의중 과목
		view.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t[과목기간]\t\t[교재명]");
		view.thickLine();
				
		LecturerScheduleDAO progdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> progsubjectcheck = progdao.progsubjectcheck();
		
			
		
		for(VwSubjectDTO dto2 : progsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t%s ~ %s\t%s\n"
								, dto2.getVsubjectSeq()
								, dto2.getVsubjectName()
								, dto2.getVsubjectStartDate()
								, dto2.getVsubjectEndDate()
								, dto2.getvTextbook());
		}//for	
		progdao.close();	

	}//prog()
	
	
	public void selectSubject(String selectnum, String inputnum){
		view.title(LecturerView.SCHEDULESERVICECURRENT);
		view.thickLine();
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> subjectcheck = dao.subjectcheck( selectnum,  inputnum);

			for(VwSubjectDTO dto : subjectcheck) {
				System.out.printf("\t[과목번호] : %s\n\t[과목명] : %s \n\t[과목시작기간] : %s \n\t[과목종료기간] %s \n\t[교재명] : %s \n\t[강사명] :  %s\n"
						,dto.getVsubjectSeq(), dto.getVsubjectName(), dto.getVsubjectStartDate(), dto.getVsubjectEndDate(), dto.getvTextbook(), dto.getVlecturerseq());
			}//for	
			
		dao.close();	
	}
	
	public void selectSubjectcount(String selectnum, String inputnum){
		//강의중 과정의 총 인원
			LecturerScheduleDAO countdao = new LecturerScheduleDAO();
			ArrayList<VwCountStudentDTO> progcountcheck = countdao.progcountcheck();
					
			view.thinLine();
				for(VwCountStudentDTO dto : progcountcheck) {
						
				System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());
						
				}
		
	}//selectSubjectcount
	
	public void coursestudent(String selectnum, String inputnum) {
		view.thickLine();
		System.out.println("\t[교육생번호]\t[교육생이름]\t[TEL]\t[등록일]\t\t[상태]");
		view.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwStudentDTO> courseStudent = dao.courseStudent(selectnum,  inputnum);
		
	
		for(VwStudentDTO dto : courseStudent) {
			System.out.printf("\t[%s] ", dto.getVstudentSeq());
			
			System.out.printf("\t%s ", dto.getVstudentName());
			
			System.out.printf("\t%s ", dto.getVphoneNum());
			
			System.out.printf("\t%s ", dto.getVregistrationtime());
			
			System.out.printf("\t%s ", dto.getVstudentstatus());
			
			System.out.print("\t세부사항 참조\n");
			
		}
		view.thinLine();
		
		dao.close();
		
	
		
	}//coursestudent
	
	
	

	@Override
	public void substu(String temp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void end() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subject(String selcou) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectSubject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectSubjectcount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void coursestudent() {
		// TODO Auto-generated method stub
		
	}

}
