package admin.service;

public interface IAdLecturerInfoService {

	void Lectureradd();

	void Lecturerlist();

	

	void detailLecturer(String selectnum);

	void avlbsubject(String selectnum);

	void checkcourse(String selectnum);
	
	void checksubject(String selectnum);



	void subjectadd();

	
	
}
