package dto;

public class VwSubjectDTO {

	private String vsubjectSeq;
	private String vsubjectName;
	private String vsubjectStartDate;
	private String vsubjectEndDate;
	private String vTextbook;
	private String vlecturerName;
	private String vcourseSeq;
	private String vcourseName;
	private String vlecturerseq;
	
	
	public String getVsubjectSeq() {
		return vsubjectSeq;
	}
	public void setVsubjectSeq(String vsubjectSeq) {
		this.vsubjectSeq = vsubjectSeq;
	}
	public String getVsubjectName() {
		return vsubjectName;
	}
	public void setVsubjectName(String vsubjectName) {
		this.vsubjectName = vsubjectName;
	}
	public String getVsubjectStartDate() {
		return vsubjectStartDate;
	}
	public void setVsubjectStartDate(String vsubjectStartDate) {
		this.vsubjectStartDate = vsubjectStartDate;
	}
	public String getVsubjectEndDate() {
		return vsubjectEndDate;
	}
	public void setVsubjectEndDate(String vsubjectEndDate) {
		this.vsubjectEndDate = vsubjectEndDate;
	}
	public String getvTextbook() {
		return vTextbook;
	}
	public void setvTextbook(String vTextbook) {
		this.vTextbook = vTextbook;
	}
	public String getVlecturerName() {
		return vlecturerName;
	}
	public void setVlecturerName(String vlecturerName) {
		this.vlecturerName = vlecturerName;
	}
	public String getVcourseSeq() {
		return vcourseSeq;
	}
	public void setVcourseSeq(String vcourseSeq) {
		this.vcourseSeq = vcourseSeq;
	}
	public String getVcourseName() {
		return vcourseName;
	}
	public void setVcourseName(String vcourseName) {
		this.vcourseName = vcourseName;
	}
	public String getVlecturerseq() {
		return vlecturerseq;
	}
	public void setVlecturerseq(String vlecturerseq) {
		this.vlecturerseq = vlecturerseq;
	}
	
	
	
	
	
	
}
