package dto;

public class VwCountAttendanceDTO {

	private String seq;
	private String name;
	private String goout;
	private String late;
	private String early;
	private String abscence;
	private String attended;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGoout() {
		return goout;
	}
	public void setGoout(String goout) {
		this.goout = goout;
	}
	public String getLate() {
		return late;
	}
	public void setLate(String late) {
		this.late = late;
	}
	public String getEarly() {
		return early;
	}
	public void setEarly(String early) {
		this.early = early;
	}
	public String getAbscence() {
		return abscence;
	}
	public void setAbscence(String abscence) {
		this.abscence = abscence;
	}
	public String getAttended() {
		return attended;
	}
	public void setAttended(String attended) {
		this.attended = attended;
	}
	
	
}
