package student;

import java.util.Scanner;

import login.Cls;
import student.service.IStAttendanceViewService;
import student.service.StAttendanceViewService;

public class StudentController {

	private static StudentView studentView;	
	private static IStAttendanceViewService stAttendanceViewService; 
	private static IStAttendanceViewService stAttViewService;
	private static Scanner scan;
	private static String studentSeq = "1";
	
	static {
		studentView = new StudentView();		
		scan = new Scanner(System.in);
		stAttendanceViewService = new StAttendanceViewService();
	}
	
//===================================================================================	
	
	public static void main(String[] args) throws Exception {

		boolean studentLoop = true;
		
		while (studentLoop) {
			
			Cls.clearScreen();
			System.out.println("\t\t\t\t\tLOADING.....");
			Thread.sleep(700);
			Cls.clearScreen();
			
			studentView.begin();
			studentView.menu();
			String select = scan.nextLine();
			
	//-------------------------------------------------------
			
			if (select.equals("1")) {
				
				studentView.endMenu(select);
				
				System.out.println("1번 진입");
				//성적 조회
				boolean stGradeLoop = true;
				
				while (stGradeLoop) {
					
				}
				
	//-------------------------------------------------------		
				
			} else if (select.equals("2")) {
				studentView.endMenu(select);

				System.out.println("2번 진입");
				//출결 등록
				boolean stAttendanceRecordLoop = true;
				
				while (stAttendanceRecordLoop) {
					
				}
				
	//-------------------------------------------------------
				
			} else if (select.equals("3")) { //출결 조회
				
				studentView.endMenu(select);

				boolean studentAttendanceViewLoop = true;
				
				while (studentAttendanceViewLoop) {
					
					Cls.clearScreen();
					studentView.title(StudentView.ATTENDANCEVIEW);
					
					String menuSelect = studentView.studentAttendanceViewMenu();
					
					select = scan.nextLine();
					
					if (menuSelect.equals("1")) {
						
						boolean p = true;
						
						while(p) {
							
							
							studentView.title(studentView.ATTENDANCE);
							studentView.menuCourse(studentSeq); // 
							String courseSeq = scan.nextLine();
							studentView.subMenuCourse();
							
							select = scan.nextLine();
							
							if (select.equals("1")) {
							
								stAttendanceViewService.entireAttendanceView(courseSeq, studentSeq);
				
							} else if (select.equals("2")) {
								stAttendanceViewService.subjectAttendanceView(studentSeq);
							} else  {
								p = false;
							}
							
						}
					} else if (menuSelect.equals("0")) {
						studentAttendanceViewLoop = false;
					}
						
					 
						
					
				}//while : studentAttendanceViewLoop
				
	//-------------------------------------------------------
				
			} else if (select.equals("0")) {
				
				studentView.endMenu(select);

				studentLoop = false;
				
				Cls.clearScreen();
				System.out.println("\t\t\t\t\tLOADING.....");
				Thread.sleep(700);
				Cls.clearScreen();
				
			}
		}//While End				
	}//Method : main
}