package student.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.DAO.AdAttendanceDAO;
import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import dto.VwsubjectAttendanceDTO;
import login.Cls;
import student.StudentView;
import student.DAO.StAttendanceDAO;
import student.DAO.StudentAttendanceViewDAO;

public class StAttendanceViewService implements IStAttendanceViewService {

	private static StudentView studentView;
	private static StudentAttendanceViewDAO studentAttendanceViewDAO;
	private static Scanner scan;
	
	static {
		studentView = new StudentView();
		studentAttendanceViewDAO = new StudentAttendanceViewDAO();
		scan = new Scanner(System.in);
	}
	
	

//출결 조회 - 전체 기간 조회
//=====================================================================================================================
	
	@Override
	public void entireAttendanceView(String courseSeq, String studentSeq) {
		StAttendanceDAO dao = new StAttendanceDAO();
		
		VwCourseDTO dto = dao.myCourseName(courseSeq);
		
		System.out.println("\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		System.out.printf("\t%s",  dto.getVcourseName());
		System.out.println("\n\t==========================================================================\n");
		System.out.println();
		System.out.println("\t[전체 기간 조회]");
				
		ArrayList<VwCountAttendanceDTO> list = dao.fullAttendance(studentSeq);
				
		for (VwCountAttendanceDTO dto2 : list) {
			System.out.println("\n\t--------------------------------------------------------------------------\n");
			System.out.printf("\t이름: %s\n", dto2.getName());
			System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
								, dto2.getAttended()
								, dto2.getLate()
								, dto2.getEarly()
								, dto2.getGoout()
								, dto2.getAbscence());
			
		}
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
		
		String select = scan.nextLine();
		
	}//method : entireAttendanceView

//=====================================================================================================================
	
	
	
//출결 조회 - 과목별 조회
//=====================================================================================================================
	
	@Override
	public void subjectAttendanceView(String studentSeq) {
		
		boolean subjectAttendanceViewLoop01 = true;
		
		while (subjectAttendanceViewLoop01) {
			
			Cls.clearScreen();
			studentView.title(StudentView.ATTENDANCESUBJECTVIEW); // 여기까지
			
			ArrayList<String> subjectList = studentAttendanceViewDAO.subjectAttendanceView(studentSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));	
				
				if (i == subjectList.size() - 1) {
					studentView.thickLine();
				} else {
					studentView.thinLine();
				}
			}
						
			String subjectSeq = studentView.subjectAttendanceView01();
			
			if (!subjectSeq.equals("0")) {
				
				boolean subjectAttendanceViewLoop02 = true;
				
				while (subjectAttendanceViewLoop02) {
					
					Cls.clearScreen();
					studentView.title(StudentView.ATTENDANCESUBJECTVIEW);
					String studentName = studentAttendanceViewDAO.studentName(studentSeq);
					studentView.studentName(studentName);
					
					
					VwCountAttendanceDTO dto = new VwCountAttendanceDTO();
					
					StudentAttendanceViewDAO dao = new StudentAttendanceViewDAO();
					
					dto = dao.attendanceBySubject(subjectSeq, studentSeq);
					
					System.out.println("\n\t--------------------------------------------------------------------------\n");
					System.out.printf("\t이름: %s\n", dto.getName());
					System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
										, dto.getAttended()
										, dto.getLate()
										, dto.getEarly()
										, dto.getGoout()
										, dto.getAbscence());
					
					System.out.println("\n\t==========================================================================\n");
					System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
					
					
					subjectSeq = studentView.subjectAttendanceView02();
					
					if (!subjectSeq.equals("0")) continue;
					else if (subjectSeq.equals("0")) subjectAttendanceViewLoop02 = false;
					
				}//while : subjectAttendanceViewLoop02

			} else if (subjectSeq.equals("0")) subjectAttendanceViewLoop01 = false;
		}//while : subjectAttendanceViewLoop01
	}//method : monthlyAttendanceView


}//class : StAttendanceViewService


