package student.service;

import java.util.Scanner;

import dto.AttendanceDTO;
import login.Cls;
import student.StudentView;
import student.DAO.StudentAttendanceRecordDAO;

public class StAttendanceRecordService implements IStAttendanceRecordService {

	private static StudentView studentView;	
	private static StudentAttendanceRecordDAO studentAttendanceRecordDAO;
	private static Scanner scan;
	
	static {
		studentView = new StudentView();
		studentAttendanceRecordDAO = new StudentAttendanceRecordDAO();
		scan = new Scanner(System.in);
	}
	
//=================================================================================================
	
	@Override
	public void attendanceRecordAdd(String studentSeq) {
		
		Cls.clearScreen();
		studentView.title(StudentView.ATTENDANCERECORD);
		
		String studentName = studentAttendanceRecordDAO.studentName(studentSeq);
		studentView.attendanceRecordAdd01(studentName);
		
		
		//입력
		System.out.println();
		System.out.print("\t오늘의 날짜 (0000-00-00) : ");
		String todayDate = scan.nextLine();
		
		System.out.println();
		System.out.print("\t출근시간 입력 (00:00) : ");
		String goTo = todayDate + " " + scan.nextLine();
		
		System.out.println();
		System.out.print("\t퇴근시간 입력 (00:00) : ");
		String comeBack = todayDate + " " + scan.nextLine();
			
		
		//출근시간 INSERT
		AttendanceDTO attendanceDTO = new AttendanceDTO();
		attendanceDTO.setGoTo(goTo);
		attendanceDTO.setStudentSeq(studentSeq);
		studentAttendanceRecordDAO.attendanceRecordGoToAdd(attendanceDTO);
		
		
		//퇴근시간 INSERT
		attendanceDTO.setComeBack(comeBack);
		attendanceDTO.setStudentSeq(studentSeq);
		studentAttendanceRecordDAO.attendanceRecordComeBackAdd(attendanceDTO);	
		
		
		//완료 메시지
		studentView.attendanceRecordAdd02();
		
	}//method : attendanceRecordAdd

}//class : StAttendanceRecordService
