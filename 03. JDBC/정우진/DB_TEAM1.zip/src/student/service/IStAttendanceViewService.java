package student.service;

public interface IStAttendanceViewService {

	void subjectAttendanceView(String studentSeq);

	void entireAttendanceView(String courseSeq, String studentSeq);

}
