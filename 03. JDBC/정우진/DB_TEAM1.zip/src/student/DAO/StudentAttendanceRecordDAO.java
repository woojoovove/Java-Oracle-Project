package student.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dto.AttendanceDTO;
import util.DBUtil;

public class StudentAttendanceRecordDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public StudentAttendanceRecordDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : StudentAttendanceRecordDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close	
	

	
//학생명	
//=====================================================================================================================================	
	
	public String studentName(String studentSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblStudentInfo WHERE seq = %s", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String studentName = rs.getString("name");
				return studentName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : studentName
	
//=====================================================================================================================================		
	
	
	
//출결 기록 입력
//=====================================================================================================================================	
	
	//출근시간 입력
	public int attendanceRecordGoToAdd(AttendanceDTO attendanceDTO) {
		
		String sql = "INSERT INTO tblAttendance (seq, attendancedate, studentseq) "
						+ "VALUES(attendanceSeq.NEXTVAL, TO_DATE(?, \'yyyy-mm-dd hh24-mi-ss\'), ?)";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, attendanceDTO.getGoTo());
			pstat.setString(2, attendanceDTO.getStudentSeq());

			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : attendanceRecordGoToAdd

	
	//퇴근시간 입력
	public int attendanceRecordComeBackAdd(AttendanceDTO attendanceDTO) {
		
		String sql = "INSERT INTO tblAttendance (seq, attendancedate, studentseq) "
				+ "VALUES(attendanceSeq.NEXTVAL, TO_DATE(?, \'yyyy-mm-dd hh24-mi-ss\'), ?)";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, attendanceDTO.getComeBack());
			pstat.setString(2, attendanceDTO.getStudentSeq());
		
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : attendanceRecordComeBackAdd

}//class : StudentAttendanceRecordDAO




