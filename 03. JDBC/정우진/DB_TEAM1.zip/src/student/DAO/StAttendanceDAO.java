package student.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import util.DBUtil;

public class StAttendanceDAO {

	private static Connection conn;
	private static Statement stat;
	private static PreparedStatement pstat;
	//--------------------------------------------------------------------------------------------	

	public StAttendanceDAO() {
		try {
			
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
			
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO");
		}
	}
	//--------------------------------------------------------------------------------------------	
	public ArrayList<VwCourseDTO> courseNameList(String studentSeq) {
		
		try {
			
			ArrayList<VwCourseDTO> courseList = new ArrayList<VwCourseDTO>();
			
			String sql = String.format("SELECT * FROM vwCourse WHERE vCourseSeq = (SELECT courseSeq FROM tblStudent WHERE seq = 1)", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				
				VwCourseDTO courseDTO = new VwCourseDTO();
				courseDTO.setVcourseSeq(rs.getString("VcourseSeq"));
				courseDTO.setVcourseName(rs.getString("VcourseName"));
				courseList.add(courseDTO);
			}
			return courseList;
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO");
		}
		
		return null;
	}

	//--------------------------------------------------------------------------------------------	
	
	
	
	public VwCourseDTO myCourseName(String courseSeq) {

		try {
			
			String sql = String.format("SELECT VCOURSENAME FROM vwCourse WHERE VCOURSESEQ = %s", courseSeq);
			
			ResultSet rs = stat.executeQuery(sql);
			
			VwCourseDTO dto = new VwCourseDTO();

			if(rs.next()) {
				
				dto.setVcourseName(rs.getString("VCOURSENAME"));
			}
			
			return dto;
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}
	
	public ArrayList<VwCountAttendanceDTO> fullAttendance(String studentSeq) {
		
		ArrayList<VwCountAttendanceDTO> list = new ArrayList<VwCountAttendanceDTO>();
		
		try {
			
			VwCountAttendanceDTO dto = new VwCountAttendanceDTO();
			
			String sql = String.format("SELECT * FROM vwCountAttendance WHERE seq = %s", studentSeq);
			
			ResultSet rs = stat.executeQuery(sql);
			
			while(rs.next()) {
				dto.setAbscence(rs.getString("abscence"));
				dto.setAttended(rs.getString("attended"));
				dto.setEarly(rs.getString("early"));
				dto.setGoout(rs.getString("goout"));
				dto.setLate(rs.getString("late"));
				dto.setName(rs.getString("name"));
				dto.setSeq(rs.getString("seq"));
				
				list.add(dto);
			}
			
			return list;
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO.fullAttendance()");
		}
		
		return null;
	}

	//--------------------------------------------------------------------------------------------	
	
	
	//--------------------------------------------------------------------------------------------	

	//--------------------------------------------------------------------------------------------	
	

	//--------------------------------------------------------------------------------------------	
	
	
	

	
}

	
