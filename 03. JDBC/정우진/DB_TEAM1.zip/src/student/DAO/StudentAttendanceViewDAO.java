package student.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import dto.VwsubjectAttendanceDTO;
import util.DBUtil;

public class StudentAttendanceViewDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public StudentAttendanceViewDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : StudentAttendanceViewDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close	
	
	
	
//학생명	
//=====================================================================================================================================	
	
	public String studentName(String studentSeq) {
		
		try {
			
			String sql = String.format("SELECT name FROM tblStudentInfo WHERE seq = %s", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String studentName = rs.getString("name");
				return studentName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : studentName
	
//=====================================================================================================================================	

	
	
//전체 기간 조회
//=====================================================================================================================================	
	
	//전체 기간 출결사항
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//=====================================================================================================================================		
	
	
	
//과목별 조회
//=====================================================================================================================================	
	
	//과목 리스트
	public ArrayList<String> subjectAttendanceView(String studentSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwsubjectAttendance WHERE vstudentseq = %s", studentSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwsubjectAttendanceDTO> subjectAttendanceList = new ArrayList<VwsubjectAttendanceDTO>();
			
			while (rs.next()) {				
				VwsubjectAttendanceDTO vwsubjectAttendanceDTO = new VwsubjectAttendanceDTO();
				
				vwsubjectAttendanceDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				vwsubjectAttendanceDTO.setvSubjectName(rs.getString("vSubjectName"));
				vwsubjectAttendanceDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				vwsubjectAttendanceDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				
				subjectAttendanceList.add(vwsubjectAttendanceDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwsubjectAttendanceDTO vwsubjectAttendanceDTO : subjectAttendanceList) {
				tempList.add(
						"\t[" + vwsubjectAttendanceDTO.getvSubjectSeq() + "]" 
						+ "\t과목명\t\t" + vwsubjectAttendanceDTO.getvSubjectName()
						+"\n\t\t과목기간\t" + vwsubjectAttendanceDTO.getvSubjectStart().substring(0, 10) + " ~ "
											+ vwsubjectAttendanceDTO.getvSubjectEnd().substring(0, 10));
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectAttendanceView
	
	
	public VwCountAttendanceDTO attendanceBySubject (String subjectSeq, String studentSeq) {
		
		try {
			
			VwCourseDTO	course = new VwCourseDTO();
			
			String sql1 = String.format("SELECT startDate, endDate FROM tblSubject WHERE seq = %s", subjectSeq);
			
			ResultSet rs = stat.executeQuery(sql1);
			
			VwCountAttendanceDTO dto = new VwCountAttendanceDTO();

			if (rs.next()) {
				
				String startDate = rs.getString("startdate").split(" ")[0];
				String endDate = rs.getString("enddate").split(" ")[0];
				
				String vwDate = String.format("create or replace view vwDate as select to_date('%s','yyyy-mm-dd') + level - 1 as regdate from dual connect by level <= (to_date('%s','yyyy-mm-dd')-to_date('%s','yyyy-mm-dd') + 1 )"
						, startDate, endDate, startDate);
				stat.executeUpdate(vwDate);
			}
			
			String sql2 = String.format("SELECT * FROM vwCountAttendance WHERE seq = %s", studentSeq);

			pstat = conn.prepareStatement(sql2);
			
			ResultSet rs2 = pstat.executeQuery();
			
			while (rs2.next()) {
				dto.setName(rs2.getString("name"));
				dto.setSeq(rs2.getString("seq"));
				dto.setAbscence(rs2.getString("abscence"));
				dto.setAttended(rs2.getString("attended"));
				dto.setEarly(rs2.getString("early"));
				dto.setGoout(rs2.getString("goout"));
				dto.setLate(rs2.getString("late"));
			}
			
			
			return dto;
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}
	
	//과목별 출결사항
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//=====================================================================================================================================
	
}//class : StudentAttendanceViewDAO



