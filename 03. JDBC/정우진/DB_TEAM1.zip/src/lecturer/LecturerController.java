package lecturer;

import java.util.Scanner;

import dto.WarningDTO;
import lecturer.service.ILeWarningService;
import lecturer.service.LeAttendanceService;
import lecturer.service.LeWarningService;
import lecturer.view.WarningView;
import login.Cls;

public class LecturerController {

	private static ILeWarningService leWarningService;
	private static WarningView warningView;
	private static LecturerView lecturerView;	
	private static Scanner scan;
	private static LeAttendanceService leAttendanceService;
	private final static String lecturerSeq = "4";
	
	
	static {
		warningView = new WarningView();
		lecturerView = new LecturerView();		
		scan = new Scanner(System.in);
		leAttendanceService = new LeAttendanceService();
		leWarningService = new LeWarningService(); 

	}
	
//===================================================================================	
	
	public static void main(String[] args) throws Exception {

		boolean lecturerLoop = true;
		
		while (lecturerLoop) {
			
			Cls.clearScreen();
			System.out.println("\t\t\t\t\tLOADING.....");
			Thread.sleep(700);
			Cls.clearScreen();
			
			lecturerView.begin();
			lecturerView.menu();
			String select = scan.nextLine();
			
	//-------------------------------------------------------	
			
			if (select.equals("1")) {
				
				//강의 스케줄 관리 메뉴
				boolean leScheduleLoop = true;
				
				while (leScheduleLoop) {
					
				}				
				
	//-------------------------------------------------------	
				
			} else if (select.equals("2")) {
				
				//배점 관리
				boolean lePercentLoop = true;
				
				while (lePercentLoop) {
					
				}					
				
	//-------------------------------------------------------
				
			} else if (select.equals("3")) {
				
				//성적 관리
				boolean leGradeLoop = true;
				
				while (leGradeLoop) {

				}
				
	//-------------------------------------------------------			
				
			} else if (select.equals("4")) {
				
				//출결 관리
				boolean leAttendanceLoop = true;
				
				while (leAttendanceLoop) {
					
					lecturerView.attendanceMenu();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
							
						boolean b = true;
						
						while (b) {
							
							lecturerView.title(LecturerView.ATTENDANCE);
							leAttendanceService.courseMenu(lecturerSeq);
							
							String courseSeq = scan.nextLine();
							
							lecturerView.attendanceSubMenu();
							
							select = scan.nextLine();
							
							if (select.equals("1")) {
								
								leAttendanceService.fullAttendance(courseSeq);
							} else if (select.equals("2") ) {
								
								leAttendanceService.AttendanceBySubject(courseSeq);
							} else {
								b = false;
							}
							
						}
					} else {
						leAttendanceLoop = false;
					}
					
				}
				
	//-------------------------------------------------------	
								
			} else if (select.equals("5")) {
				
				//추천서 관리
				boolean leRecommendationLoop = true;
				
				while (leRecommendationLoop) {
					
				}
				
	//-------------------------------------------------------
		
			
			} else if (select.equals("6")) {
				
				warningView.title(WarningView.INIMENU);
				select = scan.nextLine();
				
				if (select.equals("1")) {
					
					boolean warningLoop	 = true;
					while (warningLoop)	{
						
						leWarningService.listStudents(lecturerSeq);
						warningView.warningSubMenu();
						select = scan.nextLine();
						
						if (!select.equals("0")) {
							
							WarningDTO student = leWarningService.counsel(lecturerSeq, select);
							int result = leWarningService.insert(student);
							
							if (result == 1) {
								warningView.success();
							} else {
								warningView.failure();
							}
							
						} else {
							warningLoop = false;
						}
					}
				} 
				
	//-------------------------------------------------------
	
			} else {
				
				//로그아웃
				lecturerLoop = false;
				
				Cls.clearScreen();
				System.out.println("\t\t\t\t\tLOADING.....");
				Thread.sleep(700);
				Cls.clearScreen();
				
			}
			
		}//While End					
		
	}//Method : main
	
}


