package lecturer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.CourseNameDTO;
import dto.VwCourseDTO;
import util.DBUtil;

public class LeAttendanceDAO {

	private static Connection conn;
	private static Statement stat;
	private static PreparedStatement pstat;
	
	static {
		DBUtil util = new DBUtil();
		conn = util.connect();
		try {
			stat = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	public ArrayList<VwCourseDTO> courseNameList(String lecturerSeq) {

		
		try {
			
			String sql = String.format("SELECT * FROM vwCourse WHERE vlecturerSeq = %s", lecturerSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseDTO> courseNameList = new ArrayList<VwCourseDTO>();
			
			while (rs.next()) {				
				
				VwCourseDTO courseDTO = new VwCourseDTO();
				courseDTO.setVcourseSeq(rs.getString("VcourseSeq"));
				courseDTO.setVcourseName(rs.getString("VcourseName"));	
				
				courseNameList.add(courseDTO);					
			}
			
			return courseNameList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
			System.out.println("LeAttendanceDAO.courseNameList()");
		}
		
		return null;
	}

}
