package lecturer.view;

import java.util.Scanner;

public class WarningView {

	public static final int INIMENU = 1;
	public static final int ENDINPUT = 2;

	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
	public void title(int n) {
		
		if (n==WarningView.INIMENU) {
			System.out.println("\t\t\t\t[특별 상담 관리]");
			System.out.println("\n\t==========================================================================\n");
			
			System.out.println("\t\t\t\t[1] 특별 상담 대상 학생 조회\n");
			System.out.println();
			System.out.println("\t\t\t\t[0] 돌아가기\n");
			
			System.out.println("\t--------------------------------------------------------------------------\n");
			
			System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
			System.out.print("\t\t\t\t입력: ");
		}
	}
	
	
	public void warningSubMenu() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\n\t\t\t\t특별상담 대상 끝.");
		System.out.println("\n\t\t\t\t특별상담 일지를 작성하시려면 학생 번호를 입력해주십시오.");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}

	public void requireInput() {
		System.out.println("\n\t\t\t\t상담내용을 입력해주십시오. (최대 200자)");
		System.out.print("\t\t\t\t입력: ");
	}

	public void success() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\n\t\t\t\t특별 상담 일지 작성이 완료되었습니다.");
		System.out.println("\n\t\t\t\t이전 메뉴로 돌아갑니다. 엔터를 입력해주십시오.");
	
		scan.nextLine();
	}

	public void failure() {
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\n\t\t\t\t특별 상담 일지 작성 실패.");
		System.out.println("\n\t\t\t\t이전 메뉴로 돌아갑니다. 엔터를 입력해주십시오.");
	
		scan.nextLine();		
	}
	
	

}
