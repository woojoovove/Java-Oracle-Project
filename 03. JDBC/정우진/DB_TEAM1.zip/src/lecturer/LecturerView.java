package lecturer;

public class LecturerView {

	public static final int ATTENDANCE = 1;

	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 교사]");
		
	}//Method : begin
	
//-----------------------------------------------------------------
	
	public void menu() {
	
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 강의 스케줄 관리\n");
		System.out.println("\t\t\t\t[2] 배점 관리\n");
		System.out.println("\t\t\t\t[3] 성적 관리\n");
		System.out.println("\t\t\t\t[4] 출결 관리\n");
		System.out.println("\t\t\t\t[5] 추천서 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu

	public void attendanceMenu() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과정별 출결 조회\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
	}

	public void title(int n) {
		switch(n)
		
		{
		case LecturerView.ATTENDANCE		: System.out.println("\t\t\t\t[과정별 출결 조회]"); break;
		}
	}

	public void attendanceSubMenu() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t조회 방법을 선택하십시오");
		System.out.println("\t\t\t\t[1] 전체 조회\n");
		System.out.println("\t\t\t\t[2] 기간별 조회\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}
	
}//Class : LecturerView
