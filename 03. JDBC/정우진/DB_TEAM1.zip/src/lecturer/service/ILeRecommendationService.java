package lecturer.service;

public interface ILeRecommendationService {

}
