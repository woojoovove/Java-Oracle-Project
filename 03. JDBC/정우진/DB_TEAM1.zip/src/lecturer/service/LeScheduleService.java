package lecturer.service;

public class LeScheduleService implements ILeScheduleService{

}
