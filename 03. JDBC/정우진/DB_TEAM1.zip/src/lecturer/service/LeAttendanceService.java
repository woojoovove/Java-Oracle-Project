package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.DAO.AdAttendanceDAO;
import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import dto.VwSubjectDTO;
import lecturer.dao.LeAttendanceDAO;

public class LeAttendanceService implements ILeAttendanceService {

	private Scanner scan = new Scanner(System.in);
	
	public void courseMenu(String lecturerSeq) {
		
		// DB 작업을 하는 DAO 객체를 하나 만듬
		// DAO가 가지는 구체적인 메소드를 부르면 원하는 자료를 원하는 형태(XXXDTO 어레이 리스트 등)로 가져다 줌.
		
		LeAttendanceDAO leAttendanceDAO = new LeAttendanceDAO();
		
		ArrayList<VwCourseDTO> courseNameDTO= leAttendanceDAO.courseNameList(lecturerSeq);
		
		System.out.println("\n\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		for(VwCourseDTO dto : courseNameDTO) {
			
			System.out.printf("\t[%s] %s\n", dto.getVcourseSeq(), dto.getVcourseName());
			System.out.println("\t--------------------------------------------------------------------------\n");
		}
		System.out.println("\t==========================================================================\n");
		System.out.println("\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		
	}

	public void fullAttendance(String courseSeq) {

		AdAttendanceDAO dao = new AdAttendanceDAO();
		
		VwCourseDTO dto = dao.singleCourseInfo(courseSeq);
		
		System.out.println("\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		System.out.printf("\t%s", dto.getVcourseName());
		System.out.println("\n\t==========================================================================\n");
		System.out.println();
		System.out.println("\t[전체 기간 조회]");
				
		ArrayList<VwCountAttendanceDTO> list = dao.fullAttendance(courseSeq);
				
		for (VwCountAttendanceDTO dto2 : list) {
			System.out.println("\n\t--------------------------------------------------------------------------\n");
			System.out.printf("\t이름: %s\n", dto2.getName());
			System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
								, dto2.getAttended()
								, dto2.getLate()
								, dto2.getEarly()
								, dto2.getGoout()
								, dto2.getAbscence());
			
		}
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
		
		String select = scan.nextLine();
	}

	public void AttendanceBySubject(String courseSeq) {

		boolean bool = true;
		
		while(bool) {

			AdAttendanceDAO dao = new AdAttendanceDAO();
			
			VwCourseDTO dto = dao.singleCourseInfo(courseSeq);
			
			System.out.println("\t\t\t\t[과목별 출결 조회]");

			
			System.out.println("\t[과정명]");
			System.out.println("\n\t==========================================================================\n");
			System.out.printf("\t%s (%s ~ %s)"
								, dto.getVcourseName()
								, dto.getVcourseStartDate().split(" ")[0]
								, dto.getVcourseEndDate().split(" ")[0]);
			System.out.println("\n\t==========================================================================\n");
			System.out.println();
			System.out.println("\t[과목 구분]");
			
			ArrayList<VwSubjectDTO> list2 = dao.subjectList(courseSeq);
			
			for (VwSubjectDTO dto2 :list2) {
				
				System.out.printf("\t[%s] %s\n", dto2.getVsubjectSeq(), dto2.getVsubjectName());
				System.out.println("\n\t--------------------------------------------------------------------------\n");

			}
			
			System.out.println("\n\t==========================================================================\n");
			System.out.println("\t[0] 돌아가기");
			System.out.println("\n\t--------------------------------------------------------------------------\n");
			System.out.println("\t[ ] 안의 번호를 입력하십시오. ");
			System.out.println("\t입력: ");

			String subjectSeq = scan.nextLine();
			
			
			ArrayList<VwCountAttendanceDTO> list = dao.monthlyAttendance(courseSeq, subjectSeq);
			
			for (VwCountAttendanceDTO dto2 : list) {
				System.out.println("\n\t--------------------------------------------------------------------------\n");
				System.out.printf("\t이름: %s\n", dto2.getName());
				System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
									, dto2.getAttended()
									, dto2.getLate()
									, dto2.getEarly()
									, dto2.getGoout()
									, dto2.getAbscence());
				
			}
			System.out.println("\n\t==========================================================================\n");
			System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
			
			String select = scan.nextLine();
			bool = false;

		}
	}

}
