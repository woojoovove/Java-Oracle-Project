package lecturer.service;

public class LeGradeService implements ILeGradeService{

}
