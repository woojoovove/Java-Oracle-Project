package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import dto.WarningDTO;
import lecturer.dao.LeWarningDAO;
import lecturer.view.WarningView;

public class LeWarningService implements ILeWarningService {

	private static WarningView view;
	private static Scanner scan;
	
	static {
		view = new WarningView();
		scan = new Scanner(System.in);
	}
	
	@Override
	public void listStudents(String lecturerSeq) {
		System.out.println("\t[번호]\t[이름]\t[출결점수] [강사명]\t\t[과정명]");
		LeWarningDAO dao = new LeWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(lecturerSeq); 
		
		for (WarningDTO student : studentList) {
			
			System.out.printf("\t[%s]\t%s\t%s\t\t%s\t%s"
								, student.getSTUDENTSEQ()
								, student.getSTUDENTNAME()
								, student.getATTENDANCEGRADE()
								, student.getLECTURERNAME()
								, student.getCOURSENAME());
			System.out.println("\n\t--------------------------------------------------------------------------\n");
		
		}
		
		
	}

	@Override
	public WarningDTO counsel(String lecturerSeq, String select) {

		LeWarningDAO dao = new LeWarningDAO();
		WarningDTO student = dao.getSingleStudent(select); 
		
		System.out.println("\n\t\t\t\t[특별상담일지 ]");
		System.out.println("\n\t==========================================================================\n");
		System.out.printf("\t[%s] %s [출결점수] %s [과정명] %s "
							, student.getSTUDENTSEQ()
							, student.getSTUDENTNAME()
							, student.getATTENDANCEGRADE()
							, student.getCOURSENAME());
		System.out.println("\n\t=================================상담내용===================================\n");

		view.requireInput();
		String content = scan.nextLine();
		
		student.setCOUNSELINGCONTENT(content);
		return student;
	}

	@Override
	public int insert(WarningDTO student) {

		LeWarningDAO dao = new LeWarningDAO();
		return dao.insert(student);
	}

}
