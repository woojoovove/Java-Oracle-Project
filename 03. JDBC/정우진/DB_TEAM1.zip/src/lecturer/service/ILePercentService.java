package lecturer.service;

public interface ILePercentService {

}
