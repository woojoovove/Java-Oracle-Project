package lecturer.service;

public class LePercentService implements ILePercentService{

}
