package lecturer.service;

public interface ILeGradeService {

}
