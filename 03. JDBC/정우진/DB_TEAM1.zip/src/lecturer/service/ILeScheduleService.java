package lecturer.service;

public interface ILeScheduleService {

}
