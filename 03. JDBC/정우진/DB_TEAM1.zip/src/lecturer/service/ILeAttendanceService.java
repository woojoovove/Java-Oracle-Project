package lecturer.service;

public interface ILeAttendanceService {

}
