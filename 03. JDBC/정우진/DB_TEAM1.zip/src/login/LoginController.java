package login;

import java.util.Scanner;

import admin.AdministratorController;
import lecturer.LecturerController;
import student.StudentController;

public class LoginController {

	private static LoginView loginView;	
	private static Scanner scan;
	
	static {
		loginView = new LoginView();
		scan = new Scanner(System.in);
	}
	
//--------------------------------------------------------------------------	
	
	public static void main(String[] args) throws Exception {

		boolean loginLoop = true;
		
		while (loginLoop) {
			
			loginView.begin();
			loginView.menu();
			
			String select = scan.nextLine();
			
			if (select.equals("1")) {
								
				Cls.clearScreen();
				System.out.println("\t\t\t\t\tLOADING.....");
				Thread.sleep(700);
				Cls.clearScreen();
				
				loginView.begin();
				String id = loginView.login();
				
				if (id.startsWith("admin")) { //관리자 이름으로 로그인
					
					loginView.loginProcess();
					Thread.sleep(700);
					AdministratorController.main(args);	//관리자메뉴
					
				} else if (id.startsWith("lecturer")) { //교사 이름으로 로그인
					
					loginView.loginProcess();
					Thread.sleep(700);
					LecturerController.main(args); //교사메뉴					
					
				} else if (id.startsWith("student")) { //교육생 이름으로 로그인
					
					loginView.loginProcess();
					Thread.sleep(700);
					StudentController.main(args); //교육생메뉴
												
				} else {
					
					loginView.loginError();											
					Cls.clearScreen();
					System.out.println("\t\t\t\t\tLOADING.....");
					Thread.sleep(700);
					Cls.clearScreen();
					
				}
				
			} else if (select.equals("0")) {
				
				loginLoop = false;
								
			}
	
		}//While End
		
		loginView.end();
			
	}//Method : main

}//Class : LoginController


