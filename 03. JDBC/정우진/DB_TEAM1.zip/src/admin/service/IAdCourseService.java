package admin.service;

public interface IAdCourseService {
	
	void courseAdd();	
	String courseList();	
	void courseEdit();	
	void courseDelete();	
		
	void subjectAdd();
	void subjectList();
	void subjectEdit();	
	void subjectDelete();
	
}
