package admin.service;

public interface IAdLecturerInfoService {

}
