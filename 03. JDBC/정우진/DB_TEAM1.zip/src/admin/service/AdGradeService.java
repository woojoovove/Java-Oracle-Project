package admin.service;

public class AdGradeService implements IAdGradeService {

	public static void gradeByCourse() {
		// TODO Auto-generated method stub
		
	}

	public static void gradeByName() {
		// TODO Auto-generated method stub
		
	}

}
