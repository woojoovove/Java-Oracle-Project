package admin.service;

public class AdStudentService implements IAdStudentService {

	public static void studentAdd() {
		// TODO Auto-generated method stub
		
	}

	public static void searchByName() {
		// TODO Auto-generated method stub
		
	}

	public static void searchByCourse() {
		// TODO Auto-generated method stub
		
	}

}
