package admin.service;

public class AdBasicInfoService implements IAdBasicInfoService {

}
