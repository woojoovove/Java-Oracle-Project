package admin.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import admin.AdministratorView;
import admin.DAO.AdAttendanceDAO;
import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import dto.VwSubjectDTO;
import util.DBUtil;

public class AdAttendanceService implements IAdAttendanceService {
	
	private static AdministratorView view;
	private static Scanner scan;
	private static Connection conn;
	private static Statement stat;
	private static PreparedStatement pstat;
	
	static {

		view = new AdministratorView();
		scan = new Scanner(System.in);
		
		try {
			DBUtil util = new DBUtil();
			conn = util.connect();
			stat = conn.createStatement();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	

	@Override
	public void fullAttendance(String courseSeq) {
		
		AdAttendanceDAO dao = new AdAttendanceDAO();
		
		VwCourseDTO dto = dao.singleCourseInfo(courseSeq);
		
		System.out.println("\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		System.out.printf("\t%s", dto.getVcourseName());
		System.out.println("\n\t==========================================================================\n");
		System.out.println();
		System.out.println("\t[전체 기간 조회]");
				
		ArrayList<VwCountAttendanceDTO> list = dao.fullAttendance(courseSeq);
				
		for (VwCountAttendanceDTO dto2 : list) {
			System.out.println("\n\t--------------------------------------------------------------------------\n");
			System.out.printf("\t이름: %s\n", dto2.getName());
			System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
								, dto2.getAttended()
								, dto2.getLate()
								, dto2.getEarly()
								, dto2.getGoout()
								, dto2.getAbscence());
			
		}
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
		
		String select = scan.nextLine();
	}


	@Override
	public void attendanceByMonth(String courseSeq) {
		
		boolean bool = true;
		
		while(bool) {

			AdAttendanceDAO dao = new AdAttendanceDAO();
			
			VwCourseDTO dto = dao.singleCourseInfo(courseSeq);
			
			System.out.println("\t\t\t\t[과목별 출결 조회]");

			
			System.out.println("\t[과정명]");
			System.out.println("\n\t==========================================================================\n");
			System.out.printf("\t%s (%s ~ %s)"
								, dto.getVcourseName()
								, dto.getVcourseStartDate().split(" ")[0]
								, dto.getVcourseEndDate().split(" ")[0]);
			System.out.println("\n\t==========================================================================\n");
			System.out.println();
			System.out.println("\t[과목 구분]");
			
			ArrayList<VwSubjectDTO> list2 = dao.subjectList(courseSeq);
			
			for (VwSubjectDTO dto2 :list2) {
				
				System.out.printf("\t[%s] %s\n", dto2.getVsubjectSeq(), dto2.getVsubjectName());
				System.out.println("\n\t--------------------------------------------------------------------------\n");

			}
			
			System.out.println("\n\t==========================================================================\n");
			System.out.println("\t[0] 돌아가기");
			System.out.println("\n\t--------------------------------------------------------------------------\n");
			System.out.println("\t[ ] 안의 번호를 입력하십시오. ");
			System.out.println("\t입력: ");

			String subjectSeq = scan.nextLine();
//			String s = (dto.getVcourseStartDate().split("-"))[1];
//			String e = (dto.getVcourseEndDate().split("-"))[1];
			
			
			
			ArrayList<VwCountAttendanceDTO> list = dao.monthlyAttendance(courseSeq, subjectSeq);
			
			for (VwCountAttendanceDTO dto2 : list) {
				System.out.println("\n\t--------------------------------------------------------------------------\n");
				System.out.printf("\t이름: %s\n", dto2.getName());
				System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
									, dto2.getAttended()
									, dto2.getLate()
									, dto2.getEarly()
									, dto2.getGoout()
									, dto2.getAbscence());
				
			}
			System.out.println("\n\t==========================================================================\n");
			System.out.println("\t이전 화면으로 돌아갑니다. 엔터를 입력해주세요.");
			
			String select = scan.nextLine();
			bool = false;

		}
	}




}