package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.AdministratorView;
import admin.DAO.AdWarningDAO;
import dto.WarningDTO;

public class AdWarningService implements IAdWarningService {

	private static AdministratorView adminview;
	private static Scanner scan;
	
	static {
		adminview = new AdministratorView();
		scan = new Scanner(System.in);
	}
	
	@Override
	public void listStudents() {
		
		System.out.println("\t[번호]\t[이름]\t[출결점수]\t[강사명]\t\t[과정명]");
		AdWarningDAO dao = new AdWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(); 
		
		for (WarningDTO student : studentList) {
			
			System.out.printf("\t[%s]\t%s\t%s\t\t%s\t%s"
								, student.getSTUDENTSEQ()
								, student.getSTUDENTNAME()
								, student.getATTENDANCEGRADE()
								, student.getLECTURERNAME()
								, student.getCOURSENAME());
			System.out.println("\n\t--------------------------------------------------------------------------\n");
		
		}
	}

	@Override
	public void notifyLecturer() {
		
		AdWarningDAO dao = new AdWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(); 
		
		dao.notifyLecturer(studentList);
		
		adminview.pause(AdministratorView.WARNING);
	}

}



























