package admin.service;

public interface IAdBasicInfoService {

}
