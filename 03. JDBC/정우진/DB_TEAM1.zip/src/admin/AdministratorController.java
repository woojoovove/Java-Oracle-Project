package admin;

import java.util.Scanner;

import admin.service.AdAttendanceService;
import admin.service.AdBasicInfoService;
import admin.service.AdGradeService;
import admin.service.AdStudentService;
import admin.service.AdWarningService;
import admin.service.IAdCourseService;
import admin.service.IAdRecommendationService;
import admin.service.IAdWarningService;
import login.Cls;

public class AdministratorController {

	private static AdministratorView administratorView;
	
	private static IAdCourseService adCourseService;
	private static AdAttendanceService attendanceService;
	private static IAdRecommendationService recommendationService;
	private static IAdWarningService adWarningService;
	
	private static Scanner scan;
	
	static {
		administratorView = new AdministratorView();
		attendanceService = new AdAttendanceService();
		adWarningService = new AdWarningService();
		scan = new Scanner(System.in);
	}
	
//==========================================================================================================
	
	public static void main(String[] args) throws Exception {

		boolean administratorLoop = true;
		
		while (administratorLoop) {
			
			Cls.clearScreen();
			System.out.println("\t\t\t\t\tLOADING.....");
			Thread.sleep(700);
			Cls.clearScreen();
			
			administratorView.begin();
			administratorView.menu();
			String select = scan.nextLine();
			
	//------------------------------------------------------------------------------------------------------
			
			if (select.equals("1")) { //기초 정보 관리
							
				boolean adBasicInfoLoop = true;
				
				while (adBasicInfoLoop) {
					
					administratorView.basicInfomenu();
					select = scan.nextLine();

					AdBasicInfoService abis = new AdBasicInfoService();

					if (select.equals("1")) { // 과정명 보기
						
						firstCourseName();

					} else if (select.equals("2")) { // 과목명 보기
						
						secondSubjectName();
						
					} else if (select.equals("3")) { // 강의실명 보기
						
						ThirdClassRoom();
						
					} else if (select.equals("4")) { // 교재명 보기
						
						FourthTextBook();
						
					} else if (select.equals("0")) { // 돌아가기

						System.out.println("이전 화면으로 돌아갑니다");
						administratorView.menu();

					} else {
						System.out.println("다시 입력해 주세요");

						continue;
					}
					
				}//While : adBasicInfoLoop		
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("2")) { //교사 계정 관리
								
				boolean adLecturerInfoLoop = true;
				
				while (adLecturerInfoLoop) {
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("3")) { //개설 과정 관리
						
				Cls.clearScreen();
				System.out.println("\t\t\t\t\tLOADING.....");
				Thread.sleep(700);
				Cls.clearScreen();
				administratorView.courseManagement();
				
				boolean adCourseLoop = true;
				
				while (adCourseLoop) {
					
					select = scan.nextLine();
					
					if (select.equals("1")) { //개설 과정 신규 등록
						
						adCourseService.courseAdd();												
											
					} else if (select.equals("2")) { //개설 과정 조회
						
						boolean adCourseListLoop = true;
						
						while (adCourseListLoop) {
							
							String courseNum = adCourseService.courseList();
							
							if (courseNum.equals("0")) adCourseListLoop = false;
							else if (courseNum.equals("again")) continue;	
							else {
								
								//개설 과정 관리(과목, 교육생)
								boolean adSubjectInfoLoop = true;
								
								while (adSubjectInfoLoop) {
									
									select = scan.nextLine();
									
									if (select.equals("1")) {
										
										adCourseService.subjectList();
										
									} else if (select.equals("2")) {
										
										adCourseService.subjectAdd();
										
									} else if (select.equals("3")) {
										
										adCourseService.subjectEdit();
										
									} else if (select.equals("4")) {
										
										adCourseService.subjectDelete();
										
									} else if (select.equals("5")) {
										
										//교육생 목록
										
									} else if (select.equals("0")) {
										adSubjectInfoLoop = false;
									}
									
								}//While : adSubjectInfoLoop
								
							}
			
						}//While : adCourseListLoop

					} else if (select.equals("3")) { //개설 과정 수정
						
						
						
					} else if (select.equals("4")) { //개설 과정 삭제
						
						
						
					} else if (select.equals("0")) { //이전 메뉴로 돌아가기
						
						adCourseLoop = false;
						
					} else {						
						System.out.println("\t\t\t\t잘못된 입력입니다");						
					}
					
				}//While : adCourseLoop	
								
	//------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("4")) { //교육생 관리
				
				boolean adStudentLoop = true;
				
				while (adStudentLoop) {
					
					administratorView.menuAdStudent();
					
					String sel = scan.nextLine();
					if (sel.equals("1")) {
						
						AdStudentService.studentAdd();
						
					}
						
					else if (sel.equals("2")) {
						
						boolean bool = true;
						
						while(bool) {

							administratorView.menuManageStudent();
							
							String p = scan.nextLine();
							if (p.equals("1")) {
								
								AdStudentService.searchByName();
								
							}
							
							else if (p.equals("2")) {
								
								AdStudentService.searchByCourse();
								
							}
						}
						
					} else adStudentLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("5")) { //성적 관리
				
				boolean adGradeLoop = true;
				
				while (adGradeLoop) {
					
					administratorView.menuGrade();
					
					String pick = scan.nextLine();
					
					if (pick.equals("1")) {
						
						AdGradeService.gradeByCourse();
						
					}
					
					else if (pick.equals("2")) {
						
						AdGradeService.gradeByName();
						
					}
					
					else adGradeLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("6")) { //출결 관리
								
				boolean adAttendanceLoop = true;
				
				while (adAttendanceLoop) {
					
					administratorView.menuAttendance();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
						
						boolean p = true;
						
						while(p) {
							
							administratorView.title(AdministratorView.ATTENDANCEBYCOURSE);
							administratorView.menuCourse();
							String courseSeq = scan.nextLine();
							administratorView.menuCourseSub();
							
							
							select = scan.nextLine();
							
							if(select.equals("1")) {
								attendanceService.fullAttendance(courseSeq);
							} else if (select.equals("2")) {
								attendanceService.attendanceByMonth(courseSeq);
							} else {
								p = false;
								break;
							}		
						}
					}
					
					else if (select.equals("0")) adAttendanceLoop = false;
					
				}	
				
	//------------------------------------------------------------------------------------------------------
				
			} else if (select.equals("7")) { //추천서 관리
								
				boolean adRecommendationLoop = true;
				
				while (adRecommendationLoop) {
					
					administratorView.title(administratorView.RECOMMENDATION);
					recommendationService.recommendation();
					
				}	
				
	//------------------------------------------------------------------------------------------------------				
	
			} else if (select.equals("8")) { //특별 상담 관리
				
				boolean adWarningLoop = true;
				
				while (adWarningLoop) {
					
					administratorView.title(administratorView.WARNING);
					administratorView.warningMenu();
					
					select = scan.nextLine();
					
					if (select.equals("1")) {
						
						adWarningService.listStudents();
						administratorView.warningSubMenu();
						select = scan.nextLine();
						
						if (select.equals("1")) {
							adWarningService.notifyLecturer();
						}
					} else {
						adWarningLoop = false;
					}
				}	
	//------------------------------------------------------------------------------------------------------	
				
			} else if (select.equals("0")) { //로그아웃
								
				administratorLoop = false;	
				
				Cls.clearScreen();
				System.out.println("\t\t\t\t\tLOADING.....");
				Thread.sleep(700);
				Cls.clearScreen();
				
			}
			
		}//While End
		
	}//Method : main

	private static void FourthTextBook() {
		// TODO Auto-generated method stub
		
	}

	private static void ThirdClassRoom() {
		// TODO Auto-generated method stub
		
	}

	private static void secondSubjectName() {
		// TODO Auto-generated method stub
		
	}

	private static void firstCourseName() {
		// TODO Auto-generated method stub
		
	}
	
}//Class : AdministratorController


