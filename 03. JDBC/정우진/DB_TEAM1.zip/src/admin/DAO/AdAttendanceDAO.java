package admin.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.CourseNameDTO;
import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import dto.VwSubjectDTO;
import util.DBUtil;

public class AdAttendanceDAO {

	private static Connection conn;
	private static Statement stat;
	private static PreparedStatement pstat;
	//--------------------------------------------------------------------------------------------	

	public AdAttendanceDAO() {
		try {
			
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
			
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO");
		}
	}
	//--------------------------------------------------------------------------------------------	
	
//	public boolean isConnected() {
//		try {
//			return !this.isConnected();
//		} catch (Exception e) {
//			System.out.println(e.toString());
//		}
//		return false;
//	}
//	//--------------------------------------------------------------------------------------------	
//	
//	public void close() {
//		try {
//			this.conn.close();
//		} catch (Exception e) {
//			System.out.println(e.toString());
//		}
//	}
	//--------------------------------------------------------------------------------------------	
	
	public ArrayList<CourseNameDTO> courseNameList() {
		
		try {
			
			String sql = "SELECT * FROM tblCourseName";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<CourseNameDTO> courseNameList = new ArrayList<CourseNameDTO>();
			
			while (rs.next()) {				
				CourseNameDTO courseNameDTO = new CourseNameDTO();
				
				courseNameDTO.setSeq(rs.getString("seq"));
				courseNameDTO.setName(rs.getString("name"));	
				
				courseNameList.add(courseNameDTO);					
			}
			
			return courseNameList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
			System.out.println("StAttendanceDAO.courseNameList()");
		}
		
		return null;
		
	}//method : courseNameList 
	
	//--------------------------------------------------------------------------------------------	
	public VwCourseDTO singleCourseInfo(String courseSeq) {
		
		try {
			VwCourseDTO dto = new VwCourseDTO();

			String sql = String.format("SELECT * FROM vwCourse WHERE vCourseSeq = %s", courseSeq);
			
			ResultSet rs = stat.executeQuery(sql);
			if(rs.next()) {
				
				dto.setVclassroom(rs.getString("vclassroom"));	
				dto.setVcourseEndDate(rs.getString("vcourseEndDate"));
				dto.setVcourseName(rs.getString("vcourseName"));
				dto.setVcourseSeq(rs.getString("vcourseSeq"));
				dto.setVcourseStartDate(rs.getString("vcourseStartDate"));
				dto.setVlecturerSeq(rs.getString("vlecturerSeq"));
				
			}
			
			return dto;
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
	
	
	
	//--------------------------------------------------------------------------------------------	
		
	public ArrayList<VwCountAttendanceDTO> fullAttendance(String courseSeq) {
		try {
			
			String sql = String.format("SELECT * FROM vWcountattendance WHERE seq IN (SELECT seq FROM tblStudent WHERE courseSeq = %s)"
									, courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCountAttendanceDTO> list = new ArrayList<VwCountAttendanceDTO>();
			
			while (rs.next()) {
				
				VwCountAttendanceDTO dto = new VwCountAttendanceDTO();
				
				dto.setSeq(rs.getString("seq"));
				dto.setName(rs.getString("name"));
				dto.setGoout(rs.getString("goout"));
				dto.setEarly(rs.getString("early"));
				dto.setLate(rs.getString("late"));
				dto.setAttended(rs.getString("attended"));
				dto.setAbscence(rs.getString("abscence"));
				
				list.add(dto);
				
			}
			
			return list;
			
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO.fullAttendance()");
		}
		
		return null;
		
	}
	
	//--------------------------------------------------------------------------------------------	
	
	
	public ArrayList<VwSubjectDTO> subjectList(String courseSeq) {
		try {
			
			String sql = String.format("SELECT * FROM vwSubject WHERE vCourseSeq = %s"
									, courseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwSubjectDTO> list = new ArrayList<VwSubjectDTO>();
			
			while (rs.next()) {
				
				VwSubjectDTO dto = new VwSubjectDTO();
				
				dto.setVcourseSeq(rs.getString("VCOURSESEQ"));
				dto.setVcourseName(rs.getString("VCOURSENAME"));
				dto.setVlecturerName(rs.getString("VLECTURERNAME"));
				dto.setVsubjectEndDate(rs.getString("VSUBJECTENDDATE"));
				dto.setVsubjectName(rs.getString("VSUBJECTNAME"));
				dto.setVsubjectSeq(rs.getString("VSUBJECTSEQ"));
				dto.setVsubjectStartDate(rs.getString("VSUBJECTSTARTDATE"));
				dto.setvTextbook(rs.getString("VTEXTBOOK"));
				
				
				list.add(dto);
				
			}
			
			return list;
			
		} catch (Exception e) {
			System.out.println(e.toString());
			System.out.println("StAttendanceDAO.monthlyAttendance()");
		}
		
		return null;
		
	}

	public ArrayList<VwCountAttendanceDTO> monthlyAttendance(String courseSeq, String subjectSeq) {

		try {
			
			//startDate & endDate
			String sql  = "SELECT VSUBJECTSTARTDATE, VSUBJECTENDDATE FROM vwSubject	WHERE vsubjectSeq = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, subjectSeq);
			
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				
				String startDate = rs.getString("VSUBJECTSTARTDATE").split(" ")[0];
				String endDate = rs.getString("VSUBJECTENDDATE").split(" ")[0];
							
				String vwDate = String.format("create or replace view vwDate as select to_date('%s','yyyy-mm-dd') + level - 1 as regdate from dual connect by level <= (to_date('%s','yyyy-mm-dd')-to_date('%s','yyyy-mm-dd') + 1 )"
												, startDate, endDate, startDate);
				pstat = conn.prepareStatement(vwDate);
				pstat.executeUpdate();
			}
			
			String vwCountAttendance = String.format("SELECT * FROM vwCountAttendance WHERE seq IN (SELECT seq FROM tblStudent WHERE courseSeq = %s)", courseSeq);
			
			pstat = conn.prepareStatement(vwCountAttendance);
			ResultSet rs2 = pstat.executeQuery();
			
			ArrayList<VwCountAttendanceDTO> list = new ArrayList<VwCountAttendanceDTO>();
			
			while (rs2.next()) {
				
				VwCountAttendanceDTO dto = new VwCountAttendanceDTO();

				dto.setName(rs2.getString("name"));
				dto.setSeq(rs2.getString("seq"));
				dto.setAbscence(rs2.getString("abscence"));
				dto.setAttended(rs2.getString("attended"));
				dto.setEarly(rs2.getString("early"));
				dto.setGoout(rs2.getString("goout"));
				dto.setLate(rs2.getString("late"));

				list.add(dto);
			}
			return list;
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}

}
