package dto;

public class VwCourseTotalDTO {

		private String vname;
		private String vtotal;
		
	
		public String getVname() {
			return vname;
		}
		public void setVname(String vname) {
			this.vname = vname;
		}
		public String getVtotal() {
			return vtotal;
		}
		public void setVtotal(String vtotal) {
			this.vtotal = vtotal;
		}
			
}
