package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.AdminDAO;
import dto.*;

public class AdStudentService implements IAdStudentService {

	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	public static void studentAdd() {
		
		boolean loop = true;
		while(loop) {
			System.out.println("[교육생 등록]");
			System.out.println("이름을 입력해주십시오");
			System.out.print("입력[한글]: ");
			String name =scan.nextLine();
			
			System.out.println("주민번호 뒷자리를 입력해주십시오");
			System.out.print("입력[번호 7자리]: ");
			String rnum =scan.nextLine();
			
			System.out.println("전화번호를 입력해주십시오");
			System.out.print("입력[000-0000-0000]: ");
			String pnum =scan.nextLine();
			
			AdminDAO dao = new AdminDAO();
			dao.studentAdd(name,rnum,pnum);
			dao.close();
			
			System.out.println("[1]교육생 추가 등록");
			System.out.println("[0]뒤로 가기");
			
			if(scan.nextLine().equals("0")) {
				loop = false;
			}else {
				System.out.println("교육생을 추가로 등록합니다.");
			}
		}
		
		
		
		
		
	}//StudentAdd
	public static void searchByName() {
		
		System.out.println("[이름으로 교육생 검색]");
		System.out.println("교육생 이름을 입력해주십시오");
		System.out.print("입력[한글]: ");
		
		boolean loop = true;
		while(loop) {
			AdminDAO dao = new AdminDAO();
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
			list = dao.searchByName(scan.nextLine());
			
			System.out.println("번호\t이름\t주민번호 뒷자리\t전화");
			for(StudentInfoDTO dto : list) {
				System.out.println(String.format("[%s]\t%s\t%s\t%s", 
						dto.getSeq(),dto.getName(),dto.getRegistrationNum(),dto.getPhoneNum()));
				
			}
			
			System.out.println("[0] 뒤로가기");
			System.out.println("[]안의 번호를 입력하세요");
			System.out.print("입력 :");
			
			//dto list에서 name seq받아서 name 찾기
			if(scan.nextLine().equals("0")) {
				loop = false;
			}else {
				AdStudentService.selectedstudentinfo(scan.nextLine());
			}
			
		}
		
		
		
		
		
	}
	private static void selectedstudentinfo(String nextLine) {
		boolean loop = true;
		
		System.out.println("[교육생 상세 정보 확인]");
		System.out.println("[기본사항]");
		
		AdminDAO dao = new AdminDAO();
		StudentInfoDTO studto = new StudentInfoDTO();
		studto = dao.studentInfoBySeq(nextLine);
		
		VwstucouDTO coudto = new VwstucouDTO();
		coudto = dao.courseInfo(nextLine);
		
		while(loop) {
			
			System.out.println("[기본사항]");
			System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
			System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
					studto.getSeq(),studto.getName(),studto.getRegistrationNum()
					,studto.getPhoneNum(),studto.getRegistrationDate()));
			
			System.out.println("[과정 정보]");
			System.out.println("등록 과정 명 \t"+coudto.getVcouname());
			System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
			System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
			System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
			System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
			
			System.out.println("[1] 교육생 정보 수정");
			System.out.println("[2] 교육생 삭제");
			System.out.println("[0] 뒤로 가기");
			
			System.out.println("[]안의 번호를 입력하세요");
			System.out.print("입력 :");
			
			if(scan.nextLine().equals("0")) {
				loop =false;
			}else if(scan.nextLine().equals("1")) {
				AdStudentService.stuInfoModify(coudto);
				
			}else if(scan.nextLine().equals("2")) {
				AdStudentService.stuInfoDelete(coudto);
				
			}else {
				System.out.println("다시 입력해주세요.");
			}

			
						
		}
		
		dao.close();
		
		
		
		
	}
	private static void stuInfoDelete(VwstucouDTO coudto) {
		
		System.out.println(coudto.getVstuname()+" 교육생의 정보를 삭제합니다");
		AdminDAO dao = new AdminDAO();
		dao.studentinfoDelete(coudto.getVstuinseq());
		dao.close();
		
	}
	private static void stuInfoModify(VwstucouDTO coudto) {
		boolean loop = true;
		while(loop) {
			
			System.out.println("[기본사항]");
			System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
			System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
					coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
					,coudto.getVstupnum(),coudto.getVstuinrdate()));
			
			System.out.println("[과정 정보]");
			System.out.println("등록 과정 명 \t"+coudto.getVcouname());
			System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
			System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
			System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
			System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
			
			System.out.println("[1] 이름 수정");
			System.out.println("[2] 주민번호 뒷자리 수정");
			System.out.println("[3] 전화번호 수정");
			System.out.println("[4] 등록일 수정");
			System.out.println("[5] 등록 과정 관리");
			System.out.println("[6] 수료/중도탈락 관리");
			System.out.println("[0] 뒤로 가기");
			
			System.out.println("[]안의 번호를 입력하세요");
			System.out.print("입력 :");
			
			switch(scan.nextLine()) {
			
			case "1" : AdStudentService.stuInfoMoName(coudto); break; 
			case "2" : AdStudentService.stuInfoMoRnum(coudto);break; 
			case "3" : AdStudentService.stuInfoMoPnum(coudto);break; 
			case "4" : AdStudentService.stuInfoMoRdate(coudto);break; 
			case "5" : AdStudentService.stuInfoMoCourse(coudto);break; 
			case "6" : AdStudentService.stuInfoMoStatus(coudto);break; 
			case "0" : loop = false; break; 
				
			
			}

		}
		
		
		
		
		
		
		
	}
	private static void stuInfoMoCourse(VwstucouDTO coudto) {
		
		boolean loop = true;
		
		while(loop) {
		
			System.out.println("[기본사항]");
			System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
			System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
					coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
					,coudto.getVstupnum(),coudto.getVstuinrdate()));
			
			System.out.println("[과정 정보]");
			System.out.println("등록 과정 명 \t"+coudto.getVcouname());
			System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
			System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
			System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
			System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
			
			System.out.println("[1] 과정 추가");
			System.out.println("[2] 과정 삭제");
			System.out.println("[3] 과정별 제적 상태 관리");
			System.out.println("[0] 돌아가기");
			
			System.out.println("[]안의 번호를 입력하세요.");
			System.out.println("입력 :");
			
			switch(scan.nextLine()) {
			
			case "1" : stuInfoCourseAdd(coudto);	break;
			case "2" : stuInfoCourseDel(coudto);	break;
			case "3" : stuInfoCourseManage(coudto);	break;
			case "0" : 	break;
			default : System.out.println("잘못된 입력입니다."); break;
			}
		}
		
		
		// TODO 과정 수정 화면 구성?
		
		
		
	}
	
	private static void stuInfoCourseManage(VwstucouDTO coudto) {
		
		
		
		
	}
	private static void stuInfoCourseDel(VwstucouDTO coudto) {
		
		
	}
	private static void stuInfoCourseAdd(VwstucouDTO coudto) {
		
		
	}
	private static void stuInfoMoStatus(VwstucouDTO coudto) {
		
		System.out.println("[기본사항]");
		System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
		System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		
		System.out.println("[과정 정보]");
		System.out.println("등록 과정 명 \t"+coudto.getVcouname());
		System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
		System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
		System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
		System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		
		System.out.println("수료로 변경[1]입력");
		System.out.println("중도탈락으로 변경[2]입력");
		System.out.print("선택[번호] :");
		String select = scan.nextLine();
		System.out.print("수료처리할/중도탈락처리할 날짜를 입력하십시오.");
		String date = scan.nextLine();
			AdminDAO dao = new AdminDAO();
			dao.modifyStatus(select,date,coudto);
			dao.close();
		
		
		System.out.println(date+"부로 수료처리/중도탈락처리 완료");
	}
	private static void stuInfoMoRdate(VwstucouDTO coudto) {
		System.out.println("[기본사항]");
		System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
		System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		
		System.out.println("[과정 정보]");
		System.out.println("등록 과정 명 \t"+coudto.getVcouname());
		System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
		System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
		System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
		System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		
		System.out.println("새 등록일을 입력해주십시오.");
		System.out.print("새 등록일(0000-00-00)");
		AdminDAO dao = new AdminDAO();
		dao.modifyRdate(coudto,scan.nextLine()); //날짜 어쩔까?
		
		dao.close();
		System.out.println("등록일 수정 완료");
	}
	private static void stuInfoMoPnum(VwstucouDTO coudto) {
		System.out.println("[기본사항]");
		System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
		System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		
		System.out.println("[과정 정보]");
		System.out.println("등록 과정 명 \t"+coudto.getVcouname());
		System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
		System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
		System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
		System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		
		System.out.println("새 전화번호를 입력해주십시오.");
		System.out.print("새 전화번호(000-0000-0000)");
		AdminDAO dao = new AdminDAO();
		dao.modifyPnum(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("전화번호 수정 완료");
	}
	private static void stuInfoMoRnum(VwstucouDTO coudto) {
		System.out.println("[기본사항]");
		System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
		System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		
		System.out.println("[과정 정보]");
		System.out.println("등록 과정 명 \t"+coudto.getVcouname());
		System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
		System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
		System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
		System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		
		System.out.println("새 주민번호 뒷자리를 입력해주십시오.");
		System.out.print("새 주민번호 뒷자리");
		AdminDAO dao = new AdminDAO();
		dao.modifyRnum(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("주민번호 수정 완료");
		
	}
	private static void stuInfoMoName(VwstucouDTO coudto) {
		System.out.println("[기본사항]");
		System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
		System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		
		System.out.println("[과정 정보]");
		System.out.println("등록 과정 명 \t"+coudto.getVcouname());
		System.out.println("과정 시작 날짜 \t"+coudto.getVcoustart());
		System.out.println("과정 종료 날짜 \t"+coudto.getVcouend());
		System.out.println("과정별 재적 상태\t"+coudto.getVstustatus());
		System.out.println("수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		
		System.out.println("새 이름을 입력해주십시오.");
		System.out.print("새 이름");
		
		AdminDAO dao = new AdminDAO();
		dao.modifyName(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("이름 수정 완료");
		
	}
	
	public static void searchByCourse() {
		
		boolean loop = true;
		while(loop) {
			System.out.println("[과정명으로 교육생 검색]");
			
			AdminDAO dao = new AdminDAO();
			ArrayList<VwcoustuDTO>list = dao.vwCouStu();
			
			for(VwcoustuDTO dto : list) {
				System.out.println(String.format("[%s] %s", dto.getVseq(),dto.getVname()));
			}
			
			System.out.println("과정 번호를 입력하세요.");
			System.out.print("입력[번호] :");
			
			if(scan.nextLine().equals("0")) {
				loop=false;
			}else {
				AdStudentService.selCouStuInfo(scan.nextLine()); //과정번호
			}
			
			dao.close();
			
		}
		
		
		
	}
	private static void selCouStuInfo(String nextLine) { //과정번호
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("[과정명으로 교육생 검색]");
			System.out.println("해당 과정을 수강하는 교육생들의 명단은 아래와 같습니다.");
			
			AdminDAO dao = new AdminDAO();
			ArrayList<VwstucouDTO>list = dao.selCouStuList(nextLine);
			
			System.out.println("번호\t이름\t주민번호 뒷자리\t전화번호");
			for(VwstucouDTO dto : list) {
				
				System.out.println(String.format("[%s]\t%s\t%s\t%s",dto.getVstuinseq(),
						dto.getVstuname(),dto.getVsturnum(),dto.getVstupnum()));
				
			}
			dao.close();
			System.out.println("[0] 뒤로가기");
			System.out.println("[]안의 번호를 입력하세요.");
			System.out.println("입력 : ");
			
			if(scan.nextLine().equals("0")) {
				loop = false;
			}else {
				selCouStueachInfo(scan.nextLine());
				
			}
			
		}
		
		
		
		
	}
	private static void selCouStueachInfo(String nextLine) { //stuinfoseq
		
		boolean loop = true;
		AdminDAO dao = new AdminDAO();
		VwstucouDTO dto = new VwstucouDTO();
		dto = dao.courseInfo(nextLine);
		
		while(loop) {
			
			System.out.println("[기본사항]");
			System.out.println("번호\t이름\t주민번호\t전화번호\t등록일");
			System.out.println(String.format("[%s]\t%s\t%s\t%s\t%s", 
					dto.getVstuinseq(),dto.getVstuname(),dto.getVsturnum()
					,dto.getVstupnum(),dto.getVstuinrdate()));
			
			System.out.println("[과정 정보]");
			System.out.println("등록 과정 명 \t"+dto.getVcouname());
			System.out.println("과정 시작 날짜 \t"+dto.getVcoustart());
			System.out.println("과정 종료 날짜 \t"+dto.getVcouend());
			System.out.println("과정별 재적 상태\t"+dto.getVstustatus());
			System.out.println("수료/중도 탈락 날짜 \t"+dto.getVstustatusdate());
			
			System.out.println("[1] 교육생 정보 수정");
			System.out.println("[2] 교육생 삭제");
			System.out.println("[0] 뒤로 가기");
			
			System.out.println("[]안의 번호를 입력하세요");
			System.out.print("입력 :");
			
			if(scan.nextLine().equals("0")) {
				loop =false;
			}else if(scan.nextLine().equals("1")) {
				AdStudentService.stuInfoModify(dto);
				
			}else if(scan.nextLine().equals("2")) {
				AdStudentService.stuInfoDelete(dto);
				
			}else {
				System.out.println("다시 입력해주세요.");
			}

			
						
		}
		
		dao.close();
		
	}

}//class
