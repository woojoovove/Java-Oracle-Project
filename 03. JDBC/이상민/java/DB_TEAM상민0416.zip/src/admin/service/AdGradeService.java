package admin.service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

import admin.AdminDAO;
import dto.*;

public class AdGradeService implements IAdGradeService {

	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}

	
	
	public static void gradeByCourse() {
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("[과정별 시험 및 성적 관리]");
			
			System.out.println("[진행중인 과정]");
			
			AdminDAO dao = new AdminDAO(); 
			
			ArrayList<VwcouingdateDTO> list = new ArrayList<VwcouingdateDTO>();
			
			list = dao.couIngList();
			
			for(VwcouingdateDTO dto : list) {
				System.out.println(String.format("[%s] %s", dto.getVcouseq(),dto.getVcouname()));
				
			}
			
			dao.close();
			
			System.out.println("[]안의 번호를 입력하세요.");
			System.out.println("입력 :");
			String couseq = scan.nextLine();
			
			if(couseq.equals("0")) {
				loop = false;
			}else {
				AdGradeService.gradeBySubject(couseq);
			}
			
		}
		
		
		
	}



	private static void gradeBySubject(String couseq) {
		boolean loop = true;
		while(loop) {
			
			System.out.println("[과정별 시험 및 성적 관리]");
			
			AdminDAO dao = new AdminDAO(); 
			
			VwcouroomlecDTO coudto = new VwcouroomlecDTO();
			ArrayList<VwcousubDTO> sublist = new ArrayList<VwcousubDTO>();
			coudto = dao.gradeBySubject(couseq);
			sublist = dao.vwcousub(couseq);
			
			System.out.println("과정명" + coudto.getVcouname());
			System.out.println("과정기간" + coudto.getVcoustart()+"~"+coudto.getVcouend());
			System.out.println("강의실명" + coudto.getVroomname());
			System.out.println("교사명"+coudto.getVlecname());
			
			System.out.println("과목명\t\t성적 등록 여부\t시험문제 등록여부");
			
			for(VwcousubDTO dto : sublist) {
				System.out.println(String.format("[%s]\t\t%s\t%s\t%s", dto.getVsubseq(),
																	dto.getVsubname(),
																	subRegist(dto.getVsubseq()),
																	quizRegist(dto.getVsubseq())));
			}
			
					
			System.out.println("번호 입력  subseq 7");
			
			if(scan.nextLine().equals("0")) {
				loop = false;
			}else{
				AdGradeService.graeachStudent(couseq,scan.nextLine());
			}
			
			dao.close();
		}
		
		
		
	}



	private static String quizRegist(String vsubseq) {
		
		AdminDAO dao = new AdminDAO(); 		
		String cnt = dao.cntQuiz(vsubseq);
		
		return cnt;
	}



	private static String subRegist(String vsubseq) {
		
		AdminDAO dao = new AdminDAO(); 		
		String cnt = dao.cntSubRegist(vsubseq);
		
		return cnt;
		
		
	}



	private static void graeachStudent(String couseq,String subseq) {
		
		boolean loop = true;

		while(loop) {
			
			System.out.println("[과정별 시험 및 성적 관리]");
			
			AdminDAO dao = new AdminDAO();
			
			VwsubcouroomlecDTO coudto = new VwsubcouroomlecDTO();
			ArrayList<VwsinfograDTO>sinlist = new ArrayList<VwsinfograDTO>();
			coudto = dao.vwsubcouroomlec(couseq,subseq);
			sinlist = dao.vwsinfogra(couseq,subseq);
			
			System.out.println("[과목 정보]");
			System.out.println("[과목명]"+coudto.getVsubname());
			System.out.println("[과목 기간]"+coudto.getVsubstart()+"~"+coudto.getVsubend());
			System.out.println("[교재명]"+coudto.getVtextname());
			System.out.println("[교사명]"+coudto.getVlecname());
			
			int i=0;
			for(VwsinfograDTO dto : sinlist) {
				i++;
				System.out.println(String.format("교육생%02d", i));
				System.out.println("이름"+dto.getVstuname());
				System.out.println("주민번호 뒷자리"+dto.getVrnum());
				System.out.println("필기"+dto.getVgraprac());
				System.out.println("실기"+dto.getVgraprac());
								
			}
			dao.close();
			
			System.out.println("[0] 돌아가기");
			System.out.println("[] 안의 번호를 입력하세요");
			System.out.print("입력 :");
			String select = scan.nextLine();
			if(select.equals("0")) {
				loop = false;
			}
			
		}
		
		
		
		
		
	}



	public static void gradeByName() {
		
		boolean loop = true;
		{
			System.out.println("[교육생별 시험 및 성적 관리]");
			System.out.println("교육생 이름을 입력해주십시오.");
			System.out.println("입력[한글] :");
			String name = scan.nextLine();
			
			AdminDAO dao = new AdminDAO();
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
			list = dao.studentInfoByName(name);
			
			for(StudentInfoDTO dto : list) {
				System.out.println("번호\t이름\t주민번호 뒷자리\t 전화번호");
				System.out.println(String.format("[%s]\t%s\t%s\t%s", 
							dto.getSeq(),dto.getName(),dto.getRegistrationNum(),
							dto.getPhoneNum()));
				
			}
			
			System.out.println("[]안의 번호를 입력하세요.");
			System.out.print("입력 :");
			String select = scan.nextLine();
			if(select.equals("0")) {
				loop = false;
			}else {
				AdGradeService.subInfo(select);
			}
			
			
		}
		
		
		
	}



	private static void subInfo(String stuinfoseq) {
		boolean loop = true;
		
		while(loop) {
			
			System.out.println("교육생별 시험 및 성적 관리");
			
			AdminDAO dao = new AdminDAO();
			ArrayList<VwstucoutempDTO>tempdtolist = new ArrayList<VwstucoutempDTO>();
			
			tempdtolist=dao.vwstucoutemp(stuinfoseq);
			
			for(VwstucoutempDTO dto : tempdtolist) {
				System.out.println("교육생"+dto.getVsinfoseq());
				System.out.println("주민번호 뒷자리"+dto.getVsturnum());
				System.out.println("과정명"+dto.getVcouname());
				System.out.println("과정기간"+dto.getVcoustart()+"~"+dto.getVcouend());
				System.out.println("강의실"+dto.getVroomname());
				
				ArrayList<VwcousubstutexlecDTO> list = new ArrayList<VwcousubstutexlecDTO>();
				list = dao.vwcousubstutexlec(dto.getVcouseq(),stuinfoseq);
				
				for(VwcousubstutexlecDTO subdto : list) {
					System.out.println("과목"+subdto.getVsubseq());
					System.out.println("과목명"+subdto.getVsubname());
					System.out.println("과목기간"+subdto.getVsubstart()+"~"+subdto.getVsubend());
					System.out.println("교재명"+subdto.getVtextname());
					System.out.println("교사명"+subdto.getVlecname());
					
					
				}
			}
				
				
			
			dao.close();
			
			System.out.println("돌아가기");
			System.out.println("[]안의 번호를 입력하세요.");
			System.out.println("입력 :");
			String subseq = scan.nextLine();
			
			if(subseq.equals("0")) {
				loop=false;
			}else {
				AdGradeService.quizGradPage(stuinfoseq,subseq);
				
			}
			
						
		}
		
		
		
		
	}



	private static void quizGradPage(String stuinfoseq, String subseq) {
		
		boolean loop = true;
		while(loop) {
			AdminDAO dao = new AdminDAO();
			VwsubgraquizDTO dto = dao.vwsubgraquiz(stuinfoseq,subseq);
			
			System.out.println("[과목]"+dto.getVsubseq());
			System.out.println("과목명" + dto.getVsubnanme());
			System.out.println("과목 기간" + dto.getVsubstart()+"~"+dto.getVsubend());
			System.out.println("교재명"+dto.getVtextname());
			System.out.println("교사명"+dto.getVlecturername());
			System.out.println("배점 정보 \t필기배점"+dto.getVsubwrittenpercent()+"\t실기배점"+dto.getVsubpracpercent());
			System.out.println("성적 정보 \t필기"+dto.getVgrawritten()+"\t실기"+dto.getVgrapractical());
			System.out.println("시험 날짜"+dto.getVquizdate());
			
			System.out.println("입력 :");
			String temp = scan.nextLine();
			
			if(scan.nextLine().equals("0")) {
				loop = false;
			}
		}
		
	}

}
