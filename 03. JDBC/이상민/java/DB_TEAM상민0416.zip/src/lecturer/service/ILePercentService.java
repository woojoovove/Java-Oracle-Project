package lecturer.service;

public interface ILePercentService {

	void course();

	void leperquizadd();

	void leperquizdel();

	void leperdateadd();

	void leperdatedel();

	void leperadd();

	void lepermodify();

	void leperdel();

}
