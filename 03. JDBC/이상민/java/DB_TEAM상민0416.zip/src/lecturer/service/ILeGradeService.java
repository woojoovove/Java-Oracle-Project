package lecturer.service;

public interface ILeGradeService {

	void allsubject();

	void student(String nextLine);

	String alleachstudent(String subseq, String nextLine );

	void subject();

	String eachstudent(String subseq, String nextLine);

	void written(String gradeseq);

	void practical(String gradeseq);

	void allstudent(String nextLine);



}
