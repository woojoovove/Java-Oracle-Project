package student.service;

public class StAttendanceViewService implements IStAttendanceViewService {

	@Override
	public void entireAttendanceList() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void monthlyAttendanceList() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dailyAttendanceList() {
		// TODO Auto-generated method stub
		
	}
	
	

}
