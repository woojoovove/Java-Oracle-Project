package lecturer.service;

public class LeAttendanceService implements ILeAttendanceService {

	@Override
	public void course() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void course(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void allview() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void month() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void month(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void viewday() {
		// TODO Auto-generated method stub
		
	}

}
