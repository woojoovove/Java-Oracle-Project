package lecturer.service;
import lecturer.view.LecturerGradeView;
import lecturer.dao.LecturerGradeDAO;
import dto.*;
import java.util.Scanner;
import java.sql.ResultSet;
import java.util.ArrayList;
public class LeGradeService implements ILeGradeService{
	
		
	private static Scanner scan;
	private static LecturerGradeView view;
	
	
	
	public LeGradeService() {
		view = new LecturerGradeView();
		scan = new Scanner(System.in);
		
	}
	
	@Override
	public void allsubject() {
		
//		System.out.println("\t\t\t\t[종강 과목 조회]");
//		
//		LecturerGradeDAO dao = new LecturerGradeDAO();
//		ArrayList<VwcousubstubookDTO> list = dao.Vwcousubstubooklist();
//		
//		int i = 0;
//		for(VwcousubstubookDTO dto : list) {
//			i++;
//			System.out.println(String.format("\t[과목 %s]",dto.getVsubseq()));
//			System.out.printf("\t[과정명] %s\n\t[과정기간()] %s ~ %s\n\t[강의실] %s\n"
//					+"\t[과목명] %s\n\t[과목기간] %s ~ %s\n\t[교재명]%s\n\t[출결배점] %s\n[필기배점] %s\n\t[실기배점]%s\n"
//					,dto.getVcouname(),dto.getVcoustart(),dto.getVcouend(),dto.getVroomname(),
//					dto.getVsubname(),dto.getVsubstart(),dto.getVsubend(),dto.getVbookname(),dto.getVsubatt(),
//					dto.getVsubwrit(),dto.getVsubprac());
//			System.out.println();
//			
//		}  //한페이지에 몇개 나오게 할 지 정할 것. 시간 yy mm dd
//		
//		
//		
//		
//		dao.close();
//		
//		
//		
		
		
		
		
		
		
	}

	@Override
	public void student(String nextLine) {
		
		
		System.out.println("\t\t\t\t[교육생]");
		System.out.println();		
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwsinfoDTO> list = dao.VwsinfoList(nextLine); //과목 seq가 들어가야함.
		
		
		view.title(view.DOUBLELINE);
		System.out.println("\t[교육생번호]\t[이름]\t[전화번호]\t\t[수료,중도탈락]\t[날짜]");
		for(VwsinfoDTO dto : list) {
		view.title(view.LINE);	
			System.out.printf("\t[%s]\t\t%s\t%s\t%s\t\t%s\n",
					dto.getVstuseq(),dto.getVstuname(),dto.getVstupnum(),
					dto.getVstustatus(),dto.getVstatusdate());
					
			
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것,성적이 입력되지 않은 더미 필요.
		view.title(view.DOUBLELINE);
		if(list.size()==0) {
			System.out.println("\t모든 교육생의 성적 정보가 입력되어 있습니다.");
			view.title(view.DOUBLELINE);
		}
		
		
		dao.close();
		
		
	}

	@Override
	public String alleachstudent(String subseq, String nextLine) {
		
		System.out.println("\t\t\t\t[종강 과목 조회]");
		view.title(view.DOUBLELINE);
		LecturerGradeDAO dao = new LecturerGradeDAO();
		VwstugrainfoDTO dto = dao.vwstugrainfolist(subseq,nextLine);
		
		
		System.out.println("\t[교육생번호]\t[이름]\t[필기]\t[실기]");
		view.title(view.LINE);
		System.out.printf("\t[%s]\t\t%s\t%s\t%s\n",
				dto.getVstuseq(),dto.getVstuname(),dto.getVgrawri(),dto.getVgraprac());
	
		System.out.println();
		
		dao.close();
		
		return dto.getVgraseq();
	}

	
	@Override
	public void subject(String lecseq) {
		
		System.out.println("\t\t\t\t[종강 과목 조회]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwcousubstubookDTO> list = dao.Vwcousubstubooklist(lecseq);
		
		int i = 0;
		for(VwcousubstubookDTO dto : list) {
			i++;
			System.out.println(String.format("\t[과목 %s]",dto.getVsubseq()));
			view.title(view.DOUBLELINE);
			System.out.printf("\t[과정명]\t%s\n\t[과정기간()]%s ~ %s\n\t[강의실]\t%s\n"
					+"\t[과목명]\t%s\n\t[과목기간]\t%s ~ %s\n\t[교재명]\t%s\n\t[출결배점]\t%s\n\t[필기배점]\t%s\n\t[실기배점]\t%s\n"
					,dto.getVcouname(),dto.getVcoustart(),dto.getVcouend(),dto.getVroomname(),
					dto.getVsubname(),dto.getVsubstart(),dto.getVsubend(),dto.getVbookname(),dto.getVsubatt(),
					dto.getVsubwrit(),dto.getVsubprac());
			view.title(view.DOUBLELINE);
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것. 시간 yy mm dd
		
		view.pressEnter();		
		
		
		dao.close();
		
		
		
		
	}


	@Override
	public String eachstudent(String courseseq, String studentseq) {
		
		
		System.out.println("\t\t\t\t[성적 입력]");
		
		System.out.println("\t[교육생번호]\t[이름]\t[전화번호]\t\t[수료,중도탈락]\t[날짜]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		VwstugraDTO dto = dao.vwstugralist(courseseq,studentseq);
		
		System.out.printf("\t[%s]\t\t%s\t%s\t\t%s\t%s\n", dto.getVstuseq(),
											dto.getVstuname(),dto.getVstupnum(),
											dto.getVstustatus(),dto.getVstustadate());
		
		dao.close();
		
		
		return dto.getVgraseq();
	}

	@Override
	public void written(String gradeseq) {
		
		insertAttGrade(gradeseq);
		
		view.title(view.DOUBLELINE);
		
		System.out.println("\t필기 점수 입력");
		System.out.println("\t0~100");
		view.title(view.LINE);
		System.out.println("\t 입력 :");
		LecturerGradeDAO dao = new LecturerGradeDAO();
		String score = scan.nextLine();
		dao.grawrittenupdate(gradeseq,score);
		
		dao.close();
	}


	@Override
	public void practical(String gradeseq) {
		
		insertAttGrade(gradeseq);
		
		view.title(view.DOUBLELINE);
		System.out.println("\t실기 점수 입력");
		System.out.println("\t0~100");
		view.title(view.LINE);
		System.out.println("\t 입력 :");
		LecturerGradeDAO dao = new LecturerGradeDAO();
		String score = scan.nextLine();
		dao.grapracticeupdate(gradeseq,score);
		
		dao.close();
		
	}

	private void insertAttGrade(String gradeseq) {
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		dao.Attgrade(gradeseq);
		
		
		dao.close();
		
		
	}
	
	
	
	
	
	
	
	@Override
	public void allstudent(String nextLine) {
		
		
		System.out.println("\t\t\t\t[교육생 선택]");
		view.title(view.DOUBLELINE);		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwstugrainfoDTO> list = dao.VwstugrainfoDTO(nextLine); //과목 seq가 들어가야함.
		
		
		System.out.println("\t[교육생번호]\t[이름]\t[필기]\t[실기]");
		view.title(view.DOUBLELINE);		
		for(VwstugrainfoDTO dto : list) {
			
			view.title(view.LINE);		
			System.out.printf("\t[%s]\t\t%s\t%s\t%s\n",
					dto.getVstuseq(),dto.getVstuname(),dto.getVgrawri(),dto.getVgraprac());
					
			
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것,성적이 입력되지 않은 더미 필요.
		view.title(view.DOUBLELINE);		
		
		
		
		dao.close();
		
		
		
		
	}

	@Override
	public void subject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int alleachstudent(String nextLine) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void written() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void practical() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int eachstudent(String nextLine) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
