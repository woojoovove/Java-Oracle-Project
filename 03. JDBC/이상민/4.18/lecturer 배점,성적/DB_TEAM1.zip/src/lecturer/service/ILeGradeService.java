package lecturer.service;

public interface ILeGradeService {

	void allsubject();

	void student(String nextLine);

	int alleachstudent(String nextLine);

	void written();

	void practical();

	void subject();

	int eachstudent(String nextLine);

	String eachstudent(String courseseq, String studentseq);

	String alleachstudent(String subseq, String nextLine);

	void subject(String lecseq);

	void written(String gradeseq);

	void practical(String gradeseq);

	void allstudent(String nextLine);

}
