package student.service;

public interface IStAttendanceViewService {

	void entireAttendanceView(String studentSeq);

	void subjectAttendanceView(String studentSeq);

}
