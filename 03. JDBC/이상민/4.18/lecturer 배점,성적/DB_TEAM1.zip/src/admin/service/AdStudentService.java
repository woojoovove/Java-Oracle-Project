package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.dao.AdminStudentDAO;
import admin.view.AdminStudentView;
import dto.StudentInfoDTO;
import dto.VwBeforeCouDTO;
import dto.VwDelListDTO;
import dto.VwcoustuDTO;
import dto.VwstucouDTO;

public class AdStudentService implements IAdStudentService {

	private static Scanner scan;
	private static AdminStudentView adminStudentView;
	
	static {
		scan = new Scanner(System.in);
		adminStudentView = new AdminStudentView();
	}
	
//===============================================================================================================================	
	
	public static void studentAdd() {
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("\t\t\t\t[교육생 관리]\n");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t이름을 입력해주십시오");
			System.out.print("\t입력[한글]: ");
			String name =scan.nextLine();
			adminStudentView.title(AdminStudentView.LINE);
			
			System.out.println("\t주민번호 뒷자리를 입력해주십시오");
			System.out.print("\t입력[번호 7자리]: ");
			String rnum =scan.nextLine();
			adminStudentView.title(AdminStudentView.LINE);
			
			System.out.println("\t전화번호를 입력해주십시오");
			System.out.print("\t입력[000-0000-0000]: ");
			String pnum =scan.nextLine();
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			AdminStudentDAO dao = new AdminStudentDAO();
			dao.studentAdd(name,rnum,pnum);
			dao.close();
			
			System.out.println("\t교육생 등록을 완료하였습니다.");
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t[1]교육생 추가 등록");
			System.out.println();
			System.out.println("\t[0]뒤로 가기");
			adminStudentView.title(AdminStudentView.LINE);
			
			adminStudentView.requireSelct();
			String select = scan.nextLine();
			
			if(select.equals("0")) {
				loop = false;
			}else {
				System.out.println("\t교육생을 추가로 등록합니다.");
				adminStudentView.pressEnter();
			}
		}
			
	}//StudentAdd
	
//===============================================================================================================================
	
	public static void searchByName() {
		
		adminStudentView.searchByName();
		
		boolean loop = true;
		while(loop) {
			AdminStudentDAO dao = new AdminStudentDAO();
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
			list = dao.searchByName(scan.nextLine());
			
			System.out.println("\t번호\t이름\t주민번호 뒷자리\t\t전화");
			for(StudentInfoDTO dto : list) {
				adminStudentView.title(AdminStudentView.LINE);
				System.out.println(String.format("\t[%s]\t%s\t%s\t%s", 
						dto.getSeq(),dto.getName(),dto.getRegistrationNum(),dto.getPhoneNum()));
				
			}
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t[0] 뒤로가기");
			adminStudentView.title(AdminStudentView.LINE);
			adminStudentView.requireSelct();
			
			String select = scan.nextLine();
			if(select.equals("0")) {
				dao.close();
				loop = false;
			}else {
				System.out.println("\t'"+select+"' 교육생의 상세 정보로 이동합니다.");
				adminStudentView.pressEnter();
				dao.close();
				AdStudentService.selectedstudentinfo(select);
			}
			
		}
		
	}
	
//===============================================================================================================================
	
	private static void selectedstudentinfo(String nextLine) {
		boolean loop = true;
		
		while(loop) {

			System.out.println("\t\t\t\t[교육생 상세 정보 확인]");
			System.out.println();
			
			
			AdminStudentDAO dao = new AdminStudentDAO();
			StudentInfoDTO studto = new StudentInfoDTO();
			studto = dao.studentInfoBySeq(nextLine);
			
			VwstucouDTO coudto = new VwstucouDTO();
			coudto = dao.courseInfo(nextLine);
			
			System.out.println("\t[기본사항]");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t번호\t이름\t주민번호\t\t전화번호\t\t\t등록일");
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println(String.format("\t[%s]\t%s\t%s\t\t%s\t\t%s", 
					studto.getSeq(),studto.getName(),studto.getRegistrationNum()
					,studto.getPhoneNum(),studto.getRegistrationDate()));
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println();
			System.out.println("\t[과정 정보]");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t등록 과정 명 \t"+coudto.getVcouname());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정 시작 날짜 \t"+coudto.getVcoustart());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정 종료 날짜 \t"+coudto.getVcouend());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정별 재적 상태\t"+coudto.getVstustatus());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			dao.close();
			System.out.println("\t[1] 교육생 정보 수정");
			System.out.println("\t[2] 교육생 삭제");
			System.out.println("\t[0] 뒤로 가기");
			adminStudentView.title(AdminStudentView.LINE);
			
			adminStudentView.requireSelct();
			String select = scan.nextLine();
			
			if(select.equals("0")) {
				loop =false;
			}else if(select.equals("1")) {
				AdStudentService.stuInfoModify(coudto);
				
			}else if(select.equals("2")) {
				AdStudentService.stuInfoDelete(coudto);
				
			}else {
				System.out.println("\t\t\t\t다시 입력해주세요.");
			}
				
		}
			
	}
	
//===============================================================================================================================
	
	private static void stuInfoDelete(VwstucouDTO coudto) {
		
		System.out.println("\t"+coudto.getVstuname()+" 교육생의 정보를 삭제합니다");
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.studentinfoDelete(coudto.getVstuinseq());
		dao.close();
		
		adminStudentView.pressEnter();
	}
	
//===============================================================================================================================
	
	private static void stuInfoModify(VwstucouDTO coudto) {
		boolean loop = true;
		while(loop) {
			
			AdStudentService.coudtoinfo(coudto);
								
			System.out.println("\t수정하고 싶은 항목을 선택해주십시오");
			System.out.println("\t[1] 이름 수정");
			System.out.println("\t[2] 주민번호 뒷자리 수정");
			System.out.println("\t[3] 전화번호 수정");
			System.out.println("\t[4] 등록일 수정");
			System.out.println("\t[5] 등록 과정 관리");
			System.out.println("\t[6] 수료/중도탈락 관리");
			System.out.println();
			System.out.println("\t[0] 뒤로 가기");
			adminStudentView.title(AdminStudentView.LINE);
			adminStudentView.requireSelct();
			adminStudentView.title(AdminStudentView.LINE);
			String select = scan.nextLine();
			switch(select) {
			
			case "1" : AdStudentService.stuInfoMoName(coudto);
			System.out.println("\t[1] 이름 수정");
			adminStudentView.pressEnter();
			break; 
			case "2" : AdStudentService.stuInfoMoRnum(coudto);
			System.out.println("\t[2] 주민번호 뒷자리 수정");
			adminStudentView.pressEnter();
			break; 
			case "3" : AdStudentService.stuInfoMoPnum(coudto);
			System.out.println("\t[3] 전화번호 수정");
			adminStudentView.pressEnter();
			break; 
			case "4" : AdStudentService.stuInfoMoRdate(coudto);
			System.out.println("\t[4] 등록일 수정");
			adminStudentView.pressEnter();
			break; 
			case "5" : AdStudentService.stuInfoMoCourse(coudto);
			System.out.println("\t[5] 등록 과정 관리");
			adminStudentView.pressEnter();
			break; 
			case "6" : AdStudentService.stuInfoMoStatus(coudto);
			System.out.println("\t[6] 수료/중도탈락 관리");
			adminStudentView.pressEnter();
			break; 
			case "0" : loop = false; break; 
			default : System.out.println("\t잘못된 입력입니다."); break;	
			
			}

		}

	}
	
//===============================================================================================================================
	
	private static void coudtoinfo(VwstucouDTO coudto) {
		
		System.out.println("\t[기본사항]");
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		System.out.println("\t번호\t이름\t주민번호\t전화번호\t\t등록일");
		adminStudentView.title(AdminStudentView.LINE);
		System.out.println(String.format("\t[%s]\t%s\t%s\t%s\t\t%s", 
				coudto.getVstuinseq(), coudto.getVstuname(),coudto.getVsturnum()
				,coudto.getVstupnum(),coudto.getVstuinrdate()));
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		
		System.out.println("\t[과정 정보]");
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		System.out.println("\t등록 과정 명 \t"+coudto.getVcouname());
		adminStudentView.title(AdminStudentView.LINE);
		System.out.println("\t과정 시작 날짜 \t"+coudto.getVcoustart());
		adminStudentView.title(AdminStudentView.LINE);
		System.out.println("\t과정 종료 날짜 \t"+coudto.getVcouend());
		adminStudentView.title(AdminStudentView.LINE);
		System.out.println("\t과정별 재적 상태\t"+coudto.getVstustatus());
		adminStudentView.title(AdminStudentView.LINE);
		System.out.println("\t수료/중도 탈락 날짜 \t"+coudto.getVstustatusdate());
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoCourse(VwstucouDTO coudto) {
		
		boolean loop = true;
		
		while(loop) {
		
			AdStudentService.coudtoinfo(coudto);
			
			System.out.println("\t원하시는 작업을 선택해주십시오.");
			System.out.println("\t[1] 과정 추가");
			System.out.println("\t[2] 과정 삭제");
			System.out.println("\t[3] 과정별 제적 상태 관리");
			System.out.println("\t[0] 돌아가기");
			adminStudentView.title(AdminStudentView.LINE);
			adminStudentView.requireSelct();
			adminStudentView.title(AdminStudentView.LINE);
			
			switch(scan.nextLine()) {
			
			case "1" : stuInfoCourseAdd(coudto);	break;
			case "2" : stuInfoCourseDel(coudto);	break;
			case "0" : 	loop = false;break;
			default : System.out.println("잘못된 입력입니다."); break;
			}
		}
		
	}
	
//===============================================================================================================================
	
	@SuppressWarnings("unused")
	private static void stuInfoCourseManage(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
	}
	
//===============================================================================================================================
	
	private static void stuInfoCourseDel(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		AdminStudentDAO dao = new AdminStudentDAO();
		
		ArrayList<VwDelListDTO> list = new ArrayList<VwDelListDTO>();
		list = dao.vwDelList(coudto);
		
		System.out.println("\t[과정 목록]");
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		System.out.println("\t[과정번호]\t과정명\t과정시작날짜~과정 종료날짜");
		
		for(VwDelListDTO dto : list) {
			System.out.println(String.format("\t[%s]\t%s\t%s~%s", dto.getVcouseq(),
										dto.getVcouname(),dto.getVcoustart(),dto.getVcouend()));
			adminStudentView.title(AdminStudentView.LINE);
			
			
		}
		
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		adminStudentView.requireSelct();
		String select = scan.nextLine();
		dao.stuInfoCourseDel(coudto,select);	
		dao.close();
		adminStudentView.pressEnter();
		
	}
	
//===============================================================================================================================
	
	private static void stuInfoCourseAdd(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
		AdminStudentDAO dao = new AdminStudentDAO();
		
		ArrayList<VwBeforeCouDTO>list =  dao.vwbeforecou();
		System.out.println("[\t과정 목록]");
		
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		System.out.println("\t[과정번호]\t과정명");
		
		for(VwBeforeCouDTO dto : list) {
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println(String.format("\t[%s]\t%s", dto.getVcouseq(),dto.getVcouname()));
			
		}
		adminStudentView.title(AdminStudentView.DOUBLELINE);
		adminStudentView.requireSelct();
		String select = scan.nextLine();
		dao.stuInfoCourseAdd(coudto,select);	
		dao.close();
		
		adminStudentView.pressEnter();
			
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoStatus(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
		
		System.out.println("\t수료로 변경[1]입력");
		System.out.println("\t중도탈락으로 변경[2]입력");
		System.out.println();
		adminStudentView.requireSelct();
//		view.title(view.LINE);
		String select = scan.nextLine();
//		System.out.print("\t수료처리할/중도탈락처리할 날짜를 입력하십시오.");
//		System.out.println("\t새 등록일(0000-00-00)");//SYSDATE 안돼나
		System.out.println();
		adminStudentView.title(AdminStudentView.LINE);
		String sysdate = "sysdate";
//		String date = scan.nextLine();
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.modifyStatus(select,sysdate,coudto);
		dao.close();
		
		
		adminStudentView.title(AdminStudentView.LINE);
//		System.out.println("\t"+date+"부로 수료처리/중도탈락처리 완료");
		System.out.println();
		System.out.println("\t 이전 화면으로 돌아갑니다.");
		adminStudentView.pressEnter();
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoRdate(VwstucouDTO coudto) {
		
		
		AdStudentService.coudtoinfo(coudto);
		
		System.out.println("\t새 등록일을 입력해주십시오.");
		System.out.print("\t새 등록일(0000-00-00)");
		System.out.println();
		adminStudentView.title(AdminStudentView.LINE);
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.modifyRdate(coudto,scan.nextLine()); //날짜 어쩔까?
		
		dao.close();
		System.out.println("\t등록일 수정 완료");
		System.out.println("\t 이전 화면으로 돌아갑니다.");
		adminStudentView.pressEnter();
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoPnum(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
		System.out.println("\t새 전화번호를 입력해주십시오.");
		System.out.print("\t새 전화번호(000-0000-0000)");
		System.out.println();
		adminStudentView.title(AdminStudentView.LINE);
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.modifyPnum(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("\t전화번호 수정 완료");
		System.out.println("\t 이전 화면으로 돌아갑니다.");
		adminStudentView.pressEnter();
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoRnum(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
		System.out.println("\t새 주민번호 뒷자리를 입력해주십시오.");
		System.out.print("\t새 주민번호 뒷자리");
		System.out.println();
		adminStudentView.title(AdminStudentView.LINE);
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.modifyRnum(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("\t주민번호 수정 완료");
		System.out.println("\t이전 화면으로 돌아갑니다.");
		
		adminStudentView.pressEnter();
	}
	
//===============================================================================================================================
	
	private static void stuInfoMoName(VwstucouDTO coudto) {
		
		AdStudentService.coudtoinfo(coudto);
		
		System.out.println("\t새 이름을 입력해주십시오.");
		System.out.println();
		System.out.print("\t새 이름 :");
		System.out.println();
		adminStudentView.title(AdminStudentView.LINE);
		
		AdminStudentDAO dao = new AdminStudentDAO();
		dao.modifyName(coudto,scan.nextLine());
		
		dao.close();
		System.out.println("\t이름 수정 완료");
		System.out.println("\t이전 화면으로 돌아갑니다.");
		
		adminStudentView.pressEnter();
			
	}
	
//===============================================================================================================================
	
	public static void searchByCourse() {
		
		boolean loop = true;
		while(loop) {
			System.out.println("\t\t\t\t[과정명으로 교육생 검색]");
			System.out.println();
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			AdminStudentDAO dao = new AdminStudentDAO();
			ArrayList<VwcoustuDTO>list = dao.vwCouStu();
			
			System.out.println("\t[과정번호]\t과정명");
			
			for(VwcoustuDTO dto : list) {
				adminStudentView.title(AdminStudentView.LINE);
				System.out.println(String.format("\t[%s]\t%s", dto.getVseq(),dto.getVname()));
			}
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			adminStudentView.requireSelct();
			
			adminStudentView.title(AdminStudentView.LINE);
			
			String select = scan.nextLine();
			
			if(select.equals("0")) {
				loop=false;
			}else {
				AdStudentService.selCouStuInfo(select); //과정번호
			}			
			dao.close();
			
		}
	
	}
	
//===============================================================================================================================
	
	private static void selCouStuInfo(String nextLine) { //과정번호
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("\t\t\t\t[과정명으로 교육생 검색]");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t해당 과정을 수강하는 교육생들의 명단은 아래와 같습니다.");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			
			AdminStudentDAO dao = new AdminStudentDAO();
			ArrayList<VwstucouDTO>list = dao.selCouStuList(nextLine);
			
			System.out.println("\t번호\t이름\t주민번호 뒷자리\t\t전화번호");
			for(VwstucouDTO dto : list) {
				adminStudentView.title(AdminStudentView.LINE);
				System.out.println(String.format("\t[%s]\t%s\t%s\t\t%s",dto.getVstuinseq(),
						dto.getVstuname(),dto.getVsturnum(),dto.getVstupnum()));
				
			}
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			dao.close();
			System.out.println("\t[0] 뒤로가기");
			
			adminStudentView.requireSelct();
			adminStudentView.title(AdminStudentView.LINE);
			
			String select = scan.nextLine();
			
			if(select.equals("0")) {
				loop = false;
			}else {
				
				adminStudentView.pressEnter();
				selCouStueachInfo(select);
				
			}
			
		}
	
	}
	
//===============================================================================================================================
	
	private static void selCouStueachInfo(String nextLine) { //stuinfoseq
		
		boolean loop = true;
		AdminStudentDAO dao = new AdminStudentDAO();
		VwstucouDTO dto = new VwstucouDTO();
		dto = dao.courseInfo(nextLine);
		
		while(loop) {
			System.out.println("\t\t\t\t[교육생 상세 정보 확인]");
			System.out.println();
			System.out.println("\t[기본사항]");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t번호\t이름\t\t주민번호\t전화번호\t\t등록일");
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println(String.format("\t[%s]\t%s\t\t%s\t%s\t%s", 
					dto.getVstuinseq(),dto.getVstuname(),dto.getVsturnum()
					,dto.getVstupnum(),dto.getVstuinrdate()));
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			System.out.println("\t[과정 정보]");
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			System.out.println("\t등록 과정 명 \t"+dto.getVcouname());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정 시작 날짜 \t"+dto.getVcoustart());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정 종료 날짜 \t"+dto.getVcouend());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t과정별 재적 상태\t"+dto.getVstustatus());
			adminStudentView.title(AdminStudentView.LINE);
			System.out.println("\t수료/중도 탈락 날짜 \t"+dto.getVstustatusdate());
			adminStudentView.title(AdminStudentView.DOUBLELINE);
			
			System.out.println("\t[1] 교육생 정보 수정");
			System.out.println("\t[2] 교육생 삭제");
			System.out.println("\t[0] 뒤로 가기");
			adminStudentView.title(AdminStudentView.LINE);
			adminStudentView.requireSelct();
			adminStudentView.title(AdminStudentView.LINE);
			
			String select = scan.nextLine();
			if(select.equals("0")) {
				loop =false;
			}else if(select.equals("1")) {
				
				System.out.println("\t교육생 정보 수정 메뉴로 이동합니다.");
				
				adminStudentView.pressEnter();
				AdStudentService.stuInfoModify(dto);
				
			}else if(select.equals("2")) {
				
				System.out.println("\t교육생 삭제 메뉴로 이동합니다.");
				
				adminStudentView.pressEnter();
				AdStudentService.stuInfoDelete(dto);
				
			}else {
				System.out.println("\t다시 입력해주세요.");
			}
				
		}
		
		dao.close();
		
	}

}//class
