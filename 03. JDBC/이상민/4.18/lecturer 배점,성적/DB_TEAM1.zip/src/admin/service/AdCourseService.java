package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.dao.AdministratorCourseDAO;
import admin.view.AdministratorCourseView;
import dto.CourseDTO;
import dto.SubjectDTO;
import util.Cls;

public class AdCourseService implements IAdCourseService {

	private static AdministratorCourseView administratorView;
	private static AdministratorCourseDAO adminCourseDAO;
	private static Scanner scan;
	
	static {
		administratorView = new AdministratorCourseView();
		adminCourseDAO = new AdministratorCourseDAO();
		scan = new Scanner(System.in);
	}
	
	
	
//과정 추가	
//===================================================================================================================================
	
	@Override
	public void courseAdd() {
		
		Cls.clearScreen();
				
		//과정명 선택
		administratorView.title(AdministratorCourseView.ADDCOURSENAME);
		
		ArrayList<String> courseNameList = adminCourseDAO.courseNameList();
		
		for (int i=0; i<courseNameList.size(); i++) {
			
			System.out.println(courseNameList.get(i));		
			if (i != courseNameList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String courseNameSeq = administratorView.addCourseName01();	
		String courseName = adminCourseDAO.selectCourseName(courseNameSeq);
		administratorView.addCourseName02(courseName);
		
		Cls.clearScreen();

	//-----------------------------------------------------------------------------------------------		
		
		//과정 기간 입력
		administratorView.title(AdministratorCourseView.ADDCOURSEDATE);
		
		System.out.println();
		System.out.print("\t과정 시작일(0000-00-00) : ");
		String startDate = scan.nextLine();
		
		System.out.println();
		System.out.print("\t과정 종료일(0000-00-00) : ");
		String endDate = scan.nextLine();
				
		administratorView.addCourseDate(startDate, endDate);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------
		
		//강의실 선택
		administratorView.title(AdministratorCourseView.ADDCOURSECLASSROOM);
		
		ArrayList<String> classroomList = adminCourseDAO.classroomList();
		
		for (int i=0; i<classroomList.size(); i++) {
			
			System.out.println(classroomList.get(i));		
			if (i != classroomList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String classroomSeq = administratorView.addCourseClassroom01();
		administratorView.addCourseClassroom02(classroomSeq);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------
		
		//교사 선택
		administratorView.title(AdministratorCourseView.ADDCOURSELECTURER);
		
		ArrayList<String> lecturerList = adminCourseDAO.lecturerList();
		
		for (int i=0; i<lecturerList.size(); i++) {
			
			System.out.println(lecturerList.get(i));		
			if (i != lecturerList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String lecturerSeq = administratorView.addLecturer01();
		String lecturerName = adminCourseDAO.selectLecturer(lecturerSeq);
		administratorView.addLecturer02(lecturerName);
		
		Cls.clearScreen();
		
	//-----------------------------------------------------------------------------------------------

		//추가 작업 : INSERT
		CourseDTO courseDto = new CourseDTO();
		courseDto.setStartDate(startDate);
		courseDto.setEndDate(endDate);
		courseDto.setCourseNameSeq(courseNameSeq);
		courseDto.setClassroomSeq(classroomSeq);
		courseDto.setLecturerSeq(lecturerSeq);

		int result = adminCourseDAO.courseAdd(courseDto);
		
		if (result == 1) {
			administratorView.courseAddFinish();
		} else {
			System.out.println("실패하였습니다");
		}
		
	}//Method : courseAdd

//===================================================================================================================================

	

//과정 수정	
//===================================================================================================================================	
	
	@Override
	public void courseEdit() {
		
		boolean courseEditLoop = true;
		
		while (courseEditLoop) {
			
			Cls.clearScreen();
					
			//수정할 과정 선택
			administratorView.title(AdministratorCourseView.EDITCOURSE);
			
			ArrayList<String> courseEditList = adminCourseDAO.courseEdit();
			
			for (int i=0; i<courseEditList.size(); i++) {
				System.out.println(courseEditList.get(i));			
			}
			
			String oldCourseNameSeq = administratorView.courseEdit01();
			
			if (!oldCourseNameSeq.equals("0")) {
				
				String courseName = adminCourseDAO.selectCourseEdit(oldCourseNameSeq);
				administratorView.courseEdit02(courseName);
								
	//-----------------------------------------------------------------------------------------------		

				//수정할 요소 선택
				
				boolean courseEditElementLoop = true;
				
				while (courseEditElementLoop) {
					
					Cls.clearScreen();
					
					administratorView.title(AdministratorCourseView.EDITCOURSEELEMENT);
					
					ArrayList<String> editCourseType = adminCourseDAO.editCourseType(oldCourseNameSeq);
					
					for (int i=0; i<editCourseType.size(); i++) {
						System.out.println(editCourseType.get(i));			
					}
					
					String editElement = administratorView.courseEditElement();
					
	//-----------------------------------------------------------------------------------------------
							
					if (editElement.equals("1")) {
						
						Cls.clearScreen();
						
						//과정명 수정 - 새 과정명 선택
						administratorView.title(AdministratorCourseView.EDITCOURSENAME);						
						String oldCourseName = adminCourseDAO.oldCourseName(oldCourseNameSeq);
						System.out.println("\t기존 과정명 : " + oldCourseName);
						administratorView.thickLine();
						
						ArrayList<String> courseNameList = adminCourseDAO.courseNameList();
						
						for (int i=0; i<courseNameList.size(); i++) {
							
							System.out.println(courseNameList.get(i));		
							if (i != courseNameList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newCourseNameSeq = administratorView.editCourseName01();	
						String newCourseName = adminCourseDAO.selectCourseName(newCourseNameSeq);						
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setCourseNameSeq(newCourseNameSeq);

						int result = adminCourseDAO.editCourseName(courseDto);
						
						if (result == 1) {
							administratorView.editCourseName02(newCourseName);
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("2")) {
						
						Cls.clearScreen();
						
						//과정기간 수정 - 기존 과정기간
						administratorView.title(AdministratorCourseView.EDITCOURSEDATE);						
						String oldCourseDate = adminCourseDAO.oldCourseDate(oldCourseNameSeq);
						System.out.println("\t기존 과정기간 : " + oldCourseDate);
						administratorView.thickLine();					
						
						
						//UPDATE 작업
						System.out.println();
						System.out.print("\t과정 시작일(0000-00-00) : ");
						String startDate = scan.nextLine();
						
						System.out.println();
						System.out.print("\t과정 종료일(0000-00-00) : ");
						String endDate = scan.nextLine();

						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setStartDate(startDate);
						courseDto.setEndDate(endDate);
						
						int result = adminCourseDAO.editCourseDate(courseDto);
						
						if (result == 1) {
							administratorView.editCourseDate();
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("3")) {
						
						Cls.clearScreen();
						
						//강의실 수정 - 기존 강의실
						administratorView.title(AdministratorCourseView.EDITCOURSECLASSROOM);						
						String oldCourseClassroom = adminCourseDAO.oldCourseClassroom(oldCourseNameSeq);
						System.out.println("\t기존 강의실 : " + oldCourseClassroom);
						administratorView.thickLine();	
						administratorView.editCourseClassroom01();	
						
						ArrayList<String> classroomList = adminCourseDAO.classroomList();
						
						for (int i=0; i<classroomList.size(); i++) {
							
							System.out.println(classroomList.get(i));		
							if (i != classroomList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newClassroomSeq = administratorView.addCourseClassroom01();												
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setCourseNameSeq(newClassroomSeq);

						int result = adminCourseDAO.editCourseClassroom(courseDto);
						
						if (result == 1) {
							administratorView.editCourseClassroom02(newClassroomSeq);
						} else {
							System.out.println("실패하였습니다");
						}
						
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("4")) {
						
						Cls.clearScreen();
						
						//교사 수정 - 기존 교사
						administratorView.title(AdministratorCourseView.EDITCOURSELECTURER);						
						String oldCourseLecturer = adminCourseDAO.oldCourseLecturer(oldCourseNameSeq);
						System.out.println("\t기존 교사 : " + oldCourseLecturer);
						administratorView.thickLine();	
						administratorView.editCourseLecturer01();
						
						ArrayList<String> lecturerList = adminCourseDAO.lecturerList();
						
						for (int i=0; i<lecturerList.size(); i++) {
							
							System.out.println(lecturerList.get(i));		
							if (i != lecturerList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newLecturerSeq = administratorView.addLecturer01();
						String lecturerName = adminCourseDAO.selectLecturer(newLecturerSeq);
						
						//UPDATE 작업
						CourseDTO courseDto = new CourseDTO();
						courseDto.setSeq(oldCourseNameSeq);
						courseDto.setLecturerSeq(newLecturerSeq);;

						int result = adminCourseDAO.editCourseLecturer(courseDto);
						
						if (result == 1) {
							administratorView.editCourseLecturer02(lecturerName);
						} else {
							System.out.println("실패하였습니다");
						}
											
					} else if (editElement.equals("0")) courseEditElementLoop = false;					
								
				}//while : courseEditElementLoop
								
			} else if (oldCourseNameSeq.equals("0")) courseEditLoop = false;	
			
		}//while : courseEditLoop
				
	}//method : courseEdit	
		
//===================================================================================================================================


	
//과정 삭제
//===================================================================================================================================	

	@Override
	public void courseDelete() {
		
		boolean courseDeleteLoop = true;
		
		while (courseDeleteLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorCourseView.DELTETECOURSE);
			
			ArrayList<String> courseEditList = adminCourseDAO.courseEdit();
			
			for (int i=0; i<courseEditList.size(); i++) {
				System.out.println(courseEditList.get(i));			
			}
			
			String deleteCourseSeq = administratorView.courseDelete();
			
			if (!deleteCourseSeq.equals("0")) {
				
				String deleteCourseName = adminCourseDAO.selectCourseName(deleteCourseSeq);	
				
				//DELETE 작업
				CourseDTO courseDto = new CourseDTO();
				courseDto.setSeq(deleteCourseSeq);

				int result = adminCourseDAO.courseDelete(courseDto);
				
				if (result == 1) {
					administratorView.courseDeleteFinish(deleteCourseName);
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (deleteCourseSeq.equals("0")) courseDeleteLoop = false;
			
		}//while : courseDeleteLoop
		
	}//method : courseDelete
	
//===================================================================================================================================



//과정 목록	
//===================================================================================================================================
	
	@Override
	public void courseList() {
		
		boolean courseListLoop = true;
		
		while (courseListLoop) {
			
			Cls.clearScreen();
			
			//개설 과정 리스트
			administratorView.title(AdministratorCourseView.COURSELIST);
			
			ArrayList<String> courseList = adminCourseDAO.courseList();
			
			for (int i=0; i<courseList.size(); i++) {
				System.out.println(courseList.get(i));			
			}
			
			String courseSeq = administratorView.courseList01();
			
			if (!courseSeq.equals("0")) {
				
				String courseName = adminCourseDAO.selectCourseListName(courseSeq);	
				String courseLecturer = adminCourseDAO.selectCourseLecturer(courseSeq);
				administratorView.courseList02(courseName);
								
	//-------------------------------------------------------------------------------
				
				//과목 관리 메뉴			
				boolean subjectManagementLoop = true;
				
				while (subjectManagementLoop) {
					
					Cls.clearScreen();
					
					administratorView.title(AdministratorCourseView.COURSELIST);
					
					ArrayList<String> selectCourseListInfo = adminCourseDAO.selectCourseListInfo(courseSeq);
					
					for (int i=0; i<selectCourseListInfo.size(); i++) {
						System.out.println(selectCourseListInfo.get(i));			
					}
					
					String subjectElement = administratorView.courseManagementMenu();
					
					if (!subjectElement.equals("0")) {
											
						if (subjectElement.equals("1")) 		subjectList(courseSeq);
						
						else if (subjectElement.equals("2")) 	subjectAdd(courseSeq, courseLecturer);
						
						else if (subjectElement.equals("3")) 	subjectEdit(courseSeq, courseLecturer);
						
						else if (subjectElement.equals("4")) 	subjectDelete(courseSeq);
						
						else if (subjectElement.equals("5")) 	courseStudentList(courseSeq);			
						
					} else if (subjectElement.equals("0")) subjectManagementLoop = false;
					
				}//while : subjectManagementLoop
								
			} else if (courseSeq.equals("0")) courseListLoop = false;
						
		}//while : courseListLoop
		
	}//Method ; courseList

//===================================================================================================================================	

	
	
//과목 추가	
//===================================================================================================================================	
	
	@Override
	public void subjectAdd(String courseSeq, String courseLecturer) {
					
		//과목명 선택
		Cls.clearScreen();
		administratorView.title(AdministratorCourseView.ADDSUBJECTNAME);		
		administratorView.addSubjectName01(courseLecturer);
		
		ArrayList<String> subjectNameList = adminCourseDAO.subjectNameList(courseLecturer);
		
		for (int i=0; i<subjectNameList.size(); i++) {
			
			System.out.println(subjectNameList.get(i));		
			if (i != subjectNameList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String subjectNameSeq = administratorView.addSubjectName02();	
		String subjectName = adminCourseDAO.selectSubjectName(subjectNameSeq);
		administratorView.addSubjectName03(subjectName);
			
	//-----------------------------------------------------------------------------------------------
			
		//과목 기간 입력
		Cls.clearScreen();			
		administratorView.title(AdministratorCourseView.ADDSUBJECTDATE);
		
		System.out.println();
		System.out.print("\t과목 시작일(0000-00-00) : ");
		String startDate = scan.nextLine();
		
		System.out.println();
		System.out.print("\t과목 종료일(0000-00-00) : ");
		String endDate = scan.nextLine();
				
		administratorView.addSubjectDate(startDate, endDate);
		
	//-----------------------------------------------------------------------------------------------
		
		//교재 선택
		Cls.clearScreen();
		administratorView.title(AdministratorCourseView.ADDSUBJECTTEXTBOOK);
		
		ArrayList<String> subjectTextbookList = adminCourseDAO.subjectTextbookList();
		
		for (int i=0; i<subjectTextbookList.size(); i++) {
			
			System.out.println(subjectTextbookList.get(i));		
			if (i != subjectTextbookList.size() - 1) {
				administratorView.thinLine();
			}		
			
		}
		
		String subjectTextbookSeq = administratorView.addSubjectTextbook01();	
		String subjectTextbookName = adminCourseDAO.subjectTextbookName(subjectTextbookSeq);
		administratorView.addSubjectTextbook02(subjectTextbookName);
		
		
	//-----------------------------------------------------------------------------------------------
		
		//INSERT문 실행
		SubjectDTO subjectDTO = new SubjectDTO();
		subjectDTO.setStartDate(startDate);
		subjectDTO.setEndDate(endDate);
		subjectDTO.setSubjectNameSeq(subjectNameSeq);
		subjectDTO.setCourseSeq(courseSeq);
		subjectDTO.setTextbookSeq(subjectTextbookSeq);

		int result = adminCourseDAO.subjectAdd(subjectDTO);
		
		if (result == 1) {
			administratorView.subjectAddFinish();
		} else {
			System.out.println("실패하였습니다");
		}
		
	}//method : subjectAdd

//===================================================================================================================================

	
	
//과목 정보
//===================================================================================================================================

	@Override
	public void subjectList(String courseSeq) {
		
		boolean subjectListLoop = true;
		
		while (subjectListLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorCourseView.SUBJECTLIST);
			
			ArrayList<String> subjectList = adminCourseDAO.subjectList(courseSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));			
			}
			
			String select = administratorView.subjectList();
			
			if (!select.equals("0")) {
				
				continue;
				
			} else if(select.equals("0")) subjectListLoop = false;
			
		}//while : subjectListLoop
				
	}//method : subjectList

//===================================================================================================================================
	
	
	
//과목 수정
//===================================================================================================================================

	@Override
	public void subjectEdit(String courseSeq, String courseLecturer) {
		
		boolean subjectEditLoop = true;
		
		while (subjectEditLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorCourseView.EDITSUBJECT);
			
			ArrayList<String> subjectList = adminCourseDAO.subjectList(courseSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));			
			}
			
			String subjectSeq = administratorView.editSubjectStart01();
			
			if (!subjectSeq.equals("0")) {
				
				String subjectName = adminCourseDAO.selectEditSubjectName(subjectSeq);
				administratorView.editSubjectStart02(subjectName);
				
	//-----------------------------------------------------------------------------------------------		

				//수정할 요소 선택

				boolean subjectEditElementLoop = true;
				
				while (subjectEditElementLoop) {
					
					Cls.clearScreen();
					
					administratorView.title(AdministratorCourseView.EDITSUBJECTELEMENT);
					
					ArrayList<String> editSubjectType = adminCourseDAO.editSubjectType(courseSeq, subjectSeq);
					
					for (int i=0; i<editSubjectType.size(); i++) {
						System.out.println(editSubjectType.get(i));			
					}
					
					String editElement = administratorView.subjectEditElement();	
					
	//-----------------------------------------------------------------------------------------------
					
					if (editElement.equals("1")) {

						//과목명 수정 - 새 과목명 선택
						Cls.clearScreen();
						administratorView.title(AdministratorCourseView.EDITSUBJECTNAME);
						
						String oldSubjectName = adminCourseDAO.oldSubjectName(courseSeq, subjectSeq);					
						System.out.println("\t현재 과목명\t" + oldSubjectName);
						administratorView.thickLine();
						
						administratorView.editSubjectName01(courseLecturer);
												
						ArrayList<String> subjectNameList = adminCourseDAO.subjectNameList(courseLecturer);
						
						for (int i=0; i<subjectNameList.size(); i++) {
							
							System.out.println(subjectNameList.get(i));		
							if (i != subjectNameList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newSubjectNameSeq = administratorView.editSubjectName02();	
						String newSubjectName = adminCourseDAO.selectSubjectName(newSubjectNameSeq);
						administratorView.editSubjectName03(newSubjectName);
						
						
						//UPDATE 작업
						SubjectDTO subjectDTO = new SubjectDTO();
						subjectDTO.setSeq(subjectSeq); //개설 과목 번호
						subjectDTO.setSubjectNameSeq(newSubjectNameSeq); //새로운 과목명 번호

						int result = adminCourseDAO.editSubjectName(subjectDTO);
						
						if (result == 1) {
							administratorView.editSubjectName04(newSubjectName);
						} else {
							System.out.println("실패하였습니다");
						}
				
	//-----------------------------------------------------------------------------------------------	
						
					} else if (editElement.equals("2")) {

						//과목기간 수정 - 새 과목기간 입력
						Cls.clearScreen();
						administratorView.title(AdministratorCourseView.EDITSUBJECTDATE);
						
						String oldSubjectDate = adminCourseDAO.oldSubjectDate(courseSeq, subjectSeq);
						System.out.println("\t현재 과정기간 : " + oldSubjectDate);
						administratorView.thickLine();					
						
						System.out.println();
						System.out.print("\t과목 시작일(0000-00-00) : ");
						String startDate = scan.nextLine();
						
						System.out.println();
						System.out.print("\t과목 종료일(0000-00-00) : ");
						String endDate = scan.nextLine();

						
						//UPDATE 작업
						SubjectDTO subjectDTO = new SubjectDTO();
						subjectDTO.setSeq(subjectSeq); //개설 과목 번호
						subjectDTO.setStartDate(startDate); //새로운 시작날짜
						subjectDTO.setEndDate(endDate); //새로운 종료날짜

						int result = adminCourseDAO.editSubjectDate(subjectDTO);
						
						if (result == 1) {
							administratorView.editSubjectDate(startDate, endDate);
						} else {
							System.out.println("실패하였습니다");
						}
												
	//-----------------------------------------------------------------------------------------------
						
					} else if (editElement.equals("3")) {
						
						Cls.clearScreen();
						
						//교재 수정 - 새 교재 선택
						administratorView.title(AdministratorCourseView.EDITSUBJECTTEXTBOOK);
						
						String oldSubjectTextbookName = adminCourseDAO.oldSubjectTextbookName(courseSeq, subjectSeq);
						String oldSubjectPublisherName = adminCourseDAO.oldSubjectPublisherName(courseSeq, subjectSeq);
						
						System.out.println("\t현재 교재명\t" + oldSubjectTextbookName);
						System.out.println("\t출판사\t\t" + oldSubjectPublisherName);
						
						administratorView.editSubjectTextbook01();

						ArrayList<String> subjectTextbookList = adminCourseDAO.subjectTextbookList();
						
						for (int i=0; i<subjectTextbookList.size(); i++) {
							
							System.out.println(subjectTextbookList.get(i));		
							if (i != subjectTextbookList.size() - 1) {
								administratorView.thinLine();
							}		
							
						}
						
						String newSubjectTextbookSeq = administratorView.editSubjectTextbook02();	
						String newSubjectTextbookName = adminCourseDAO.subjectTextbookName(newSubjectTextbookSeq);
						administratorView.editSubjectTextbook03(newSubjectTextbookName);
						
						
						//UPDATE 작업
						SubjectDTO subjectDTO = new SubjectDTO();
						subjectDTO.setSeq(subjectSeq); //개설 과목 번호
						subjectDTO.setTextbookSeq(newSubjectTextbookSeq); //새로운 교재명 번호

						int result = adminCourseDAO.editSubjectTextbook(subjectDTO);
						
						if (result == 1) {
							administratorView.editSubjectTextbook04(newSubjectTextbookName);
						} else {
							System.out.println("실패하였습니다");
						}				
						
					} else if (editElement.equals("0")) subjectEditElementLoop = false;
					
				}//while : subjectEditElementLoop
				
			} else if (subjectSeq.equals("0")) subjectEditLoop = false;
			
		}//while : subjectEditLoop
		
	}//method : subjectEdit

//===================================================================================================================================

	
	
//과목 삭제
//===================================================================================================================================
	
	@Override
	public void subjectDelete(String courseSeq) {
		
		boolean subjectDeleteLoop = true;
		
		while (subjectDeleteLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorCourseView.DELETESUBJECT);
			
			ArrayList<String> deleteSubjectList = adminCourseDAO.deleteSubjectList(courseSeq);
			
			for (int i=0; i<deleteSubjectList.size(); i++) {
				System.out.println(deleteSubjectList.get(i));			
			}
			
			String subjectSeq = administratorView.deleteSubjectList();
			
			if (!subjectSeq.equals("0")) {
				
				String deleteSubjectName = adminCourseDAO.deleteSubjectName(subjectSeq);
				
				//과목 삭제 작업 : UPDATE state
				SubjectDTO subjectDTO = new SubjectDTO();
				subjectDTO.setSeq(subjectSeq);

				int result = adminCourseDAO.deleteSubject(subjectDTO);
				
				if (result == 1) {
					administratorView.deleteSubjectFinish(deleteSubjectName);
				} else {
					System.out.println("실패하였습니다");
				}
				
			} else if (subjectSeq.equals("0")) subjectDeleteLoop = false;	
			
		}//while : subjectDeleteLoop
		
	}//method : subjectDelete

//===================================================================================================================================

	
	
//특정 과정을 수강하는 교육생 목록
//===================================================================================================================================
	
	@Override
	public void courseStudentList(String courseSeq) {
		
		boolean courseStudentListLoop = true;
		
		while (courseStudentListLoop) {
			
			Cls.clearScreen();
			
			administratorView.title(AdministratorCourseView.COURSESTUDENT);
			
			ArrayList<String> courseStudentList = adminCourseDAO.CourseStudentList(courseSeq);
			
			for (int i=0; i<courseStudentList.size(); i++) {
				System.out.printf("\n\t[교육생 %02d]", i+1);
				System.out.println(courseStudentList.get(i));			
			}
			
			String select = administratorView.CourseStudentList();
			
			if (!select.equals("0")) {
				
				continue;
				
			} else if (select.equals("0")) courseStudentListLoop = false;
			
		}//while : courseStudentListLoop
		
	}//method : courseStudentList

}//Class : AdCourseService
