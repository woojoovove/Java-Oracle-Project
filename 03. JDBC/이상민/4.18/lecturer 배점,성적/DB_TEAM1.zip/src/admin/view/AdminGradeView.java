package admin.view;

import java.util.Scanner;

public class AdminGradeView {
	
	public static final int DOUBLELINE = 1;
	public static final int LINE = 2;
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}

//===============================================================================================================================
	
	public void menuGrade() {
		
		System.out.println("\t\t\t\t[시험 및 성적관리]");
		System.out.println("\n\t==========================================================================\n");
		
		System.out.println("\t\t\t\t[1] 과정별 시험 및 성적 관리\n");
		System.out.println("\t\t\t\t[2] 교육생별 시험 및 성적 관리\n");
		System.out.println();
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		requireSelct();
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
	}
	
	public void requireSelct() {
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		System.out.println();
	}
	
	public void pressEnter() {
		System.out.println("\t계속 하시려면 ENTER키를 누르십시오");
		scan.nextLine();
		
	}
	
	public void title(int n) {
		
		switch(n)
		{
		
		case AdminGradeView.DOUBLELINE : 
				System.out.println("\t==========================================================================\n\n");
				break;
		case AdminGradeView.LINE : 
				System.out.println("\t--------------------------------------------------------------------------\n\n");
				break;
			
		}//switch End

	}

}
