﻿package admin.view;

import java.util.Scanner;

public class AdminStudentView {

	public static final int DOUBLELINE = 1;
	public static final int LINE = 2;
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}

//===============================================================================================================================
		
	public void menuAdStudent() {
		System.out.println("\t\t\t\t[교육생 관리]");
		System.out.println("\n\t==========================================================================\n");
		
		System.out.println("\t\t\t\t[1] 교육생 등록\n");
		System.out.println("\t\t\t\t[2] 교육생 정보 관리\n");
		System.out.println();
		System.out.println("\t\t\t\t[0] 뒤로 가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}

	public void menuManageStudent() {
		
		System.out.println("\t\t\t\t[교육생 정보 관리]");
		System.out.println("\n\t==========================================================================\n");
		
		System.out.println("\t\t\t\t[1] 이름으로 교육생 검색\n");
		System.out.println("\t\t\t\t[2] 과정명으로 교육생 검색\n");
		System.out.println();
		System.out.println("\t\t\t\t[0] 뒤로 가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
			
		
	}
	
	public void menuEditStudent() {
		
	}
	
	public void searchByName() {
		System.out.println("\t\t\t\t[이름으로 교육생 검색]");
		System.out.println("\n\t==========================================================================\n");
		
		System.out.println("\t교육생 이름을 입력해주십시오.\n");
		System.out.print("\t입력[한글]:");
		System.out.println();
		System.out.println("\n\t==========================================================================\n");
		
	}
	
	public void requireSelct() {
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		System.out.println();
	}
	
	public void pressEnter() {
		System.out.println("\t계속 하시려면 ENTER키를 누르십시오");
		scan.nextLine();
		
	}
	
	
	public void title(int n) {
		
		switch(n)
		{
		
		case AdminStudentView.DOUBLELINE : 
				System.out.println("\t==========================================================================\n\n");
				break;
		case AdminStudentView.LINE : 
				System.out.println("\t--------------------------------------------------------------------------\n\n");
				break;
			
		}//switch End

	}
		
}
