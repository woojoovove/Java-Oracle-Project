package dto;

public class VwcousubstutexlecDTO {
	
	private String vstuname;
	private String vsturnum;
	private String vstupnum;
	private String vcouname;
	private String vcoustart;
	private String vcouend;
	private String vroomname;
	private String vsubname;
	private String vsubstart;
	private String vsubend;
	private String vtextname;
	private String vlecname;
	private String vsinfoseq;
	private String vcouseq;
	private String vsubseq;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVsturnum() {
		return vsturnum;
	}
	public void setVsturnum(String vsturnum) {
		this.vsturnum = vsturnum;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcouend() {
		return vcouend;
	}
	public void setVcouend(String vcouend) {
		this.vcouend = vcouend;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVsubstart() {
		return vsubstart;
	}
	public void setVsubstart(String vsubstart) {
		this.vsubstart = vsubstart;
	}
	public String getVsubend() {
		return vsubend;
	}
	public void setVsubend(String vsubend) {
		this.vsubend = vsubend;
	}
	public String getVtextname() {
		return vtextname;
	}
	public void setVtextname(String vtextname) {
		this.vtextname = vtextname;
	}
	public String getVlecname() {
		return vlecname;
	}
	public void setVlecname(String vlecname) {
		this.vlecname = vlecname;
	}
	public String getVsinfoseq() {
		return vsinfoseq;
	}
	public void setVsinfoseq(String vsinfoseq) {
		this.vsinfoseq = vsinfoseq;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	
	
	
	
}
