package student.service;

import java.util.ArrayList;
import java.util.Scanner;

import student.dao.StudentAttendanceRecordDAO;
import student.dao.StudentAttendanceViewDAO;
import student.view.StudentView;
import util.Cls;

public class StAttendanceViewService implements IStAttendanceViewService {

	private static StudentView studentView;
	private static StudentAttendanceViewDAO studentAttendanceViewDAO;
	private static Scanner scan;
	
	static {
		studentView = new StudentView();
		studentAttendanceViewDAO = new StudentAttendanceViewDAO();
		scan = new Scanner(System.in);
	}
	
	

//출결 조회 - 전체 기간 조회
//=====================================================================================================================
	
	@Override
	public void entireAttendanceView(String studentSeq) {
				
		boolean entireAttendanceViewLoop = true;
		
		while (entireAttendanceViewLoop) {
			
			Cls.clearScreen();
			studentView.title(StudentView.ATTENDANCEENTIREVIEW);
			String studentName = studentAttendanceViewDAO.studentName(studentSeq);
			studentView.studentName(studentName);
			
			
			System.out.println("\n\n\n\n\n\n");
			System.out.println("\t전체 출결 사항");
			System.out.println("\n\n\n\n\n\n");
			
			
			
			
			String select = studentView.entireAttendanceView();
			
			if (!select.equals("0")) continue;
			else if (select.equals("0")) entireAttendanceViewLoop = false;
			
		}//while : entireAttendanceViewLoop
		
	}//method : entireAttendanceView

//=====================================================================================================================
	
	
	
//출결 조회 - 과목별 조회
//=====================================================================================================================
	
	@Override
	public void subjectAttendanceView(String studentSeq) {
		
		boolean subjectAttendanceViewLoop01 = true;
		
		while (subjectAttendanceViewLoop01) {
			
			Cls.clearScreen();
			studentView.title(StudentView.ATTENDANCESUBJECTVIEW);
			
			ArrayList<String> subjectList = studentAttendanceViewDAO.subjectAttendanceView(studentSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));	
				
				if (i == subjectList.size() - 1) {
					studentView.thickLine();
				} else {
					studentView.thinLine();
				}
				
			}
						
			String select = studentView.subjectAttendanceView01();
			
			if (!select.equals("0")) {
				
				boolean subjectAttendanceViewLoop02 = true;
				
				while (subjectAttendanceViewLoop02) {
					
					Cls.clearScreen();
					studentView.title(StudentView.ATTENDANCESUBJECTVIEW);
					String studentName = studentAttendanceViewDAO.studentName(studentSeq);
					studentView.studentName(studentName);
					
					
					
					
					System.out.println("\n\n\n\n\n\n");
					System.out.println("\t과목별 출결 사항");
					System.out.println("\n\n\n\n\n\n");
					
					
					
					
					select = studentView.subjectAttendanceView02();
					
					if (!select.equals("0")) continue;
					else if (select.equals("0")) subjectAttendanceViewLoop02 = false;
					
				}//while : subjectAttendanceViewLoop02

			} else if (select.equals("0")) subjectAttendanceViewLoop01 = false;
			
		}//while : subjectAttendanceViewLoop01
		
	}//method : monthlyAttendanceView
	
}//class : StAttendanceViewService


