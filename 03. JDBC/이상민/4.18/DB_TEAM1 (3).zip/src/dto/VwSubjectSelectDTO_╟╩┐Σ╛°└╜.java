package dto;

public class VwSubjectSelectDTO_필요없음 {

	private String vSubjectNum;
	private String vSubjectName;
	
//---------------------------------------------------------	
	
	public String getvSubjectNum() {
		return vSubjectNum;
	}
	public void setvSubjectNum(String vSubjectNum) {
		this.vSubjectNum = vSubjectNum;
	}
	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
		
}
