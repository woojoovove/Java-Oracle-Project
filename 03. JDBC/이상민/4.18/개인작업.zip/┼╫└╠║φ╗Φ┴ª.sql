drop SEQUENCE tbltutoringseq;
drop SEQUENCE tblwarningseq;
drop SEQUENCE tblsubjectgradeseq;
drop SEQUENCE attendanceSeq;
drop SEQUENCE tblstudentSeq;
drop SEQUENCE tblsubjectSeq;
drop SEQUENCE tblstudentinfoSeq;
drop SEQUENCE tblTextbookSeq;
drop SEQUENCE tblQuizSeq;
drop SEQUENCE studentSeq;
drop SEQUENCE tblPublisherSeq;
drop SEQUENCE subjectSeq;
drop SEQUENCE tblAvlbSeq;
drop SEQUENCE tblcourseSeq;
drop SEQUENCE courseSeq;
drop SEQUENCE subjectTypeSeq;
drop SEQUENCE textbookSeq;
drop SEQUENCE quizSeq;
drop SEQUENCE publisherSeq;
DROP SEQUENCE holidaySeq;
drop SEQUENCE recommendationSeq;
drop SEQUENCE dateSeq;
drop SEQUENCE courseNameSeq;
drop SEQUENCE subjectNameSeq;


drop view VWDATE;
drop view VWDATES;
drop view VWSUBJECTNAME;
DROP VIEW TBLVWQUIZLIST;
DROP VIEW TBLVWSTUDENTINFO;
DROP VIEW VWCOURSEINFO;
DROP VIEW VWCOURSELIST;
DROP VIEW VWLECTURERINFO;
DROP VIEW VWSUBJECTLIST;
DROP VIEW VWSUBJECTPERCENT;
DROP VIEW VWSUBJECTQUIZDATE;
DROP VIEW VWSUBJECTSELECT;





DROP TABLE TBLDATE;
DROP TABLE TBLHOLIDAYTEST;
drop TABLE TBLRECOMMENDATION;
drop TABLE tbltutoring;
drop TABLE tblwarning;
drop TABLE tblsubjectgrade;
drop TABLE tblAttendance;
drop TABLE tblsubject;
drop TABLE tblstudentinfo;
drop TABLE tblTextbook;
drop TABLE tblQuiz;
drop TABLE tblAttendanceType;
DROP TABLE tblattendance;
drop TABLE tblStudent;
drop TABLE tblPublisher;
drop TABLE tblSubjectName;
drop TABLE tblAvlb;
drop TABLE tblcourse;
drop TABLE tblCourseName;
drop TABLE tblSubjectType;
drop TABLE tblLecturer;
drop TABLE tblClassRoom;
DROP TABLE tblHoliday;






