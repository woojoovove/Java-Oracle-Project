package lecturer.service;
import lecturer.LecturerGradeView;
import lecturer.LecturerGradeDAO;
import dto.*;
import java.util.Scanner;
import java.sql.ResultSet;
import java.util.ArrayList;
public class LeGradeService implements ILeGradeService{
	
		
	private static Scanner scan;
	private static LecturerGradeView view;
	
	
	
	public LeGradeService() {
		view = new LecturerGradeView();
		scan = new Scanner(System.in);
		
	}
	
	@Override
	public void allsubject() {
		
		System.out.println("[종강 과목 조회]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwcousubstubookDTO> list = dao.Vwcousubstubooklist();
		
		int i = 0;
		for(VwcousubstubookDTO dto : list) {
			i++;
			System.out.println(String.format("[과목 %s]",dto.getVsubseq()));
			System.out.printf("[과정명] %s\n[과정기간()] %s ~ %s\n[강의실] %s\n"
					+"[과목명] %s\n[과목기간] %s ~ %s\n[교재명]%s\n[출결배점] %s\n[필기배점] %s\n[실기배점]%s\n"
					,dto.getVcouname(),dto.getVcoustart(),dto.getVcouend(),dto.getVroomname(),
					dto.getVsubname(),dto.getVsubstart(),dto.getVsubend(),dto.getVbookname(),dto.getVsubatt(),
					dto.getVsubwrit(),dto.getVsubprac());
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것. 시간 yy mm dd
		
		System.out.println("다음 페이지 이동 버튼");
		
		
		
		dao.close();
		
		
		
		
		
		
		
		
		
	}

	@Override
	public void student(String nextLine) {
		
		
		System.out.println("\t\t\t\t[교육생]");
				
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwsinfoDTO> list = dao.VwsinfoList(nextLine); //과목 seq가 들어가야함.
		
		
		System.out.println("[교육생번호]\t[이름]\t[전화번호]\t\t[수료,중도탈락]\t[날짜]");
		for(VwsinfoDTO dto : list) {
			
			System.out.printf("[%s]\t[%s]\t[%s]\t\t[%s]\t\t[%s]\n",
					dto.getVstuseq(),dto.getVstuname(),dto.getVstupnum(),
					dto.getVstustatus(),dto.getVstatusdate());
					
			
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것,성적이 입력되지 않은 더미 필요.
		
		
		
		dao.close();
		
		
	}

	@Override
	public String alleachstudent(String subseq, String nextLine) {
		
		System.out.println("\t\t\t\t[종강 과목 조회]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		VwstugrainfoDTO dto = dao.vwstugrainfolist(subseq,nextLine);
		
		
		System.out.println("[교육생번호]\t[이름]\t[필기]\t[실기]");
		System.out.printf("[%s]\t[%s]\t[%s]\t[%s]\n",
				dto.getVstuseq(),dto.getVstuname(),dto.getVgrawri(),dto.getVgraprac());
	
			
		
		dao.close();
		
		return dto.getVgraseq();
	}

	
	@Override
	public void subject() {
		
		System.out.println("\t\t\t\t[종강 과목 조회]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwcousubstubookDTO> list = dao.Vwcousubstubooklist();
		
		int i = 0;
		for(VwcousubstubookDTO dto : list) {
			i++;
			System.out.println(String.format("[과목 %s]",dto.getVsubseq()));
			System.out.printf("[과정명] %s\n[과정기간()] %s ~ %s\n[강의실] %s\n"
					+"[과목명] %s\n[과목기간] %s ~ %s\n[교재명]%s\n[출결배점] %s\n[필기배점] %s\n[실기배점]%s\n"
					,dto.getVcouname(),dto.getVcoustart(),dto.getVcouend(),dto.getVroomname(),
					dto.getVsubname(),dto.getVsubstart(),dto.getVsubend(),dto.getVbookname(),dto.getVsubatt(),
					dto.getVsubwrit(),dto.getVsubprac());
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것. 시간 yy mm dd
		
		System.out.println("다음 페이지 이동 버튼");
		
		
		
		dao.close();
		
		
		
		
	}


	@Override
	public String eachstudent(String courseseq, String studentseq) {
		
		
		System.out.println("\t\t\t\t[성적 입력]");
		
		System.out.println("[교육생번호]\t[이름]\t[전화번호]\t\t[수료,중도탈락]\t[날짜]");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		VwstugraDTO dto = dao.vwstugralist(courseseq,studentseq);
		
		System.out.printf("%s\t%s\t%s\t\t%s\t%s\n", dto.getVstuseq(),
											dto.getVstuname(),dto.getVstupnum(),
											dto.getVstustatus(),dto.getVstustadate());
		
		dao.close();
		
		
		return dto.getVgraseq();
	}

	@Override
	public void written(String gradeseq) {
		
		System.out.println("\t필기 점수 입력");
		System.out.println("\t0~100");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		String score = scan.nextLine();
		dao.grawrittenupdate(gradeseq,score);
		
		dao.close();
	}

	@Override
	public void practical(String gradeseq) {
		
		System.out.println("\t실기 점수 입력");
		System.out.println("\t0~100");
		
		LecturerGradeDAO dao = new LecturerGradeDAO();
		String score = scan.nextLine();
		dao.grapracticeupdate(gradeseq,score);
		
		dao.close();
		
	}

	@Override
	public void allstudent(String nextLine) {
		
		
		System.out.println("\t\t\t\t[교육생 선택]");
				
		LecturerGradeDAO dao = new LecturerGradeDAO();
		ArrayList<VwstugrainfoDTO> list = dao.VwstugrainfoDTO(nextLine); //과목 seq가 들어가야함.
		
		
		System.out.println("[교육생번호]\t[이름]\t[필기]\t[실기]");
		for(VwstugrainfoDTO dto : list) {
			
			System.out.printf("[%s]\t[%s]\t[%s]\t[%s]\n",
					dto.getVstuseq(),dto.getVstuname(),dto.getVgrawri(),dto.getVgraprac());
					
			
			System.out.println();
			
		}  //한페이지에 몇개 나오게 할 지 정할 것,성적이 입력되지 않은 더미 필요.
		
		
		
		dao.close();
		
		
		
		
	}

	

}
