package lecturer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwcousubstubookDTO;
import dto.VwsinfoDTO;
import dto.VwstugraDTO;
import dto.VwstugrainfoDTO;
import util.DBUtil;

public class LecturerGradeDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;

	public LecturerGradeDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
	}
//-----------------------------------------------------		
	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
//-----------------------------------------------------	
	public ArrayList<VwcousubstubookDTO> Vwcousubstubooklist() {
		try {
			
			String sql = "SELECT * FROM Vwcousubstubook WHERE vcouseq = 1 and vsubend<sysdate";
			ResultSet rs = stat.executeQuery(sql);
								
			ArrayList<VwcousubstubookDTO> list = new ArrayList<VwcousubstubookDTO>();
		
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwcousubstubookDTO dto = new VwcousubstubookDTO();
				
				dto.setVbookname(rs.getString("vbookname"));
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVroomname(rs.getString("Vroomname"));
				dto.setVsubatt(rs.getString("vsubatt"));
				dto.setVsubend(rs.getString("vsubend"));
				dto.setVsubname(rs.getString("vsubname"));
				dto.setVsubprac(rs.getString("Vsubprac"));
				dto.setVsubseq(rs.getString("Vsubseq"));
				dto.setVsubstart(rs.getString("Vsubstart"));
				dto.setVsubwrit(rs.getString("Vsubwrit"));
						
				list.add(dto);
			}
						
			return list;	
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
//-----------------------------------------------------
	public ArrayList<VwsinfoDTO> VwsinfoList(String nextLine) {
		try {
			
			String sql = "select * from vwsinfo where vgsubseq = "+nextLine;
			ResultSet rs = stat.executeQuery(sql);
								
			ArrayList<VwsinfoDTO> list = new ArrayList<VwsinfoDTO>();
		
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwsinfoDTO dto = new VwsinfoDTO();
				
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstuseq(rs.getString("vstuseq"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVgsubseq(rs.getString("vgsubseq"));
				dto.setVstatusdate(rs.getString("vstatusdate"));					
				list.add(dto);
			}
						
			return list;	
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
//-----------------------------------------------------
	public VwstugrainfoDTO vwstugrainfolist(String subseq, String nextLine) {
		try {
			
			String sql = "select * from vwstugrainfo where vgrasubseq = '"+subseq+"' and vstuseq = '"+nextLine+"'";
			ResultSet rs = stat.executeQuery(sql);
						
			if(rs.next()) {
				VwstugrainfoDTO dto = new VwstugrainfoDTO();
				
				dto.setVgraprac(rs.getString("vgraprac"));
				dto.setVgraseq(rs.getString("vgraseq"));
				dto.setVgrasubseq(rs.getString("vgrasubseq"));
				dto.setVgrawri(rs.getString("vgrawri"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstuseq(rs.getString("vstuseq"));
				
				return dto;	
											
			}
						
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
//-----------------------------------------------------
	public VwstugraDTO vwstugralist(String courseseq, String studentseq) {
		try {
			
			String sql = "select * from vwstugra where vstuseq='"+studentseq+"'and vsubseq='"+courseseq+"'";
			ResultSet rs = stat.executeQuery(sql);
					
				
			if(rs.next()) {
				VwstugraDTO dto = new VwstugraDTO();
				
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstuseq(rs.getString("vstuseq"));
				dto.setVstustadate(rs.getString("vstustadate"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVsubseq(rs.getString("vsubseq"));
				dto.setVgraseq(rs.getString("vgraseq"));
				return dto;	
			}else {
				System.out.println("목록이 없습니다.");
			}
						
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
//-----------------------------------------------------
	public int grawrittenupdate(String gradeseq, String nextLine) {
		String sql = "UPDATE tblsubjectgrade SET written = ? where seq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, gradeseq);
			
			return pstat.executeUpdate();
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
						
		return 0;
		
	}
//-----------------------------------------------------
	public int grapracticeupdate(String gradeseq, String nextLine) {
		String sql = "UPDATE tblsubjectgrade SET practical = ? where seq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, gradeseq);
			
			return pstat.executeUpdate();
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
						
		return 0;
		
	}
//-----------------------------------------------------
	public ArrayList<VwstugrainfoDTO> VwstugrainfoDTO(String nextLine) {
		try {
			
			String sql = "select * from vwstugrainfo where vgrasubseq = '"+nextLine+"'";
			ResultSet rs = stat.executeQuery(sql);
								
			ArrayList<VwstugrainfoDTO> list = new ArrayList<VwstugrainfoDTO>();
		
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwstugrainfoDTO dto = new VwstugrainfoDTO();
				
				dto.setVgraprac(rs.getString("vgraprac"));
				dto.setVgraseq(rs.getString("vgraseq"));
				dto.setVgrasubseq(rs.getString("vgrasubseq"));
				dto.setVgrawri(rs.getString("vgrawri"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstuseq(rs.getString("vstuseq"));
											
				list.add(dto);
			}
						
			return list;	
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return null;
	}
}
