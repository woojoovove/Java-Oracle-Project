package dto;

public class VwDelList {

	private String vcouseq;
	private String vcouname;
	private String vcoustart;
	private String vcouend;
	
	
	
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcouend() {
		return vcouend;
	}
	public void setVcouend(String vcouend) {
		this.vcouend = vcouend;
	}
	
	
}
