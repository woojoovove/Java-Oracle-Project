package dto;

public class VwstucoutempDTO {

	
	private String vstuname;
	private String vsturnum;
	private String vstupnum;
	private String vcouname;
	private String vcoustart;
	private String vcouend;
	private String vroomname;
	private String vsinfoseq;
	private String vcouseq;

	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVsturnum() {
		return vsturnum;
	}
	public void setVsturnum(String vsturnum) {
		this.vsturnum = vsturnum;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcouend() {
		return vcouend;
	}
	public void setVcouend(String vcouend) {
		this.vcouend = vcouend;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVsinfoseq() {
		return vsinfoseq;
	}
	public void setVsinfoseq(String vsinfoseq) {
		this.vsinfoseq = vsinfoseq;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	
	
	
	
	
	
}
