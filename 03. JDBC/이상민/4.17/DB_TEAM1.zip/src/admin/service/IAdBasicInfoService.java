package admin.service;

public interface IAdBasicInfoService {

	void addLecturer();

	void lecturerInfo();

	void detailLecturer();

	void updateLecturerName();

	void updateLecturerReg();

	void updateLecturerTel();

	void updateLecturerSubject();

	void textBook();

	void textBookMenu();

	void modifytextBook();

	void deletetextBook();

	void selectPublisher();

	void classRoom();

	void modifyClassRoomName();

	void modifyclassRoomNum();

	void subjectName();

	void insertSubject();

	void modifySubject();

	void deleteSubject();

	void basicInfomenu();

	void insertCourseName();

	void modifyCourseName();

	void deleteCourseName();

}
