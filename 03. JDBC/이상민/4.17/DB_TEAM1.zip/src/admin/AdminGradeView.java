package admin;

import java.util.Scanner;
public class AdminGradeView {
	
	private static Scanner scan;
	public static final int DOUBLELINE = 1;
	public static final int LINE = 2;
	static {
		scan = new Scanner(System.in);
	}
	

	public void requireSelct() {
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		System.out.println();
	}
	
	public void pressEnter() {
		System.out.println("\t계속 하시려면 ENTER키를 누르십시오");
		scan.nextLine();
		
	}
	
public void title(int n) {
		
		switch(n)
		{
		case AdminGradeView.DOUBLELINE				: System.out.println("\t==========================================================================\n\n");break;
		case AdminGradeView.LINE						: System.out.println("\t--------------------------------------------------------------------------\n\n");break;
			
		}//switch End

	}
}
