package student.service;

public class StAttendanceRecordService implements IStAttendanceRecordService {

	@Override
	public void attendanceRecordAdd() {
		// TODO Auto-generated method stub
		
	}

}
