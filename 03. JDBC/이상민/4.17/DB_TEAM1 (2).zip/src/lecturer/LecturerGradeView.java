package lecturer;

import java.util.Scanner;

import admin.AdministratorView;

public class LecturerGradeView {

	private static Scanner scan;
	public static final int DOUBLELINE = 1;
	public static final int LINE = 2;
	static {
		scan = new Scanner(System.in);
	}
	

	public void requireSelct() {
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		System.out.println();
	}
	
	public void pressEnter() {
		System.out.println("\t계속 하시려면 ENTER키를 누르십시오");
		scan.nextLine();
		
	}
	
public void title(int n) {
		
		switch(n)
		{
		case LecturerGradeView.DOUBLELINE				: System.out.println("\t==========================================================================\n");break;
		case LecturerGradeView.LINE						: System.out.println("\t--------------------------------------------------------------------------\n");break;
			
		}//switch End

	}

public void main() {
	
	System.out.println("\t\t\t\t[성적 입출력]");
	
	System.out.println("\n\t==========================================================================\n");

	System.out.println("\t\t\t\t[1] 성적 입력\n");
	System.out.println("\t\t\t\t[2] 성적 수정\n");
	
	System.out.println("\t\t\t\t[0] 돌아가기\n");
	
	System.out.println("\t--------------------------------------------------------------------------\n");
	
	
	
	
}
}
