package admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.*;
import util.DBUtil;

public class AdminDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;

	public AdminDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
	}
//-----------------------------------------------------		
	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close
	
	
	
	public void studentAdd(String name, String rnum, String pnum) {
		 // name,rnum,pnum
		String sql = "INSERT INTO tblstudentinfo values(TBLSTUDENTINFOSEQ.nextval,?,?,?,SYSDATE,default)";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			pstat.setString(2, rnum);
			pstat.setString(3, pnum);
			
			pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
						
		
		
		
		
	}
	public ArrayList<StudentInfoDTO> searchByName(String nextLine) {
		
		String sql = "SELECT * FROM vwtblstudentinfo WHERE name = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			
			ResultSet rs = pstat.executeQuery();
								
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
		
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				StudentInfoDTO dto = new StudentInfoDTO();
				
				dto.setName(rs.getString("name"));
				dto.setPhoneNum(rs.getString("phoneNum"));
				dto.setRegistrationDate(rs.getString("registrationDate"));
				dto.setRegistrationNum(rs.getString("registrationNum"));
				dto.setDelete(rs.getString("state"));
				dto.setSeq(rs.getString("seq"));

				list.add(dto);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
		
	}
	
	public StudentInfoDTO studentInfoBySeq(String nextLine) {
		
		String sql = "SELECT * FROM vwtblstudentinfo WHERE seq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
								
			if(rs.next()) {
				StudentInfoDTO dto = new StudentInfoDTO();
				dto.setName(rs.getString("name"));
				dto.setPhoneNum(rs.getString("phoneNum"));
				dto.setRegistrationDate(rs.getString("registrationDate"));
				dto.setRegistrationNum(rs.getString("registrationNum"));
				dto.setDelete(rs.getString("state"));
				dto.setSeq(rs.getString("seq"));

				return dto;
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	public VwstucouDTO courseInfo(String nextLine) {
		
		String sql = "SELECT * FROM vwstucou WHERE vstuinseq =?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
								
			if(rs.next()) {
				
								
				
				
				VwstucouDTO dto = new VwstucouDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVstuinseq(rs.getString("vstuinseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVsturnum(rs.getString("vsturnum"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVstuinrdate(rs.getString("vstuinrdate"));
				dto.setVstustatusdate(rs.getString("vstustatusdate"));				
				return dto;
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	public void studentinfoDelete(String vstuinseq) {
		String sql = "UPDATE tblstudentinfo SET state = '0' WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, vstuinseq);
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	public void modifyName(VwstucouDTO coudto, String nextLine) {
		
		String sql = "UPDATE tblstudentinfo SET name = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
	}
	public void modifyRnum(VwstucouDTO coudto, String nextLine) {
		
		String sql = "UPDATE tblstudentinfo SET registrationnum = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void modifyPnum(VwstucouDTO coudto, String nextLine) {
		
		String sql = "UPDATE tblstudentinfo SET phonenum = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void modifyRdate(VwstucouDTO coudto, String nextLine) {
		String sql = "UPDATE tblstudent SET registrationtime = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void modifyStatus(String select, String date, VwstucouDTO coudto) {
		
		String sql = "UPDATE tblstudentinfo SET registrationnum = ? WHERE seq = ? ";
		String status = "";
		if(select.equals("1")) {
			status = "3";
		}else if(select .equals("2")) {
			status = "2";
		}else {
			status = "1";
		}
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, status);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public ArrayList<VwcoustuDTO> vwCouStu() {
		
		String sql = "SELECT * FROM vwcoustu";
				
		try {
			stat = conn.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			ArrayList<VwcoustuDTO>list = new ArrayList<VwcoustuDTO>();
			
			if(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwcoustuDTO dto = new VwcoustuDTO();
				dto.setVname(rs.getString("vname"));
				dto.setVseq(rs.getString("vseq"));
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<VwstucouDTO> selCouStuList(String nextLine) {
		
		String sql = "SELECT * FROM vwstucou WHERE vcouseq =?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwstucouDTO> list = new ArrayList<VwstucouDTO>();				
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwstucouDTO dto = new VwstucouDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVstuinseq(rs.getString("vstuinseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVsturnum(rs.getString("vsturnum"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVstuinrdate(rs.getString("vstuinrdate"));
				dto.setVstustatusdate(rs.getString("vstustatusdate"));				
				
				list.add(dto);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<VwcouingdateDTO> couIngList() {
		
		String sql = "SELECT * FROM vwcouingdate";
		
		
		try {
			stat = conn.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			ArrayList<VwcouingdateDTO> list = new ArrayList<VwcouingdateDTO>();
			while(rs.next()) {
			VwcouingdateDTO dto = new VwcouingdateDTO();
			
			dto.setVcouname(rs.getString("vcouname"));
			dto.setVcouseq(rs.getString("vcouseq"));
			
			list.add(dto);
				
			}
			
			return list;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return null;
	}
	public VwcouroomlecDTO gradeBySubject(String couseq) {
		
		String sql = "SELECT * FROM vwcouroomlec WHERE  vcouseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, couseq);
			
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				
				VwcouroomlecDTO dto = new VwcouroomlecDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVlecname(rs.getString("vlecname"));
				dto.setVroomname(rs.getString("vroomname"));
				
				return dto;
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public VwsubcouroomlecDTO vwsubcouroomlec(String couseq, String subseq) {
		
		String sql = "SELECT * FROM vwsubcouroomlec WHERE vcouseq = ? and vsubseq = ? "; 
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, couseq);
			pstat.setString(2, subseq);
			
			ResultSet rs = pstat.executeQuery();
			
			VwsubcouroomlecDTO dto = new VwsubcouroomlecDTO();
			if(rs.next()) {
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVlecname(rs.getString("vlecname"));
				dto.setVroomname(rs.getString("vroomname"));
				dto.setVsubname(rs.getString("vsubname"));
				dto.setVsubseq(rs.getString("vsubseq"));
				dto.setVsubend(rs.getString("vsubend"));
				dto.setVsubstart(rs.getString("vsubstart"));
				dto.setVtextname(rs.getString("vtextname"));
				return dto;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}
	public ArrayList<VwcousubDTO> vwcousub(String couseq) {
		
		String sql = "SELECT * FROM vwcousub WHERE vcouseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, couseq);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwcousubDTO> list = new ArrayList<VwcousubDTO>();
			
			while(rs.next()) {
				VwcousubDTO dto = new VwcousubDTO();
				
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVsubname(rs.getString("vsubname"));
				dto.setVsubseq(rs.getString("vsubseq"));
				
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}
	public String cntQuiz(String vsubseq) {
		
		String sql = "select count(*) as vcnt from tblQuiz where subjectseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, vsubseq);
			
			ResultSet rs = pstat.executeQuery();
			
			if(rs.next()) {
				return rs.getString("vcnt");
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public String cntSubRegist(String vsubseq) {
		
		String sql = "select count(*) as vcnt from tblsubjectgrade where subjectseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, vsubseq);
			
			ResultSet rs = pstat.executeQuery();
			
			if(rs.next()) {
				return rs.getString("vcnt");
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<VwsinfograDTO> vwsinfogra(String couseq, String subseq) {
		
		String sql = "SELECT * FROM vwsinfogra WHERE vsubseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, subseq);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwsinfograDTO> list = new ArrayList<VwsinfograDTO>();
			
			while(rs.next()) {
				VwsinfograDTO dto = new VwsinfograDTO();
				
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVgraprac(rs.getString("vgraprac"));
				dto.setVgrawri(rs.getString("vgrawri"));
				dto.setVrnum(rs.getString("vrnum"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVsubseq(rs.getString("vsubseq"));
				
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}
	public ArrayList<StudentInfoDTO> studentInfoByName(String name) {
		
		String sql = "SELECT * FROM tblstudentinfo WHERE name like '%'||?||'%'";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
			
			while(rs.next()) {
				StudentInfoDTO dto = new StudentInfoDTO();
				
				dto.setDelete(rs.getString("state"));
				dto.setName(rs.getString("name"));
				dto.setPhoneNum(rs.getString("phoneNum"));
				dto.setRegistrationDate(rs.getString("registrationDate"));
				dto.setRegistrationNum(rs.getString("registrationNum"));
				dto.setSeq(rs.getString("seq"));
				
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<VwstucoutempDTO> vwstucoutemp(String stuinfoseq) {
		
		String sql = "select * from vwstucoutemp where vsinfoseq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, stuinfoseq);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwstucoutempDTO> list = new ArrayList<VwstucoutempDTO>();
			
			while(rs.next()) {
				VwstucoutempDTO dto = new VwstucoutempDTO();
				
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVroomname(rs.getString("vroomname"));
				dto.setVsinfoseq(rs.getString("vsinfoseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVsturnum(rs.getString("vsturnum"));
				
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
		
		
		
	}
	public ArrayList<VwcousubstutexlecDTO> vwcousubstutexlec(String vcouseq, String stuinfoseq) {
		
		String sql = "SELECT * FROM vwcousubstutexlec WHERE vcouseq = ? and vsinfoseq =?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, vcouseq);
			pstat.setString(2, stuinfoseq);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwcousubstutexlecDTO> list = new ArrayList<VwcousubstutexlecDTO>();
			
			while(rs.next()) {
				VwcousubstutexlecDTO dto = new VwcousubstutexlecDTO();
				
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVlecname(rs.getString("vlecname"));
				dto.setVroomname(rs.getString("vroomname"));
				dto.setVsinfoseq(rs.getString("vsinfoseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVsturnum(rs.getString("vsturnum"));
				dto.setVsubend(rs.getString("vsubend"));
				dto.setVsubname(rs.getString("vsubname"));
				dto.setVsubstart(rs.getString("vsubstart"));
				dto.setVtextname(rs.getString("vtextname"));
				dto.setVsubseq(rs.getString("vsubseq"));
							
				
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
		
		
		
	}
	public VwsubgraquizDTO vwsubgraquiz(String stuinfoseq, String subseq) {
		
		String sql = "select * from vwsubgraquiz  WHERE vsubseq= ? and vstuinseq = ?";
		
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, subseq);
			pstat.setString(2, stuinfoseq);
			
			ResultSet rs = pstat.executeQuery();
						
			if(rs.next()) {
				VwsubgraquizDTO dto = new VwsubgraquizDTO();
				
				dto.setVgrapractical(rs.getString("vgrapractical"));
				dto.setVgrawritten(rs.getString("vgrawritten"));
				dto.setVlecturername(rs.getString("vlecturername"));
				dto.setVquizdate(rs.getString("vquizdate"));
				dto.setVstuinseq(rs.getString("vstuinseq"));
				dto.setVsubend(rs.getString("vsubend"));
				dto.setVsubnanme(rs.getString("vsubnanme"));
				dto.setVsubpracpercent(rs.getString("vsubpracpercent"));
				dto.setVsubseq(rs.getString("vsubseq"));
				dto.setVsubstart(rs.getString("vsubstart"));
				dto.setVsubwrittenpercent(rs.getString("vsubwrittenpercent"));
				dto.setVtextname(rs.getString("vtextname"));
				
				return dto;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

//-----------------------------------------------------






}
