package student.service;

import java.util.ArrayList;

import dto.VwCountAttendanceDTO;
import dto.VwCourseDTO;
import student.dao.StudentAttendanceViewDAO;
import student.view.StudentAttendanceView;
import util.Cls;

public class StAttendanceViewService implements IStAttendanceViewService {

	private static StudentAttendanceView studentAttendanceView;
	private static StudentAttendanceViewDAO studentAttendanceViewDAO;
	
	static {
		studentAttendanceView = new StudentAttendanceView();
		studentAttendanceViewDAO = new StudentAttendanceViewDAO();
	}
	
	

//출결 조회 - 전체 기간 조회
//=====================================================================================================================
	
	@Override
	public void entireAttendanceView(String studentSeq) {
		
		boolean entireAttendanceViewLoop01 = true;
		
		while (entireAttendanceViewLoop01) {
			
			Cls.clearScreen();
			studentAttendanceView.title(StudentAttendanceView.ATTENDANCEENTIREVIEW);

			ArrayList<VwCourseDTO> courseNameDTO = studentAttendanceViewDAO.courseNameList(studentSeq);
			
			for (VwCourseDTO dto : courseNameDTO) {
				
				System.out.printf("\t[%s] %s\n", dto.getVcourseSeq(), dto.getVcourseName());
				System.out.println("\t--------------------------------------------------------------------------\n");
				
			}
			
			String courseSeq = studentAttendanceView.entireAttendanceView01();
			
			if (!courseSeq.equals("0")) {
				
				boolean entireAttendanceViewLoop02 = true;
				
				while (entireAttendanceViewLoop02) {
					
					Cls.clearScreen();
					studentAttendanceView.title(StudentAttendanceView.ATTENDANCEENTIREVIEW);
					
					VwCourseDTO dto = studentAttendanceViewDAO.myCourseName(courseSeq);
					
					System.out.println("\n\t[과정명]");
					System.out.println("\n\t==========================================================================\n");
					System.out.printf("\t%s",  dto.getVcourseName());
					System.out.println("\n\t==========================================================================\n");
					System.out.println();
					System.out.println("\t[전체 기간 조회]");
							
					ArrayList<VwCountAttendanceDTO> list = studentAttendanceViewDAO.fullAttendance(studentSeq);
							
					for (VwCountAttendanceDTO dto2 : list) {
						System.out.println("\n\t--------------------------------------------------------------------------\n");
						System.out.printf("\t이름: %s\n", dto2.getName());
						System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
											, dto2.getAttended()
											, dto2.getLate()
											, dto2.getEarly()
											, dto2.getGoout()
											, dto2.getAbscence());
						
					}
					
					System.out.println("\t==========================================================================");
					
					String select = studentAttendanceView.entireAttendanceView02();
					
					if (!select.equals("0")) continue;
					
					else if (select.equals("0")) entireAttendanceViewLoop02 = false; 
					
				}//while : entireAttendanceViewLoop02
				
			} else if (courseSeq.equals("0")) entireAttendanceViewLoop01 = false; 

		}//while : entireAttendanceViewLoop01
				
	}//method : entireAttendanceView

//=====================================================================================================================
	
	
	
//출결 조회 - 과목별 조회
//=====================================================================================================================
	
	@Override
	public void subjectAttendanceView(String studentSeq) {
		
		boolean subjectAttendanceViewLoop01 = true;
		
		while (subjectAttendanceViewLoop01) {
			
			Cls.clearScreen();
			studentAttendanceView.title(StudentAttendanceView.ATTENDANCESUBJECTVIEW);
			
			ArrayList<String> subjectList = studentAttendanceViewDAO.subjectAttendanceView(studentSeq);
			
			for (int i=0; i<subjectList.size(); i++) {
				System.out.println(subjectList.get(i));	
				
				if (i == subjectList.size() - 1) {
					studentAttendanceView.thickLine();
				} else {
					studentAttendanceView.thinLine();
				}
			}
						
			String subjectSeq = studentAttendanceView.subjectAttendanceView01();
			
			if (!subjectSeq.equals("0")) {
				
				boolean subjectAttendanceViewLoop02 = true;
				
				while (subjectAttendanceViewLoop02) {
					
					Cls.clearScreen();
					studentAttendanceView.title(StudentAttendanceView.ATTENDANCESUBJECTVIEW);
					String studentName = studentAttendanceViewDAO.studentName(studentSeq);
					studentAttendanceView.studentName(studentName);
					
					VwCountAttendanceDTO vwCountAttendanceDTO = new VwCountAttendanceDTO();

					vwCountAttendanceDTO = studentAttendanceViewDAO.attendanceBySubject(subjectSeq, studentSeq);
					
					System.out.println("\n\t--------------------------------------------------------------------------\n");
					System.out.printf("\t이름: %s\n", vwCountAttendanceDTO.getName());
					System.out.printf("\t근태: 정상(%s)회, 지각(%s)회, 조퇴(%s)회, 외출(%s)회, 결석(%s)회"
										, vwCountAttendanceDTO.getAttended()
										, vwCountAttendanceDTO.getLate()
										, vwCountAttendanceDTO.getEarly()
										, vwCountAttendanceDTO.getGoout()
										, vwCountAttendanceDTO.getAbscence());
					
					System.out.println("\n\t==========================================================================\n");

					subjectSeq = studentAttendanceView.subjectAttendanceView02();
					
					if (!subjectSeq.equals("0")) continue;
					
					else if (subjectSeq.equals("0")) subjectAttendanceViewLoop02 = false;
					
				}//while : subjectAttendanceViewLoop02

			} else if (subjectSeq.equals("0")) subjectAttendanceViewLoop01 = false;
			
		}//while : subjectAttendanceViewLoop01
		
	}//method : monthlyAttendanceView

}//class : StAttendanceViewService


