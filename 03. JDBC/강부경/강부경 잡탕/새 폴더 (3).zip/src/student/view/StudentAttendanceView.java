package student.view;

import java.util.Scanner;

public class StudentAttendanceView {

	public static final int ATTENDANCERECORD 		= 3;
	public static final int ATTENDANCEVIEW 			= 4;
	public static final int ATTENDANCEENTIREVIEW 	= 5;
	public static final int ATTENDANCESUBJECTVIEW 	= 6;
	public static final int RECOMENDATION 			= 7;
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
	

//교육생 메인 메뉴	
//===============================================================================================================================
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 교육생]");
		
	}//Method : begin
	
	public String menu() {
				
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 성적 조회\n");
		System.out.println("\t\t\t\t[2] 출결 기록 입력\n");
		System.out.println("\t\t\t\t[3] 출결 조회\n");
		System.out.println("\t\t\t\t[4] 추천서 조회\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t성적 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t출결 등록 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}  else if(select.equals("3")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t출결 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("4")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t추천서 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t로그아웃합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//Method : menu

//===============================================================================================================================
	
	
	
//출결 기록 입력 메뉴
//===============================================================================================================================	
	
	public void attendanceRecordAdd01(String studentName) {
		
		System.out.printf("\t'%s' 님의 출결을 입력합니다\n\n", studentName);
		System.out.println("\t24시간 형식으로 입력하십시오");
		System.out.println("\t--------------------------------------------------------------------------");
		
	}//method : attendanceRecordAdd01
	
	public void attendanceRecordAdd02() {
		
		System.out.println("\n\t--------------------------------------------------------------------------");
		System.out.println("\t출결 기록 입력을 완료하였습니다");
		System.out.println("\t이전 화면으로 이동합니다\n");
		System.out.println("\t계속하시려면 ENTER키를 누르십시오");
		
		scan.nextLine();
		
	}
	
//===============================================================================================================================		
	
	

//출결 조회 메뉴
//===============================================================================================================================
	
	public String studentAttendanceViewMenu01() {
		
		System.out.println("\t\t\t\t[1] 출결 조회 방법 선택\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t전체 기간 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}// Method : studentAttendanceViewMenu01
	
	public String studentAttendanceViewMenu02() {
		
		System.out.println("\t\t\t\t[1] 전체 출결 조회\n");
		System.out.println("\t\t\t\t[2] 과목별 출결 조회\n\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("1")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t전체 출결 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("2")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t과목별 출결 조회 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else if(select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : studentAttendanceViewMenu02
	
	
	
	//교육생 이름
	public void studentName(String studentName) {
		
		System.out.printf("\t'%s' 님의 출결 조회 결과입니다\n", studentName);
		System.out.println("\t==========================================================================");
		
	}//method : studentName
	
//===============================================================================================================================	
	
	
	
//출결 조회 - 전체 기간 메뉴
//===============================================================================================================================
	
	public String entireAttendanceView01() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t과정번호를 선택하십시오");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			return select;	
			
		}
		
	}//method : entireAttendanceView01


	public String entireAttendanceView02() {

		System.out.println("\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : entireAttendanceView02
	
//===============================================================================================================================	
	
	
	
//출결 조회 - 과목별 조회
//===============================================================================================================================
	
	public String subjectAttendanceView01() {
		
		System.out.println("\t과목번호를 선택하십시오");	
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t[0] 돌아가기");	
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t출결사항을 확인합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;		
			
		}
		
	}//method : subjectAttendanceView01
	
	public String subjectAttendanceView02() {
		
		System.out.println("\t[0] 돌아가기");
		
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		String select = scan.nextLine();
		
		if (select.equals("0")) {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t이전 화면으로 이동합니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		} else {
			
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t잘못된 입력입니다\n");
			System.out.println("\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			return select;	
			
		}
		
	}//method : subjectAttendanceView01
	
//===============================================================================================================================
	
	
	
//제목	
//===============================================================================================================================
	
	public void title(int n) {
		
		switch(n) 
		{

		//출결 기록 입력	
		case StudentAttendanceView.ATTENDANCERECORD :
			System.out.println("\t\t\t\t[출결 등록]");
			System.out.println("\n\t==========================================================================");
			break;
			
			
		//출결 조회	
		case StudentAttendanceView.ATTENDANCEVIEW :
			System.out.println("\t\t\t\t[출결 조회]");
			System.out.println("\n\t==========================================================================\n");
			break;	
		case StudentAttendanceView.ATTENDANCEENTIREVIEW :
			System.out.println("\t\t\t\t[출결 조회 - 전체 기간]");
			System.out.println("\n\t==========================================================================");
			break;	
		case StudentAttendanceView.ATTENDANCESUBJECTVIEW :
			System.out.println("\t\t\t\t[출결 조회 - 과목별]");
			System.out.println("\n\t==========================================================================");
			break;	
			
			
		//추천서 조회	
		case StudentAttendanceView.RECOMENDATION :
			System.out.println("\t\t\t\t[추천서 조회]");
			System.out.println("\n\t==========================================================================\n");
			break;	
			
		}//switch End
		
	}//method : title

//===============================================================================================================================	
	


//ETC	
//===============================================================================================================================
	
	public void thinLine() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		
	}//method : line
	
	public void thickLine() {
		
		System.out.println("\t==========================================================================");
		
	}//method : line
	
//------------------------------------------------------------------------------------------------------------------
	
	@SuppressWarnings("resource")
	public void pause() {
		
		System.out.println("\t계속하려면 ENTER키를 누르십시오.");
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
		
	}

//------------------------------------------------------------------------------------------------------------------
	
	@SuppressWarnings("resource")
	public void error() {
		
		System.out.println("\t잘못 입력하셨습니다. 다시 입력해주세요.");
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
		
	}
	
//===============================================================================================================================
	
}//Class : StudentView
