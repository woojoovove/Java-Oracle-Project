package lecturer.service;

public interface ILeRecommendationService {

	void recommendationList();
	void leRecommendation();
	void leRecommendationAdd();
	void leRecommendationAddList();
}
