package lecturer.service;

public interface ILeGradeService {

	void allsubject();

	void student(String nextLine);

	int alleachstudent(String nextLine);

	void written();

	void practical();

	void subject();

	int eachstudent(String nextLine);

}
