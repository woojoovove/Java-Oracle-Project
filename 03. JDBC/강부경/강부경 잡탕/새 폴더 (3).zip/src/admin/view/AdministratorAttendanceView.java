package admin.view;

import java.util.ArrayList;
import java.util.Scanner;

import admin.dao.AdAttendanceDAO;
import dto.CourseNameDTO;

public class AdministratorAttendanceView {

	//출결, 추천서
	public final static int ATTENDANCEBYCOURSE = 600;
	public static final int ATTENDANCE = 601;
	public static final int FULLATTENDANCE = 602;
	public static final int RECOMMENDATION = 700;
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}

	
	
//출결, 추천서	
//===============================================================================================================================	

	public void menuAttendance() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 과정별 출결 조회\n");

		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
	}
	
//----------------------------------------------------------------------------------------------------------------
	
	public void menuCourse() {

		//[과정별 출결 조회]
		
		/* 
		 * A07-002.와 같이 출력
		 * 과정별 출결 조회를 위한 과정 목록 출력 : 10개씩 끊어서 보여주기
		최신순으로 정렬,
		SELECT coursename FROM course ORDER BY startdate desc; 
		
		*/
		
		AdAttendanceDAO adAttendanceDAO = new AdAttendanceDAO();
		ArrayList<CourseNameDTO> courseNameDTO = adAttendanceDAO.courseNameList();
		
		System.out.println("\n\t[과정명]");
		System.out.println("\n\t==========================================================================\n");
		for(CourseNameDTO dto : courseNameDTO) {
			
			System.out.printf("\t[%s] %s\n", dto.getSeq(), dto.getName());
			System.out.println("\t--------------------------------------------------------------------------\n");
		}
		System.out.println("\t==========================================================================\n");
		System.out.println("\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t입력: ");
		
		
	}
	
//----------------------------------------------------------------------------------------------------------------
	
	public void menuCourseSub() {

		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t조회 방법을 선택하십시오");
		System.out.println("\t\t\t\t[1] 전체 조회\n");
		System.out.println("\t\t\t\t[2] 기간별 조회\n");
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}

	
//----------------------------------------------------------------------------------------------------------------
	
	public void pause(int n) {
		
		if (n == AdministratorAttendanceView.RECOMMENDATION) { 
			
			System.out.println("추천서 입력을 계속 하시려면 엔터를 입력해주세요");
			scan.nextLine();
		} else if (n == AdministratorAttendanceView.ATTENDANCEBYCOURSE) {
			
			
		}
	}
	
//===============================================================================================================================
	
	public void title(int n) {
		
		switch(n)
		{
		
		//출결, 추천서 관리
		case AdministratorAttendanceView.ATTENDANCEBYCOURSE	: 
			System.out.println("\t\t\t\t[과정별 출결 관리]");
			break;
		case AdministratorAttendanceView.ATTENDANCE	: 
			System.out.println("\t\t[출결 관리]"); 
			break;
		case AdministratorAttendanceView.RECOMMENDATION	: 
			System.out.println("\t\t[추천서 관리]");
			break;
		case AdministratorAttendanceView.FULLATTENDANCE	: 
			System.out.println("\t\t[전체 기간 조회]"); 
			break;
			
		}//switch End
				
	}//Method : title

}//Class : AdministratorView



