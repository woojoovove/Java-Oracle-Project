package dto;

public class VwstugraDTO {

	private String vstuname;
	private String vstupnum;
	private String vstustatus;
	private String vstuseq;
	private String vsuvgraseq;
	private String vstustadate;
	
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVstustatus() {
		return vstustatus;
	}
	public void setVstustatus(String vstustatus) {
		this.vstustatus = vstustatus;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	}
	public String getVsuvgraseq() {
		return vsuvgraseq;
	}
	public void setVsuvgraseq(String vsuvgraseq) {
		this.vsuvgraseq = vsuvgraseq;
	}
	public String getVstustadate() {
		return vstustadate;
	}
	public void setVstustadate(String vstustadate) {
		this.vstustadate = vstustadate;
	}
	
	
}
