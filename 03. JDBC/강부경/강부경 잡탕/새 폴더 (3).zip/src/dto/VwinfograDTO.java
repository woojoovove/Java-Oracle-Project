package dto;

public class VwinfograDTO {

	private String vstuname;
	private String vrnum;
	private String vgrawri;
	private String vgraprac;
	private String vcouseq;
	private String vsubseq;
	
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVrnum() {
		return vrnum;
	}
	public void setVrnum(String vrnum) {
		this.vrnum = vrnum;
	}
	public String getVgrawri() {
		return vgrawri;
	}
	public void setVgrawri(String vgrawri) {
		this.vgrawri = vgrawri;
	}
	public String getVgraprac() {
		return vgraprac;
	}
	public void setVgraprac(String vgraprac) {
		this.vgraprac = vgraprac;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	
}
