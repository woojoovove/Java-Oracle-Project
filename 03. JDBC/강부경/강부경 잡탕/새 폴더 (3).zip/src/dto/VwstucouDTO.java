package dto;

public class VwstucouDTO {

	
	private String vstuname;
	private String vsturnum;
	private String vstupnum;
	private String vcouname;
	private String vcoustart;
	private String vcouend;
	private String vstustatus;
	private String vstuinseq;
	private String vcouseq;
	private String vstuinrdate;
	private String vstustatusdate;
	private String vstuseq;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVsturnum() {
		return vsturnum;
	}
	public void setVsturnum(String vsturnum) {
		this.vsturnum = vsturnum;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcouend() {
		return vcouend;
	}
	public void setVcouend(String vcouend) {
		this.vcouend = vcouend;
	}
	public String getVstustatus() {
		return vstustatus;
	}
	public void setVstustatus(String vstustatus) {
		this.vstustatus = vstustatus;
	}
	public String getVstuinseq() {
		return vstuinseq;
	}
	public void setVstuinseq(String vstuinseq) {
		this.vstuinseq = vstuinseq;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVstuinrdate() {
		return vstuinrdate;
	}
	public void setVstuinrdate(String vstuinrdate) {
		this.vstuinrdate = vstuinrdate;
	}
	public String getVstustatusdate() {
		return vstustatusdate;
	}
	public void setVstustatusdate(String vstustatusdate) {
		this.vstustatusdate = vstustatusdate;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	}
	
	
	
}
